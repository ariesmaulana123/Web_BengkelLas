-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 04, 2026 at 05:49 AM
-- Server version: 8.0.30
-- PHP Version: 8.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sentosa_jaya`
--

-- --------------------------------------------------------

--
-- Table structure for table `estimasi`
--

CREATE TABLE `estimasi` (
  `id_estimasi` bigint UNSIGNED NOT NULL,
  `id_user` int UNSIGNED DEFAULT NULL,
  `nama_customer_manual` varchar(150) DEFAULT NULL,
  `no_wa_manual` varchar(30) DEFAULT NULL,
  `id_jp` int UNSIGNED DEFAULT NULL,
  `nama_pekerjaan` varchar(255) DEFAULT NULL,
  `panjang` decimal(10,2) NOT NULL,
  `lebar` decimal(10,2) NOT NULL,
  `tinggi` decimal(10,2) DEFAULT NULL,
  `ukuran_lubang` varchar(100) DEFAULT NULL,
  `luas` decimal(10,2) DEFAULT '0.00',
  `qty_unit` varchar(100) DEFAULT '1',
  `material_custom` text,
  `subtotal` decimal(15,2) DEFAULT '0.00',
  `harga_bahan` decimal(15,2) NOT NULL DEFAULT '0.00',
  `harga_jasa` decimal(15,2) NOT NULL DEFAULT '0.00',
  `estimasi_min` decimal(15,2) DEFAULT '0.00',
  `estimasi_max` decimal(15,2) DEFAULT '0.00',
  `biaya_jasa` decimal(15,2) DEFAULT '0.00',
  `biaya_pengiriman` decimal(15,2) DEFAULT '0.00',
  `biaya_tambahan` decimal(15,2) DEFAULT '0.00',
  `diskon` decimal(15,2) DEFAULT '0.00',
  `total_final` decimal(15,2) DEFAULT NULL,
  `catatan` text,
  `catatan_admin` text,
  `tanggal_survey` datetime DEFAULT NULL,
  `lokasi_survey` text,
  `sumber` varchar(20) NOT NULL DEFAULT 'kalkulator',
  `status` varchar(30) NOT NULL DEFAULT 'dihitung',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `estimasi`
--

INSERT INTO `estimasi` (`id_estimasi`, `id_user`, `nama_customer_manual`, `no_wa_manual`, `id_jp`, `nama_pekerjaan`, `panjang`, `lebar`, `tinggi`, `ukuran_lubang`, `luas`, `qty_unit`, `material_custom`, `subtotal`, `harga_bahan`, `harga_jasa`, `estimasi_min`, `estimasi_max`, `biaya_jasa`, `biaya_pengiriman`, `biaya_tambahan`, `diskon`, `total_final`, `catatan`, `catatan_admin`, `tanggal_survey`, `lokasi_survey`, `sumber`, `status`, `created_at`, `updated_at`) VALUES
(43, NULL, 'Bapak Agus', '08783637452736', NULL, 'borongan', 2.00, 6.00, NULL, '', 12.00, '1', 'holo', 5000000.00, 100000.00, 200000.00, 0.00, 0.00, 200000.00, 0.00, 0.00, 0.00, 5000000.00, 'ok', NULL, '2026-10-02 10:31:00', 'bekasi', 'manual', 'deal', '2026-10-02 03:31:55', '2026-10-02 03:33:18'),
(44, 4, NULL, NULL, NULL, NULL, 5.00, 3.00, 0.00, NULL, 0.00, '1', NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'Estimasi kanopi carport dari kalkulator web', NULL, NULL, NULL, 'kalkulator', 'tersimpan', '2026-10-02 03:38:13', '2026-10-02 03:38:13'),
(45, NULL, 'Ibu Hajah Siti (WA)', '082199887766', NULL, 'Teralis Jendela Klasik & Pintu Kasa Nyamuk', 2.50, 1.80, 0.00, '15 x 15 cm jarak kisi', 0.00, '4 Unit Jendela + 1 Pintu', 'Besi Nako 12mm Full, Frame Hollow 4x4 Tebal 1.6mm, Finishing Duco Hitam Doff', 0.00, 2800000.00, 1200000.00, 0.00, 0.00, 0.00, 150000.00, 0.00, 50000.00, NULL, 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.', NULL, NULL, NULL, 'manual', 'deal', '2026-10-02 03:38:13', '2026-10-02 03:38:13'),
(46, 4, NULL, NULL, NULL, NULL, 5.00, 3.00, 0.00, NULL, 0.00, '1', NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'Estimasi kanopi carport dari kalkulator web', NULL, NULL, NULL, 'kalkulator', 'tersimpan', '2026-10-04 03:37:42', '2026-10-04 03:37:42'),
(47, NULL, 'Ibu Hajah Siti (WA)', '082199887766', NULL, 'Teralis Jendela Klasik & Pintu Kasa Nyamuk', 2.50, 1.80, 0.00, '15 x 15 cm jarak kisi', 0.00, '4 Unit Jendela + 1 Pintu', 'Besi Nako 12mm Full, Frame Hollow 4x4 Tebal 1.6mm, Finishing Duco Hitam Doff', 0.00, 2800000.00, 1200000.00, 0.00, 0.00, 0.00, 150000.00, 0.00, 50000.00, NULL, 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.', NULL, NULL, NULL, 'manual', 'deal', '2026-10-04 03:37:42', '2026-10-04 03:37:42'),
(48, 4, NULL, NULL, NULL, NULL, 5.00, 3.00, 0.00, NULL, 0.00, '1', NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'Estimasi kanopi carport dari kalkulator web', NULL, NULL, NULL, 'kalkulator', 'tersimpan', '2026-10-04 03:57:39', '2026-10-04 03:57:39'),
(49, NULL, 'Ibu Hajah Siti (WA)', '082199887766', NULL, 'Teralis Jendela Klasik & Pintu Kasa Nyamuk', 2.50, 1.80, 0.00, '15 x 15 cm jarak kisi', 0.00, '4 Unit Jendela + 1 Pintu', 'Besi Nako 12mm Full, Frame Hollow 4x4 Tebal 1.6mm, Finishing Duco Hitam Doff', 0.00, 2800000.00, 1200000.00, 0.00, 0.00, 0.00, 150000.00, 0.00, 50000.00, NULL, 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.', NULL, NULL, NULL, 'manual', 'deal', '2026-10-04 03:57:39', '2026-10-04 03:57:39'),
(50, 4, NULL, NULL, NULL, NULL, 5.00, 3.00, 0.00, NULL, 0.00, '1', NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'Estimasi kanopi carport dari kalkulator web', NULL, NULL, NULL, 'kalkulator', 'tersimpan', '2026-10-04 03:58:19', '2026-10-04 03:58:19'),
(51, NULL, 'Ibu Hajah Siti (WA)', '082199887766', NULL, 'Teralis Jendela Klasik & Pintu Kasa Nyamuk', 2.50, 1.80, 0.00, '15 x 15 cm jarak kisi', 0.00, '4 Unit Jendela + 1 Pintu', 'Besi Nako 12mm Full, Frame Hollow 4x4 Tebal 1.6mm, Finishing Duco Hitam Doff', 0.00, 2800000.00, 1200000.00, 0.00, 0.00, 0.00, 150000.00, 0.00, 50000.00, NULL, 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.', NULL, NULL, NULL, 'manual', 'deal', '2026-10-04 03:58:19', '2026-10-04 03:58:19'),
(52, 4, NULL, NULL, NULL, NULL, 5.00, 3.00, 0.00, NULL, 0.00, '1', NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'Estimasi kanopi carport dari kalkulator web', NULL, NULL, NULL, 'kalkulator', 'tersimpan', '2026-10-04 03:58:46', '2026-10-04 03:58:46'),
(53, NULL, 'Ibu Hajah Siti (WA)', '082199887766', NULL, 'Teralis Jendela Klasik & Pintu Kasa Nyamuk', 2.50, 1.80, 0.00, '15 x 15 cm jarak kisi', 0.00, '4 Unit Jendela + 1 Pintu', 'Besi Nako 12mm Full, Frame Hollow 4x4 Tebal 1.6mm, Finishing Duco Hitam Doff', 0.00, 2800000.00, 1200000.00, 0.00, 0.00, 0.00, 150000.00, 0.00, 50000.00, NULL, 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.', NULL, NULL, NULL, 'manual', 'deal', '2026-10-04 03:58:46', '2026-10-04 03:58:46'),
(54, 4, NULL, NULL, NULL, NULL, 5.00, 3.00, 0.00, NULL, 0.00, '1', NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'Estimasi kanopi carport dari kalkulator web', NULL, NULL, NULL, 'kalkulator', 'tersimpan', '2026-10-04 04:10:15', '2026-10-04 04:10:15'),
(55, NULL, 'Ibu Hajah Siti (WA)', '082199887766', NULL, 'Teralis Jendela Klasik & Pintu Kasa Nyamuk', 2.50, 1.80, 0.00, '15 x 15 cm jarak kisi', 0.00, '4 Unit Jendela + 1 Pintu', 'Besi Nako 12mm Full, Frame Hollow 4x4 Tebal 1.6mm, Finishing Duco Hitam Doff', 0.00, 2800000.00, 1200000.00, 0.00, 0.00, 0.00, 150000.00, 0.00, 50000.00, NULL, 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.', NULL, NULL, NULL, 'manual', 'deal', '2026-10-04 04:10:15', '2026-10-04 04:10:15'),
(56, 4, NULL, NULL, NULL, NULL, 5.00, 3.00, 0.00, NULL, 0.00, '1', NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'Estimasi kanopi carport dari kalkulator web', NULL, NULL, NULL, 'kalkulator', 'tersimpan', '2026-10-04 04:13:22', '2026-10-04 04:13:22'),
(57, NULL, 'Ibu Hajah Siti (WA)', '082199887766', NULL, 'Teralis Jendela Klasik & Pintu Kasa Nyamuk', 2.50, 1.80, 0.00, '15 x 15 cm jarak kisi', 0.00, '4 Unit Jendela + 1 Pintu', 'Besi Nako 12mm Full, Frame Hollow 4x4 Tebal 1.6mm, Finishing Duco Hitam Doff', 0.00, 2800000.00, 1200000.00, 0.00, 0.00, 0.00, 150000.00, 0.00, 50000.00, NULL, 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.', NULL, NULL, NULL, 'manual', 'deal', '2026-10-04 04:13:22', '2026-10-04 04:13:22'),
(58, 4, NULL, NULL, NULL, NULL, 5.00, 3.00, 0.00, NULL, 0.00, '1', NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'Estimasi kanopi carport dari kalkulator web', NULL, NULL, NULL, 'kalkulator', 'tersimpan', '2026-10-04 04:14:16', '2026-10-04 04:14:16'),
(59, NULL, 'Ibu Hajah Siti (WA)', '082199887766', NULL, 'Teralis Jendela Klasik & Pintu Kasa Nyamuk', 2.50, 1.80, 0.00, '15 x 15 cm jarak kisi', 0.00, '4 Unit Jendela + 1 Pintu', 'Besi Nako 12mm Full, Frame Hollow 4x4 Tebal 1.6mm, Finishing Duco Hitam Doff', 0.00, 2800000.00, 1200000.00, 0.00, 0.00, 0.00, 150000.00, 0.00, 50000.00, NULL, 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.', NULL, NULL, NULL, 'manual', 'deal', '2026-10-04 04:14:16', '2026-10-04 04:14:16'),
(60, 4, NULL, NULL, NULL, NULL, 5.00, 3.00, 0.00, NULL, 0.00, '1', NULL, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 'Estimasi kanopi carport dari kalkulator web', NULL, NULL, NULL, 'kalkulator', 'tersimpan', '2026-10-04 04:19:56', '2026-10-04 04:19:56'),
(61, 7, 'Ibu Hajah Siti (WA)', '082199887766', NULL, 'Teralis Jendela Klasik & Pintu Kasa Nyamuk', 2.50, 1.80, 0.00, '15 x 15 cm jarak kisi', 0.00, '4 Unit Jendela + 1 Pintu', 'Besi Nako 12mm Full, Frame Hollow 4x4 Tebal 1.6mm, Finishing Duco Hitam Doff', 0.00, 2800000.00, 1200000.00, 0.00, 0.00, 0.00, 150000.00, 0.00, 50000.00, NULL, 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.', NULL, NULL, NULL, 'manual', 'deal', '2026-10-04 04:19:56', '2026-10-04 05:45:53'),
(62, NULL, NULL, NULL, 3, NULL, 4.00, 2.00, NULL, NULL, 8.00, '1', NULL, 3920000.00, 0.00, 0.00, 3528000.00, 4312000.00, 0.00, 0.00, 0.00, 0.00, NULL, '', NULL, NULL, NULL, 'kalkulator', 'dihitung', '2026-10-04 04:34:09', '2026-10-04 04:34:09');

-- --------------------------------------------------------

--
-- Table structure for table `estimasi_detail`
--

CREATE TABLE `estimasi_detail` (
  `id_detail_est` bigint UNSIGNED NOT NULL,
  `id_estimasi` bigint UNSIGNED NOT NULL,
  `id_material` int UNSIGNED NOT NULL,
  `qty` decimal(10,2) NOT NULL,
  `harga` decimal(15,2) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `estimasi_detail`
--

INSERT INTO `estimasi_detail` (`id_detail_est`, `id_estimasi`, `id_material`, `qty`, `harga`, `subtotal`, `created_at`) VALUES
(15, 62, 20, 8.00, 380000.00, 3040000.00, '2026-10-04 04:34:09'),
(16, 62, 21, 8.00, 110000.00, 880000.00, '2026-10-04 04:34:09');

-- --------------------------------------------------------

--
-- Table structure for table `follow_up`
--

CREATE TABLE `follow_up` (
  `id_follow_up` bigint UNSIGNED NOT NULL,
  `id_estimasi` bigint UNSIGNED DEFAULT NULL,
  `id_proyek` bigint UNSIGNED DEFAULT NULL,
  `id_user_admin` int UNSIGNED NOT NULL,
  `tipe` varchar(50) NOT NULL DEFAULT 'estimasi',
  `metode` varchar(50) NOT NULL DEFAULT 'whatsapp',
  `hasil` text NOT NULL,
  `tanggal_follow_up` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tanggal_next_follow_up` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `follow_up`
--

INSERT INTO `follow_up` (`id_follow_up`, `id_estimasi`, `id_proyek`, `id_user_admin`, `tipe`, `metode`, `hasil`, `tanggal_follow_up`, `tanggal_next_follow_up`, `created_at`) VALUES
(6, 61, 7, 2, 'penawaran', 'whatsapp', 'Customer menyetujui penawaran (DEAL). Proyek resmi dibuat dengan kode PRJ-202610-0001.', '2026-10-04 05:45:53', NULL, '2026-10-04 05:45:53');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_pekerjaan`
--

CREATE TABLE `jenis_pekerjaan` (
  `id_jp` int UNSIGNED NOT NULL,
  `nama` varchar(100) NOT NULL,
  `deskripsi` text,
  `status` varchar(20) NOT NULL DEFAULT 'aktif',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `jenis_pekerjaan`
--

INSERT INTO `jenis_pekerjaan` (`id_jp`, `nama`, `deskripsi`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Kanopi', 'Pembuatan dan pemasangan kanopi carport, teras, dan kanopi komersial dengan berbagai pilihan rangka dan atap berkualitas.', 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19'),
(2, 'Pagar', 'Fabrikasi pagar besi minimalis, laser cutting, perforated, dan expanded metal bergaransi anti karat.', 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19'),
(3, 'Railing Tangga', 'Pemasangan railing tangga dan balkon modern dari bahan hollow galvanis, stainless steel, dan kaca tempered.', 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19'),
(4, 'Teralis', 'Pembuatan teralis jendela dan pintu pengaman dengan material besi nako, plat, atau hollow kokoh.', 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19');

-- --------------------------------------------------------

--
-- Table structure for table `kasbon_tukang`
--

CREATE TABLE `kasbon_tukang` (
  `id_kasbon` int NOT NULL,
  `id_proyek` int NOT NULL,
  `id_tukang` int NOT NULL,
  `id_admin` int DEFAULT NULL,
  `nominal` decimal(15,2) NOT NULL DEFAULT '0.00',
  `tanggal_kasbon` date NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `metode_pembayaran` varchar(50) COLLATE utf8mb4_general_ci DEFAULT 'transfer',
  `bukti_transfer` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kasbon_tukang`
--

INSERT INTO `kasbon_tukang` (`id_kasbon`, `id_proyek`, `id_tukang`, `id_admin`, `nominal`, `tanggal_kasbon`, `keterangan`, `metode_pembayaran`, `bukti_transfer`, `created_at`, `updated_at`) VALUES
(1, 4, 5, 2, 1000001.00, '2026-09-25', 'sisa', 'transfer', '1790304983_8646e06647b75f00ae95.png', '2026-09-25 02:56:23', '2026-09-25 02:56:23'),
(2, 4, 5, 2, 900001.00, '2026-09-30', '', 'tunai', NULL, '2026-09-25 03:28:27', '2026-09-25 03:28:27'),
(3, 3, 3, 2, 9990001.00, '2026-09-25', '', 'tunai', NULL, '2026-09-25 03:31:58', '2026-09-25 03:31:58'),
(4, 5, 3, 1, 350000.00, '2026-10-02', 'Kasbon tahap awal', 'transfer', NULL, '2026-10-02 03:23:37', '2026-10-02 03:23:37'),
(5, 6, 3, 1, 350000.00, '2026-10-02', 'Kasbon tahap awal', 'transfer', NULL, '2026-10-02 03:24:46', '2026-10-02 03:24:46');

-- --------------------------------------------------------

--
-- Table structure for table `master_harga`
--

CREATE TABLE `master_harga` (
  `id_mharg` int UNSIGNED NOT NULL,
  `id_material` int UNSIGNED NOT NULL,
  `harga` decimal(15,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'aktif',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `master_harga`
--

INSERT INTO `master_harga` (`id_mharg`, `id_material`, `harga`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 175000.00, 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19'),
(2, 2, 225000.00, 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19'),
(3, 3, 135000.00, 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19'),
(4, 4, 390000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(5, 5, 245000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(6, 6, 160000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(7, 7, 130000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(8, 8, 210000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(9, 9, 480000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(10, 10, 95000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(11, 11, 100000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(12, 12, 380000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(13, 13, 750000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(14, 14, 520000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(15, 15, 680000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(16, 16, 120000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(17, 17, 450000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(18, 18, 650000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(19, 19, 850000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(20, 20, 380000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(21, 21, 110000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20'),
(22, 22, 80000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-25 11:08:14'),
(23, 23, 65000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-25 11:08:14'),
(24, 24, 75000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-25 11:08:14'),
(25, 25, 115000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-25 11:08:14'),
(26, 26, 30000.00, 'aktif', '2026-09-16 17:23:20', '2026-09-25 11:08:14'),
(27, 27, 45000.00, 'aktif', '2026-09-25 11:08:14', '2026-09-25 11:08:14'),
(28, 28, 35000.00, 'aktif', '2026-09-25 11:08:14', '2026-09-25 11:08:14'),
(29, 29, 95000.00, 'aktif', '2026-09-25 11:08:30', '2026-09-25 11:08:30');

-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE `material` (
  `id_material` int UNSIGNED NOT NULL,
  `id_jp` int UNSIGNED NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `nama_material` varchar(150) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'aktif',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `panjang_standar` decimal(6,2) NOT NULL DEFAULT '6.00' COMMENT 'Panjang standar material batang dalam meter'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `material`
--

INSERT INTO `material` (`id_material`, `id_jp`, `kategori`, `nama_material`, `satuan`, `status`, `created_at`, `updated_at`, `panjang_standar`) VALUES
(1, 1, 'rangka', 'Hollow Galvanis 40x40 (Tebal 1.2mm)', 'm2', 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19', 6.00),
(2, 1, 'rangka', 'Hollow Galvanis 40x60 (Tebal 1.4mm)', 'm2', 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19', 6.00),
(3, 1, 'rangka', 'Baja Ringan Zincalume C75', 'm2', 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19', 6.00),
(4, 1, 'rangka', 'Besi WF 150 Industrial', 'm2', 'aktif', '2026-09-16 17:23:19', '2026-09-16 17:23:19', 6.00),
(5, 1, 'atap', 'Alderon Double Layer (Twinwall)', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(6, 1, 'atap', 'Alderon Single Layer (RS)', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(7, 1, 'atap', 'Spandek Pasir (Peredam Suara)', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(8, 1, 'atap', 'Polycarbonate SolarTuff Flat', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(9, 1, 'atap', 'Kaca Tempered 8mm Clear', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(10, 1, 'tiang', 'Tiang Hollow 40x60 / 50x50 Galvanis', 'm', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(11, 1, 'jasa', 'Jasa Fabrikasi & Instalasi Kanopi', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(12, 2, 'rangka', 'Besi Hollow Minimalis Galvanis 40x40/40x20', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(13, 2, 'rangka', 'Laser Cutting Motif Plat Baja 2mm', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(14, 2, 'rangka', 'Kombinasi Plat Perforated & Hollow', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(15, 2, 'rangka', 'Besi Tempa Klasik Ornamen', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(16, 2, 'jasa', 'Jasa Fabrikasi & Pemasangan Pagar', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(17, 3, 'rangka', 'Hollow Galvanis Minimalis + Handrail Kayu', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(18, 3, 'rangka', 'Stainless Steel 304 Anti Karat', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(19, 3, 'rangka', 'Kaca Tempered 10mm Frameless', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(20, 3, 'rangka', 'Besi Hollow Full Hitam Doff', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(21, 3, 'jasa', 'Jasa Fabrikasi & Pemasangan Railing', 'm2', 'aktif', '2026-09-16 17:23:20', '2026-09-16 17:23:20', 6.00),
(22, 4, 'rangka', 'Besi Nako 10mm Minimalis', 'batang', 'aktif', '2026-09-16 17:23:20', '2026-09-25 11:08:14', 6.00),
(23, 4, 'rangka', 'Besi Plat Strip Minimalis 25x3', 'batang', 'aktif', '2026-09-16 17:23:20', '2026-09-25 11:08:14', 6.00),
(24, 4, 'rangka', 'Hollow Galvanis 20x20 Kotak', 'batang', 'aktif', '2026-09-16 17:23:20', '2026-09-25 11:08:14', 6.00),
(25, 4, 'rangka', 'Besi Ulir Tempa Klasik 12mm', 'batang', 'aktif', '2026-09-16 17:23:20', '2026-09-25 11:08:14', 6.00),
(26, 4, 'jasa', 'Jasa Pasang & Transportasi Teralis', 'unit', 'aktif', '2026-09-16 17:23:20', '2026-09-25 11:08:14', 6.00),
(27, 4, 'jasa', 'Jasa Fabrikasi & Pengelasan Teralis', 'unit', 'aktif', '2026-09-25 11:08:14', '2026-09-25 11:08:14', 6.00),
(28, 4, 'jasa', 'Jasa Finishing & Pengecatan Duco', 'unit', 'aktif', '2026-09-25 11:08:14', '2026-09-25 11:08:14', 6.00),
(29, 4, 'rangka', 'Besi Nako 12mm Minimalis Modern', 'batang', 'aktif', '2026-09-25 11:08:30', '2026-09-25 11:08:30', 6.00);

-- --------------------------------------------------------

--
-- Table structure for table `pengaturan_perusahaan`
--

CREATE TABLE `pengaturan_perusahaan` (
  `id` int UNSIGNED NOT NULL,
  `nama_perusahaan` varchar(150) NOT NULL DEFAULT 'Sentosa Jaya Las',
  `tagline` varchar(255) DEFAULT 'Bengkel Las & Konstruksi Baja Presisi Bergaransi',
  `alamat` text NOT NULL,
  `no_wa` varchar(30) NOT NULL DEFAULT '087766364557',
  `email` varchar(100) NOT NULL DEFAULT 'admin@sentosajayalas.com',
  `nama_bank` varchar(50) DEFAULT 'BCA (Bank Central Asia)',
  `no_rekening` varchar(50) DEFAULT '8735-0912-33',
  `atas_nama_bank` varchar(100) DEFAULT 'Sentosa Jaya Las / Maulana',
  `logo` varchar(255) DEFAULT NULL,
  `nama_penanggung_jawab` varchar(100) DEFAULT 'Bambang Sentosa',
  `jabatan_penanggung_jawab` varchar(100) DEFAULT 'Direktur Operasional',
  `catatan_penawaran` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pengaturan_perusahaan`
--

INSERT INTO `pengaturan_perusahaan` (`id`, `nama_perusahaan`, `tagline`, `alamat`, `no_wa`, `email`, `nama_bank`, `no_rekening`, `atas_nama_bank`, `logo`, `nama_penanggung_jawab`, `jabatan_penanggung_jawab`, `catatan_penawaran`, `created_at`, `updated_at`) VALUES
(1, 'Sentosa Jaya Las', 'Spesialis Kanopi, Pagar, Railing & Konstruksi Besi Berkualitas', 'Jl. Kubang , kp lubang buaya, RT.003/RW.009, Cijengkol, Kec. Setu, Kota Bks, Jawa Barat 17320', '087766364557', 'sentosajayalas.1@gmail.com', 'Bank Mandiri', '1560022862272', 'ARIEF MAULANA', NULL, 'PARSONO (Gofar)', 'Kepala Workshop', '1. Harga sudah termasuk material, ongkos kerja perakitan, dan pemasangan di lokasi.\r\n2. Pembayaran DP minimal 50% saat kesepakatan SPK kerja, pelunasan setelah pengerjaan selesai 100% dan di-acc pelanggan.\r\n3. Masa garansi konstruksi dan kebocoran atap berlaku selama 12 bulan sejak serah terima.', '2026-09-17 00:23:23', '2026-09-21 05:55:56');

-- --------------------------------------------------------

--
-- Table structure for table `proyek`
--

CREATE TABLE `proyek` (
  `id_proyek` bigint UNSIGNED NOT NULL,
  `id_estimasi` bigint UNSIGNED DEFAULT NULL,
  `id_user` int UNSIGNED NOT NULL,
  `id_tukang` int UNSIGNED DEFAULT NULL,
  `nilai_tukang` decimal(15,2) NOT NULL DEFAULT '0.00',
  `pekerjaan_tukang` text,
  `kode_proyek` varchar(50) NOT NULL,
  `nama_proyek` varchar(150) NOT NULL,
  `nilai_proyek` decimal(15,2) NOT NULL DEFAULT '0.00',
  `dp` decimal(15,2) NOT NULL DEFAULT '0.00',
  `sisa_pembayaran` decimal(15,2) NOT NULL DEFAULT '0.00',
  `status_pembayaran` varchar(30) NOT NULL DEFAULT 'belum_lunas',
  `tanggal_mulai` date DEFAULT NULL,
  `tanggal_target_selesai` date DEFAULT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `progress` int NOT NULL DEFAULT '0',
  `status` varchar(30) NOT NULL DEFAULT 'rencana',
  `catatan` text,
  `foto_dokumentasi` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `proyek`
--

INSERT INTO `proyek` (`id_proyek`, `id_estimasi`, `id_user`, `id_tukang`, `nilai_tukang`, `pekerjaan_tukang`, `kode_proyek`, `nama_proyek`, `nilai_proyek`, `dp`, `sisa_pembayaran`, `status_pembayaran`, `tanggal_mulai`, `tanggal_target_selesai`, `tanggal_selesai`, `progress`, `status`, `catatan`, `foto_dokumentasi`, `created_at`, `updated_at`) VALUES
(7, 61, 7, NULL, 0.00, '', 'PRJ-202610-0001', 'Pengerjaan Teralis Jendela Klasik & Pintu Kasa Nyamuk - Ibu Hajah Siti (WA)', 4000000.00, 0.00, 4000000.00, 'belum_lunas', '2026-10-04', NULL, NULL, 0, 'rencana', 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.', NULL, '2026-10-04 05:45:53', '2026-10-04 05:45:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int UNSIGNED NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `no_wa` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'customer',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `email`, `no_wa`, `password`, `role`, `created_at`, `updated_at`) VALUES
(2, 'Admin Sentosa Jaya', 'ariesmaulana653@gmail.com', '6281298765432', '$2y$12$u2ZC4Ov9gQo/4nfwVKvnQOWABTY6a3n16hXVLug6rY2cjzd4N0Sd2', 'admin', '2026-09-16 17:23:19', '2026-09-24 19:25:03'),
(3, 'Sujatno (Tukang Las Senior)', 'tukang@sentosajayalas.com', '081298765001', '$2y$10$/Gsr/r30krf73maxfJR95.PSj.MbQxbkSAicXEWX.35xl0fh6eCcW', 'tukang', '2026-09-16 17:23:23', '2026-09-16 17:23:23'),
(4, 'ARIEF MAULANA', 'ariefmaulanakenz@gmail.com', '087766364557', '$2y$12$OHdcH.9x8fkuruNlOsziKewpyZjaj8baRfYb0qQZWq3o5KihX1XjW', 'customer', '2026-09-19 10:00:25', '2026-09-19 10:00:25'),
(5, 'Suwandi', 'suwandhiart@gmail.com', '08129876503', '$2y$12$005CNLmFztM7qT6CtS5YausPu6L8gHJ6vhDHbI47ql/d6TFAXo/OS', 'tukang', '2026-09-25 01:04:53', '2026-09-25 01:04:53'),
(6, 'Agung herkules', 'ariefmaulanazh@gmail.com', '08963726342537', '$2y$12$GmiLOyWDJlu0Q/E6a6s3H.gS2g.y0K4EjBjcZy3Pq/NPc4XYOw.py', 'customer', '2026-09-25 04:50:24', '2026-09-25 04:50:24'),
(7, 'Ibu Hajah Siti (WA)', 'wa082199887766@sentosajayalas.com', '082199887766', '$2y$12$s.jpzfhYgtXtzrIsdvv2keAJJUZJflmLPFlCxs7/Ae7DuB2VCUFKe', 'customer', '2026-10-04 05:45:53', '2026-10-04 05:45:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `estimasi`
--
ALTER TABLE `estimasi`
  ADD PRIMARY KEY (`id_estimasi`),
  ADD KEY `idx_estimasi_user` (`id_user`),
  ADD KEY `idx_estimasi_jp` (`id_jp`),
  ADD KEY `idx_estimasi_status` (`status`);

--
-- Indexes for table `estimasi_detail`
--
ALTER TABLE `estimasi_detail`
  ADD PRIMARY KEY (`id_detail_est`),
  ADD KEY `idx_detail_estimasi` (`id_estimasi`),
  ADD KEY `idx_detail_material` (`id_material`);

--
-- Indexes for table `follow_up`
--
ALTER TABLE `follow_up`
  ADD PRIMARY KEY (`id_follow_up`),
  ADD KEY `idx_fu_estimasi` (`id_estimasi`),
  ADD KEY `idx_fu_proyek` (`id_proyek`),
  ADD KEY `idx_fu_admin` (`id_user_admin`);

--
-- Indexes for table `jenis_pekerjaan`
--
ALTER TABLE `jenis_pekerjaan`
  ADD PRIMARY KEY (`id_jp`),
  ADD UNIQUE KEY `nama` (`nama`);

--
-- Indexes for table `kasbon_tukang`
--
ALTER TABLE `kasbon_tukang`
  ADD PRIMARY KEY (`id_kasbon`),
  ADD KEY `idx_proyek` (`id_proyek`),
  ADD KEY `idx_tukang` (`id_tukang`);

--
-- Indexes for table `master_harga`
--
ALTER TABLE `master_harga`
  ADD PRIMARY KEY (`id_mharg`),
  ADD UNIQUE KEY `uq_harga_material` (`id_material`),
  ADD KEY `idx_harga_material` (`id_material`);

--
-- Indexes for table `material`
--
ALTER TABLE `material`
  ADD PRIMARY KEY (`id_material`),
  ADD UNIQUE KEY `uq_material` (`id_jp`,`kategori`,`nama_material`),
  ADD KEY `idx_material_jp` (`id_jp`);

-- Indexes for table `pengaturan_perusahaan`
--
ALTER TABLE `pengaturan_perusahaan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `proyek`
--
ALTER TABLE `proyek`
  ADD PRIMARY KEY (`id_proyek`),
  ADD UNIQUE KEY `uq_kode_proyek` (`kode_proyek`),
  ADD KEY `idx_proyek_estimasi` (`id_estimasi`),
  ADD KEY `idx_proyek_user` (`id_user`),
  ADD KEY `idx_proyek_tukang` (`id_tukang`),
  ADD KEY `idx_proyek_status` (`status`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `no_wa` (`no_wa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `estimasi`
--
ALTER TABLE `estimasi`
  MODIFY `id_estimasi` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `estimasi_detail`
--
ALTER TABLE `estimasi_detail`
  MODIFY `id_detail_est` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `follow_up`
--
ALTER TABLE `follow_up`
  MODIFY `id_follow_up` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jenis_pekerjaan`
--
ALTER TABLE `jenis_pekerjaan`
  MODIFY `id_jp` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `kasbon_tukang`
--
ALTER TABLE `kasbon_tukang`
  MODIFY `id_kasbon` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `master_harga`
--
ALTER TABLE `master_harga`
  MODIFY `id_mharg` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `material`
--
ALTER TABLE `material`
  MODIFY `id_material` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

-- AUTO_INCREMENT for table `pengaturan_perusahaan`
--
ALTER TABLE `pengaturan_perusahaan`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `proyek`
--
ALTER TABLE `proyek`
  MODIFY `id_proyek` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `estimasi`
--
ALTER TABLE `estimasi`
  ADD CONSTRAINT `fk_estimasi_jenis` FOREIGN KEY (`id_jp`) REFERENCES `jenis_pekerjaan` (`id_jp`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_estimasi_user` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `estimasi_detail`
--
ALTER TABLE `estimasi_detail`
  ADD CONSTRAINT `fk_detail_estimasi` FOREIGN KEY (`id_estimasi`) REFERENCES `estimasi` (`id_estimasi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detail_material` FOREIGN KEY (`id_material`) REFERENCES `material` (`id_material`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints for table `follow_up`
--
ALTER TABLE `follow_up`
  ADD CONSTRAINT `fk_fu_admin` FOREIGN KEY (`id_user_admin`) REFERENCES `users` (`id_user`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_fu_estimasi` FOREIGN KEY (`id_estimasi`) REFERENCES `estimasi` (`id_estimasi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_fu_proyek` FOREIGN KEY (`id_proyek`) REFERENCES `proyek` (`id_proyek`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `master_harga`
--
ALTER TABLE `master_harga`
  ADD CONSTRAINT `fk_harga_material` FOREIGN KEY (`id_material`) REFERENCES `material` (`id_material`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints for table `material`
--
ALTER TABLE `material`
  ADD CONSTRAINT `fk_material_jenis` FOREIGN KEY (`id_jp`) REFERENCES `jenis_pekerjaan` (`id_jp`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints for table `proyek`
--
ALTER TABLE `proyek`
  ADD CONSTRAINT `fk_proyek_estimasi` FOREIGN KEY (`id_estimasi`) REFERENCES `estimasi` (`id_estimasi`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_proyek_tukang` FOREIGN KEY (`id_tukang`) REFERENCES `users` (`id_user`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_proyek_user` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE RESTRICT ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
