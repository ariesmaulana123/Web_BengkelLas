<?php

/**
 * Root index.php proxy to public/index.php for Laragon / Apache convenience
 */
require __DIR__ . '/public/index.php';

