/**
 * Sentosa Jaya Las - Vanilla JavaScript
 * Clean, Modular, and Feature-Complete
 */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // ==========================================
  // 1. CONFIGURATION & CONSTANTS
  // ==========================================
  const DEFAULT_WHATSAPP_CONFIG = {
    phone: '6287766364557', // Format internasional tanpa simbol + (contoh: 6281234567890)
    defaultMessage: 'Halo Sentosa Jaya Las, saya ingin konsultasi mengenai kebutuhan fabrikasi besi / konstruksi.',
  };
  const WHATSAPP_CONFIG = {
    ...DEFAULT_WHATSAPP_CONFIG,
    ...(window.WHATSAPP_CONFIG || {}),
  };

  // ==========================================
  // 2. WHATSAPP FLOATING BUTTON HANDLER
  // ==========================================
  const waBtn = document.getElementById('floating-wa-btn');
  if (waBtn) {
    waBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const message = encodeURIComponent(WHATSAPP_CONFIG.defaultMessage);
      const waUrl = `https://wa.me/${WHATSAPP_CONFIG.phone}?text=${message}`;
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    });
  }

  // ==========================================
  // 3. SCROLL PROGRESS BAR & NAVBAR SCROLL STATE
  // ==========================================
  const scrollProgress = document.getElementById('scroll-progress');
  const mainNavbar = document.getElementById('main-navbar');
  const backToTopBtn = document.getElementById('back-to-top');

  function updateScrollState() {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    
    // Progress Bar
    if (scrollProgress && docHeight > 0) {
      const scrollPercent = (scrollTop / docHeight) * 100;
      scrollProgress.style.width = `${scrollPercent}%`;
    }

    // Navbar state
    if (mainNavbar) {
      if (scrollTop > 50) {
        mainNavbar.classList.add('navbar-scrolled');
      } else {
        mainNavbar.classList.remove('navbar-scrolled');
      }
    }

    // Back to top button
    if (backToTopBtn) {
      if (scrollTop > 400) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    }
  }

  window.addEventListener('scroll', updateScrollState, { passive: true });
  updateScrollState();

  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', (e) => {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // ==========================================
  // 4. MOBILE MENU TOGGLE
  // ==========================================
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  const menuIconBars = document.getElementById('menu-icon-bars');
  const menuIconClose = document.getElementById('menu-icon-close');

  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', () => {
      const isHidden = mobileMenu.classList.contains('hidden');
      if (isHidden) {
        mobileMenu.classList.remove('hidden');
        if (menuIconBars) menuIconBars.classList.add('hidden');
        if (menuIconClose) menuIconClose.classList.remove('hidden');
      } else {
        mobileMenu.classList.add('hidden');
        if (menuIconBars) menuIconBars.classList.remove('hidden');
        if (menuIconClose) menuIconClose.classList.add('hidden');
      }
    });

    // Auto-close mobile menu on link click
    const mobileLinks = mobileMenu.querySelectorAll('a');
    mobileLinks.forEach((link) => {
      link.addEventListener('click', () => {
        mobileMenu.classList.add('hidden');
        if (menuIconBars) menuIconBars.classList.remove('hidden');
        if (menuIconClose) menuIconClose.classList.add('hidden');
      });
    });
  }

  // ==========================================
  // 5. ACTIVE NAV MENU (SCROLLSPY)
  // ==========================================
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('section[id]');

  function updateActiveNav() {
    const scrollY = window.scrollY + 120;

    sections.forEach((section) => {
      const sectionHeight = section.offsetHeight;
      const sectionTop = section.offsetTop;
      const sectionId = section.getAttribute('id');

      if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
        navLinks.forEach((link) => {
          if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }

  window.addEventListener('scroll', updateActiveNav, { passive: true });
  updateActiveNav();

  // ==========================================
  // 6. INTERSECTION OBSERVER REVEAL ANIMATION
  // ==========================================
  const revealElements = document.querySelectorAll('.reveal-fade-up, .reveal-fade-left, .reveal-fade-right, .reveal-zoom');
  
  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('reveal-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.12,
        rootMargin: '0px 0px -40px 0px',
      }
    );

    revealElements.forEach((el) => {
      el.classList.add('reveal-init');
      revealObserver.observe(el);
    });
  } else {
    // Fallback if IntersectionObserver is not supported
    revealElements.forEach((el) => el.classList.add('reveal-visible'));
  }

  // ==========================================
  // 7. COUNTER ANIMATION (ABOUT SECTION)
  // ==========================================
  const counterElements = document.querySelectorAll('.stat-counter');
  let countersAnimated = false;

  function runCounters() {
    counterElements.forEach((counter) => {
      const target = parseInt(counter.getAttribute('data-target'), 10) || 0;
      const duration = 2000; // ms
      const stepTime = 20;
      const steps = duration / stepTime;
      const increment = target / steps;
      let current = 0;

      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          counter.innerText = target.toLocaleString('id-ID');
          clearInterval(timer);
        } else {
          counter.innerText = Math.floor(current).toLocaleString('id-ID');
        }
      }, stepTime);
    });
  }

  const statsSection = document.getElementById('stats-wrapper');
  if (statsSection && 'IntersectionObserver' in window) {
    const statsObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !countersAnimated) {
            countersAnimated = true;
            runCounters();
          }
        });
      },
      { threshold: 0.25 }
    );
    statsObserver.observe(statsSection);
  }

  // ==========================================
  // 8. PORTFOLIO FILTER & LIGHTBOX
  // ==========================================
  const filterBtns = document.querySelectorAll('.portfolio-filter-btn');
  const portfolioItems = document.querySelectorAll('.portfolio-item');

  // Filter Buttons
  filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      const filter = btn.getAttribute('data-filter');

      // Update active button state
      filterBtns.forEach((b) => {
        b.classList.remove('bg-blue-600', 'text-white', 'shadow-lg', 'shadow-blue-500/25');
        b.classList.add('bg-slate-800/80', 'text-slate-300', 'hover:bg-slate-700');
      });
      btn.classList.add('bg-blue-600', 'text-white', 'shadow-lg', 'shadow-blue-500/25');
      btn.classList.remove('bg-slate-800/80', 'text-slate-300', 'hover:bg-slate-700');

      // Filter cards
      portfolioItems.forEach((item) => {
        const itemCategory = item.getAttribute('data-category');
        if (filter === 'all' || itemCategory === filter) {
          item.classList.remove('hidden-item');
          setTimeout(() => {
            item.style.opacity = '1';
            item.style.transform = 'scale(1)';
          }, 50);
        } else {
          item.style.opacity = '0';
          item.style.transform = 'scale(0.9)';
          setTimeout(() => {
            item.classList.add('hidden-item');
          }, 300);
        }
      });
    });
  });

  // Lightbox Modal
  const lightbox = document.getElementById('lightbox-modal');
  const lightboxImg = document.getElementById('lightbox-image');
  const lightboxTitle = document.getElementById('lightbox-title');
  const lightboxCategory = document.getElementById('lightbox-category');
  const lightboxClose = document.getElementById('lightbox-close');
  const lightboxPrev = document.getElementById('lightbox-prev');
  const lightboxNext = document.getElementById('lightbox-next');

  let currentGalleryIndex = 0;
  const galleryItems = [];

  portfolioItems.forEach((item, index) => {
    const img = item.querySelector('img');
    const title = item.querySelector('.portfolio-title')?.textContent || 'Proyek Sentosa Jaya Las';
    const category = item.querySelector('.portfolio-cat-badge')?.textContent || 'Fabrikasi Besi';
    const desc = item.querySelector('.portfolio-desc')?.textContent || '';

    if (img) {
      galleryItems.push({
        src: img.getAttribute('data-full') || img.getAttribute('src'),
        title: title.trim(),
        category: category.trim(),
        desc: desc.trim(),
      });

      const clickTrigger = item.querySelector('.portfolio-zoom-trigger') || item;
      clickTrigger.addEventListener('click', (e) => {
        e.preventDefault();
        openLightbox(index);
      });
    }
  });

  function openLightbox(index) {
    if (!lightbox || !galleryItems[index]) return;
    currentGalleryIndex = index;
    updateLightboxContent();
    lightbox.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    if (!lightbox) return;
    lightbox.classList.remove('active');
    document.body.style.overflow = '';
  }

  function updateLightboxContent() {
    const item = galleryItems[currentGalleryIndex];
    if (!item) return;

    if (lightboxImg) lightboxImg.src = item.src;
    if (lightboxTitle) lightboxTitle.textContent = item.title;
    if (lightboxCategory) lightboxCategory.textContent = item.category;
  }

  function showNextImage() {
    currentGalleryIndex = (currentGalleryIndex + 1) % galleryItems.length;
    updateLightboxContent();
  }

  function showPrevImage() {
    currentGalleryIndex = (currentGalleryIndex - 1 + galleryItems.length) % galleryItems.length;
    updateLightboxContent();
  }

  if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);
  if (lightboxNext) lightboxNext.addEventListener('click', showNextImage);
  if (lightboxPrev) lightboxPrev.addEventListener('click', showPrevImage);

  if (lightbox) {
    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox || e.target.classList.contains('lightbox-backdrop')) {
        closeLightbox();
      }
    });
  }

  // Keyboard navigation for lightbox
  document.addEventListener('keydown', (e) => {
    if (!lightbox || !lightbox.classList.contains('active')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowRight') showNextImage();
    if (e.key === 'ArrowLeft') showPrevImage();
  });

  // ==========================================
  // 9. FAQ ACCORDION
  // ==========================================
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach((item) => {
    const button = item.querySelector('.faq-button');
    if (button) {
      button.addEventListener('click', () => {
        const isActive = item.classList.contains('active');

        // Close other FAQs
        faqItems.forEach((other) => {
          if (other !== item) {
            other.classList.remove('active');
            const otherBtn = other.querySelector('.faq-button');
            if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
          }
        });

        // Toggle current FAQ
        if (isActive) {
          item.classList.remove('active');
          button.setAttribute('aria-expanded', 'false');
        } else {
          item.classList.add('active');
          button.setAttribute('aria-expanded', 'true');
        }
      });
    }
  });

  // ==========================================
  // 10. TESTIMONIAL CAROUSEL & CLIENT RATING
  // ==========================================
  const carouselTrack = document.getElementById('testimonials-track');
  const prevSlideBtn = document.getElementById('testi-prev-btn');
  const nextSlideBtn = document.getElementById('testi-next-btn');
  const dotsContainer = document.getElementById('testi-dots');
  const ratingForm = document.getElementById('client-rating-form');
  const ratingButtons = document.querySelectorAll('.rating-star-btn');
  const ratingValueInput = document.getElementById('client-rating-value');
  const ratingText = document.getElementById('client-rating-text');
  const ratingSuccess = document.getElementById('rating-success-alert');

  function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = String(value || '');
    return div.innerHTML;
  }

  function createStarIcons(rating) {
    const activeRating = Math.max(1, Math.min(5, Number(rating) || 5));
    return Array.from({ length: 5 }, (_, index) => {
      const colorClass = index < activeRating ? 'text-amber-400' : 'text-slate-700';
      return `
        <svg class="w-5 h-5 fill-current ${colorClass}" viewBox="0 0 20 20" aria-hidden="true">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
        </svg>
      `;
    }).join('');
  }

  function getInitials(name) {
    const parts = String(name || 'SJ').trim().split(/\s+/).filter(Boolean);
    const letters = parts.slice(0, 2).map((part) => part.charAt(0).toUpperCase()).join('');
    return letters || 'SJ';
  }

  function createTestimonialSlide(testimonial) {
    const rating = Math.max(1, Math.min(5, Number(testimonial.rating) || 5));
    const name = testimonial.name || 'Klien Sentosa Jaya';
    const project = testimonial.project || 'Proyek Bengkel Las';
    const message = testimonial.message || '';
    const id = testimonial.id || `rating-${Date.now()}`;

    return `
      <div class="testi-slide w-full shrink-0 px-2 sm:px-6 space-y-6" data-testimonial-id="${escapeHtml(id)}">
        <div class="flex items-center space-x-1">
          ${createStarIcons(rating)}
        </div>

        <p class="text-base sm:text-xl text-slate-200 italic leading-relaxed font-light">
          "${escapeHtml(message)}"
        </p>

        <div class="flex items-center space-x-4 pt-4 border-t border-slate-800">
          <div class="w-12 h-12 rounded-full bg-emerald-600 flex items-center justify-center text-white font-bold text-base">
            ${escapeHtml(getInitials(name))}
          </div>
          <div>
            <h4 class="text-base font-bold text-white">${escapeHtml(name)}</h4>
            <p class="text-xs text-slate-400">Klien Sentosa Jaya Las</p>
            <span class="text-[11px] text-emerald-400 font-semibold">Proyek: ${escapeHtml(project)}</span>
          </div>
        </div>
      </div>
    `;
  }

  let appendClientTestimonial = () => {};

  if (carouselTrack) {
    let slides = [];
    let totalSlides = 0;
    let currentSlide = 0;
    let autoSlideInterval = null;

    function refreshSlides() {
      slides = Array.from(carouselTrack.querySelectorAll('.testi-slide'));
      totalSlides = slides.length;
      if (currentSlide >= totalSlides) currentSlide = Math.max(totalSlides - 1, 0);
    }

    function updateSlide() {
      refreshSlides();
      if (totalSlides === 0) return;

      carouselTrack.style.transform = `translateX(-${currentSlide * 100}%)`;

      if (dotsContainer) {
        const dots = dotsContainer.querySelectorAll('button');
        dots.forEach((dot, idx) => {
          if (idx === currentSlide) {
            dot.className = 'w-8 h-3 rounded-full bg-blue-600 transition-all duration-300';
          } else {
            dot.className = 'w-3 h-3 rounded-full bg-slate-600 hover:bg-slate-400 transition-all duration-300';
          }
        });
      }
    }

    function goToSlide(index) {
      refreshSlides();
      if (totalSlides === 0) return;

      currentSlide = (index + totalSlides) % totalSlides;
      updateSlide();
    }

    function renderDots() {
      refreshSlides();
      if (!dotsContainer) return;

      dotsContainer.innerHTML = '';
      slides.forEach((_, index) => {
        const dot = document.createElement('button');
        dot.setAttribute('aria-label', `Slide ke ${index + 1}`);
        dot.className = index === currentSlide
          ? 'w-8 h-3 rounded-full bg-blue-600 transition-all duration-300'
          : 'w-3 h-3 rounded-full bg-slate-600 hover:bg-slate-400 transition-all duration-300';
        dot.addEventListener('click', () => goToSlide(index));
        dotsContainer.appendChild(dot);
      });
    }

    function rebuildCarousel(targetIndex = currentSlide) {
      refreshSlides();
      currentSlide = Math.max(0, Math.min(targetIndex, totalSlides - 1));
      renderDots();
      updateSlide();
    }

    function nextSlide() {
      goToSlide(currentSlide + 1);
    }

    function prevSlide() {
      goToSlide(currentSlide - 1);
    }

    appendClientTestimonial = (testimonial) => {
      if (!testimonial || !testimonial.message) return;

      const id = testimonial.id || '';
      const alreadyExists = id && Array.from(carouselTrack.querySelectorAll('.testi-slide'))
        .some((slide) => slide.dataset.testimonialId === id);

      if (alreadyExists) {
        return;
      }

      carouselTrack.insertAdjacentHTML('beforeend', createTestimonialSlide(testimonial));
      refreshSlides();
      rebuildCarousel(totalSlides - 1);
    };

    if (nextSlideBtn) nextSlideBtn.addEventListener('click', nextSlide);
    if (prevSlideBtn) prevSlideBtn.addEventListener('click', prevSlide);

    function startAutoSlide() {
      stopAutoSlide();
      refreshSlides();
      if (totalSlides > 1) {
        autoSlideInterval = setInterval(nextSlide, 5000);
      }
    }

    function stopAutoSlide() {
      if (autoSlideInterval) clearInterval(autoSlideInterval);
    }

    rebuildCarousel(0);
    startAutoSlide();

    const carouselWrapper = document.getElementById('testimonials-wrapper');
    if (carouselWrapper) {
      carouselWrapper.addEventListener('mouseenter', stopAutoSlide);
      carouselWrapper.addEventListener('mouseleave', startAutoSlide);
    }

    let startX = 0;
    let endX = 0;

    carouselTrack.addEventListener('touchstart', (e) => {
      startX = e.touches[0].clientX;
    }, { passive: true });

    carouselTrack.addEventListener('touchend', (e) => {
      endX = e.changedTouches[0].clientX;
      const diff = startX - endX;
      if (Math.abs(diff) > 50) {
        if (diff > 0) nextSlide();
        else prevSlide();
      }
    }, { passive: true });
  }

  function setClientRating(rating) {
    const value = Math.max(1, Math.min(5, Number(rating) || 5));
    const labels = {
      1: '1 dari 5 - Perlu banyak perbaikan',
      2: '2 dari 5 - Kurang puas',
      3: '3 dari 5 - Cukup',
      4: '4 dari 5 - Puas',
      5: '5 dari 5 - Sangat puas',
    };

    if (ratingValueInput) ratingValueInput.value = String(value);
    if (ratingText) ratingText.textContent = labels[value];

    ratingButtons.forEach((button) => {
      const buttonValue = Number(button.dataset.ratingValue || 0);
      const isActive = buttonValue <= value;
      button.classList.toggle('text-amber-400', isActive);
      button.classList.toggle('text-slate-600', !isActive);
      button.setAttribute('aria-pressed', buttonValue === value ? 'true' : 'false');
    });
  }

  ratingButtons.forEach((button) => {
    button.addEventListener('click', () => setClientRating(button.dataset.ratingValue));
  });
  setClientRating(ratingValueInput ? ratingValueInput.value : 5);

  if (ratingForm) {
    ratingForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const submitBtn = ratingForm.querySelector('button[type="submit"]');
      const originalSubmitHtml = submitBtn ? submitBtn.innerHTML : '';
      const payload = {
        rating: Number(ratingValueInput ? ratingValueInput.value : 5),
        name: (document.getElementById('client-reviewer-name')?.value || '').trim(),
        project: (document.getElementById('client-reviewer-project')?.value || '').trim(),
        message: (document.getElementById('client-reviewer-message')?.value || '').trim(),
        website: (document.getElementById('client-rating-website')?.value || '').trim(),
      };

      if (!payload.name || !payload.project || !payload.message) {
        alert('Mohon lengkapi nama, proyek/lokasi, dan ulasan.');
        return;
      }

      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `
          <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Menyimpan Rating...
        `;
      }

      try {
        const baseUrl = (window.BASE_URL || window.location.origin).replace(/\/+$/, '');
        const response = await fetch(`${baseUrl}/rating-bengkel`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
          },
          body: JSON.stringify(payload),
        });
        const result = await response.json();

        if (!response.ok || result.status !== 'success') {
          throw new Error(result.message || 'Rating belum berhasil disimpan.');
        }

        if (result.data) {
          appendClientTestimonial(result.data);
        }

        if (ratingSuccess) {
          ratingSuccess.textContent = result.message || 'Terima kasih, rating Anda sudah ditambahkan ke Testimoni Klien.';
          ratingSuccess.classList.remove('hidden');
        }

        ratingForm.reset();
        setClientRating(5);

        const testimonialsSection = document.getElementById('testimoni');
        if (testimonialsSection) {
          setTimeout(() => testimonialsSection.scrollIntoView({ behavior: 'smooth', block: 'start' }), 250);
        }
      } catch (error) {
        alert(error.message || 'Rating belum berhasil disimpan. Silakan coba lagi.');
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalSubmitHtml;
        }
      }
    });
  }

  // ==========================================
  // 11. CONTACT FORM HANDLER
  // ==========================================
  const contactForm = document.getElementById('contact-form');
  const formSuccess = document.getElementById('form-success-alert');
  const formWaDirectLink = document.getElementById('form-wa-direct-link');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const nameInput = document.getElementById('contact-name');
      const phoneInput = document.getElementById('contact-phone');
      const serviceInput = document.getElementById('contact-service');
      const locationInput = document.getElementById('contact-location');
      const noteInput = document.getElementById('contact-note');
      const submitBtn = contactForm.querySelector('button[type="submit"]');

      const name = nameInput ? nameInput.value.trim() : '';
      const phone = phoneInput ? phoneInput.value.trim() : '';
      const service = serviceInput ? serviceInput.value : 'Pekerjaan Besi';
      const location = locationInput ? locationInput.value : 'Bekasi & Sekitarnya';
      const note = noteInput ? noteInput.value.trim() : '-';

      if (!name || !phone) {
        alert('Mohon lengkapi nama dan nomor telepon Anda.');
        return;
      }

      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `
          <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Memproses Pesan...
        `;
      }

      // Generate structured WhatsApp Message
      const formattedMessage = `Halo Sentosa Jaya Las, saya ingin konsultasi & meminta estimasi RAB:
- Nama: ${name}
- No. HP: ${phone}
- Layanan: ${service}
- Lokasi: ${location}
- Catatan Kebutuhan: ${note || '-'}`;

      if (formWaDirectLink) {
        const waUrl = `https://wa.me/${WHATSAPP_CONFIG.phone}?text=${encodeURIComponent(formattedMessage)}`;
        formWaDirectLink.setAttribute('href', waUrl);
      }

      // Simulate sending and show success alert
      setTimeout(() => {
        if (formSuccess) {
          formSuccess.classList.remove('hidden');
          formSuccess.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        contactForm.reset();
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = `
            <span>Kirim Permintaan Estimasi & RAB</span>
            <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
            </svg>
          `;
        }
      }, 700);
    });
  }

  // ==========================================
  // 12. ESTIMATION CALCULATOR & SURVEY BOOKING
  // ==========================================
  const getBaseUrl = () => {
    if (window.BASE_URL) return window.BASE_URL.replace(/\/+$/, '');
    const path = window.location.pathname;
    if (path.includes('/public')) {
      const publicIndex = path.indexOf('/public');
      return window.location.origin + path.substring(0, publicIndex + 7);
    }
    const match = path.match(/^(\/[^\/]+)/);
    if (match && match[1] && match[1] !== '/login' && match[1] !== '/register') {
      return window.location.origin + match[1];
    }
    return window.location.origin;
  };
  const BASE_URL = getBaseUrl();

  const calcForm = document.getElementById('calculator-form');
  const calcJpSelect = document.getElementById('calc-jp');
  const kanopiFields = document.getElementById('kanopi-specific-fields');
  const generalField = document.getElementById('general-material-field');
  const calcRangkaSelect = document.getElementById('calc-mat-rangka');
  const calcAtapSelect = document.getElementById('calc-mat-atap');
  const calcUtamaSelect = document.getElementById('calc-mat-utama');
  const generalDimensions = document.getElementById('general-dimension-fields');
  const teralisFields = document.getElementById('teralis-specific-fields');
  const teralisItems = document.getElementById('teralis-items');
  const addTeralisItem = document.getElementById('add-teralis-item');
  const calcErrorAlert = document.getElementById('calc-error-alert');
  const calcErrorText = document.getElementById('calc-error-text');

  const calcPlaceholder = document.getElementById('calc-result-placeholder');
  const calcResultCard = document.getElementById('calc-result-card');
  const calcSaveSurveyBtn = document.getElementById('calc-save-survey-btn');

  function formatRupiah(number) {
    return new Intl.NumberFormat('id-ID', {
      style: 'decimal',
      maximumFractionDigits: 0
    }).format(number);
  }

  function showCalcError(msg) {
    if (calcErrorAlert && calcErrorText) {
      calcErrorText.textContent = msg;
      calcErrorAlert.classList.remove('hidden');
      calcErrorAlert.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else {
      alert(msg);
    }
  }

  function hideCalcError() {
    if (calcErrorAlert) calcErrorAlert.classList.add('hidden');
  }

  function addTeralisRow(materials) {
    if (!teralisItems) return;
    const row = document.createElement('div');
    row.className = 'teralis-item grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-950/70 border border-slate-800';
    row.innerHTML = `
      <div>
        <label class="block mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Lebar (m)</label>
        <input type="number" class="teralis-lebar w-full px-3 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white text-sm" min="0.01" step="0.01" placeholder="Contoh: 1.20">
      </div>
      <div>
        <label class="block mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Tinggi (m)</label>
        <input type="number" class="teralis-tinggi w-full px-3 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white text-sm" min="0.01" step="0.01" placeholder="Contoh: 1.50">
      </div>
      <div>
        <label class="block mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Jumlah unit</label>
        <input type="number" class="teralis-qty w-full px-3 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white text-sm" min="1" step="1" value="1" placeholder="Contoh: 2">
      </div>
      <div>
        <label class="block mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Jarak jeruji (cm)</label>
        <input type="number" class="teralis-jarak w-full px-3 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white text-sm" min="3" step="0.5" value="8" placeholder="Contoh: 8">
      </div>
      <div class="lg:col-span-3">
        <label class="block mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Jenis besi</label>
        <select class="teralis-material w-full px-3 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-white text-sm"></select>
      </div>
      <div class="flex items-end">
        <button type="button" class="remove-teralis-item w-full px-3 py-2.5 rounded-lg bg-rose-950/50 text-rose-300 border border-rose-900/50 text-sm font-semibold" title="Hapus ukuran">Hapus ukuran</button>
      </div>`;

    const materialSelect = row.querySelector('.teralis-material');
    materials.filter(m => m.kategori !== 'jasa' && m.kategori !== 'tiang').forEach(m => {
      const option = document.createElement('option');
      option.value = m.id_material;
      option.textContent = `${m.nama_material} (Rp ${formatRupiah(m.harga)} / ${m.satuan})`;
      materialSelect.appendChild(option);
    });
    row.querySelector('.remove-teralis-item').addEventListener('click', () => {
      if (teralisItems.children.length > 1) row.remove();
    });
    teralisItems.appendChild(row);
  }

  // Handle Jenis Pekerjaan Selection Change
  if (calcJpSelect) {
    calcJpSelect.addEventListener('change', async (e) => {
      const idJp = e.target.value;
      const selectedOption = e.target.options[e.target.selectedIndex];
      const jpName = (selectedOption ? selectedOption.getAttribute('data-nama') : '') || '';

      hideCalcError();

      if (!idJp) return;

      // Show loading options
      if (calcRangkaSelect) calcRangkaSelect.innerHTML = '<option value="" disabled selected>Memuat Rangka...</option>';
      if (calcAtapSelect) calcAtapSelect.innerHTML = '<option value="" disabled selected>Memuat Atap...</option>';
      if (calcUtamaSelect) calcUtamaSelect.innerHTML = '<option value="" disabled selected>Memuat Material...</option>';

      try {
        const response = await fetch(`${BASE_URL}/kalkulator/materials/${idJp}`, {
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const result = await response.json();

        if (result.status !== 'success' || !Array.isArray(result.data)) {
          showCalcError('Gagal memuat daftar material dari database.');
          return;
        }

        const materials = result.data;

        if (jpName.includes('kanopi')) {
          if (kanopiFields) kanopiFields.classList.remove('hidden');
          if (generalField) generalField.classList.add('hidden');
          if (teralisFields) teralisFields.classList.add('hidden');
          if (generalDimensions) generalDimensions.classList.remove('hidden');

          // Populate Rangka
          const rangkaList = materials.filter(m => m.kategori === 'rangka');
          if (calcRangkaSelect) {
            calcRangkaSelect.innerHTML = '<option value="" disabled selected>-- Pilih Jenis Rangka --</option>';
            rangkaList.forEach(m => {
              const opt = document.createElement('option');
              opt.value = m.id_material;
              opt.textContent = `${m.nama_material} (Rp ${formatRupiah(m.harga)} / ${m.satuan})`;
              calcRangkaSelect.appendChild(opt);
            });
            if (rangkaList.length > 0) calcRangkaSelect.selectedIndex = 1;
          }

          // Populate Atap
          const atapList = materials.filter(m => m.kategori === 'atap');
          if (calcAtapSelect) {
            calcAtapSelect.innerHTML = '<option value="" disabled selected>-- Pilih Jenis Atap --</option>';
            atapList.forEach(m => {
              const opt = document.createElement('option');
              opt.value = m.id_material;
              opt.textContent = `${m.nama_material} (Rp ${formatRupiah(m.harga)} / ${m.satuan})`;
              calcAtapSelect.appendChild(opt);
            });
            if (atapList.length > 0) calcAtapSelect.selectedIndex = 1;
          }

        } else {
          if (kanopiFields) kanopiFields.classList.add('hidden');
          if (jpName.includes('teralis') || jpName.includes('tralis')) {
            if (generalField) generalField.classList.add('hidden');
            if (teralisFields) teralisFields.classList.remove('hidden');
            if (generalDimensions) generalDimensions.classList.add('hidden');
            if (teralisItems) {
              teralisItems.innerHTML = '';
              addTeralisRow(materials);
            }
          } else {
            if (generalField) generalField.classList.remove('hidden');
            if (teralisFields) teralisFields.classList.add('hidden');
            if (generalDimensions) generalDimensions.classList.remove('hidden');
          }

          // Populate general material (non-jasa)
          const matList = materials.filter(m => m.kategori !== 'jasa' && m.kategori !== 'tiang');
          if (calcUtamaSelect) {
            calcUtamaSelect.innerHTML = '<option value="" disabled selected>-- Pilih Material / Model --</option>';
            matList.forEach(m => {
              const opt = document.createElement('option');
              opt.value = m.id_material;
              opt.textContent = `${m.nama_material} (Rp ${formatRupiah(m.harga)} / ${m.satuan})`;
              calcUtamaSelect.appendChild(opt);
            });
            if (matList.length > 0) calcUtamaSelect.selectedIndex = 1;
          }
        }

      } catch (err) {
        showCalcError('Terjadi kesalahan koneksi saat memuat material: ' + err.message);
      }
    });

    if (addTeralisItem) {
      addTeralisItem.addEventListener('click', () => {
        const options = [...(calcUtamaSelect?.options || [])].slice(1).map(option => ({
          id_material: option.value,
          nama_material: option.textContent,
          harga: 0,
          satuan: ''
        }));
        addTeralisRow(options);
      });
    }

    // Auto trigger change if initial option selected
    if (calcJpSelect.value) {
      calcJpSelect.dispatchEvent(new Event('change'));
    }
  }

  // Handle Calculation Submission
  let lastCalcPayload = null;

  if (calcForm) {
    calcForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      hideCalcError();

      const submitBtn = document.getElementById('calc-submit-btn');
      const iconNormal = document.getElementById('calc-icon-normal');
      const iconLoading = document.getElementById('calc-icon-loading');
      const btnText = document.getElementById('calc-btn-text');

      const idJp = calcJpSelect ? parseInt(calcJpSelect.value, 10) : 0;
      const panjang = parseFloat(document.getElementById('calc-panjang')?.value) || 0;
      const lebar = parseFloat(document.getElementById('calc-lebar')?.value) || 0;
      const tinggiVal = document.getElementById('calc-tinggi')?.value;
      const tinggi = tinggiVal !== '' && tinggiVal !== undefined ? parseFloat(tinggiVal) : null;
      const catatan = document.getElementById('calc-catatan')?.value || '';

      const idRangka = calcRangkaSelect ? calcRangkaSelect.value : null;
      const idAtap = calcAtapSelect ? calcAtapSelect.value : null;
      const idUtama = calcUtamaSelect ? calcUtamaSelect.value : null;
      const selectedOption = calcJpSelect.options[calcJpSelect.selectedIndex];
      const jpName = (selectedOption ? selectedOption.getAttribute('data-nama') : '') || '';
      const isTeralis = jpName.includes('teralis') || jpName.includes('tralis');

      const payload = {
        id_jp: idJp,
        panjang: panjang,
        lebar: lebar,
        tinggi: tinggi,
        id_material_rangka: idRangka ? parseInt(idRangka, 10) : null,
        id_material_atap: idAtap ? parseInt(idAtap, 10) : null,
        id_material_utama: idUtama ? parseInt(idUtama, 10) : null,
        catatan: catatan.trim()
      };

      // Client validation
      if (!idJp) {
        showCalcError('Silakan pilih jenis pekerjaan terlebih dahulu.');
        return;
      }
      if (!isTeralis && (panjang <= 0 || lebar <= 0)) {
        showCalcError('Panjang dan lebar harus lebih besar dari 0 meter.');
        return;
      }
      const luas = panjang * lebar;
      if (!isTeralis && luas < 2.0) {
        showCalcError(`Luas pengerjaan (${luas.toFixed(2)} m²) kurang dari batas minimal 2.00 m².`);
        return;
      }

      if (isTeralis) {
        const items = [...(teralisItems?.querySelectorAll('.teralis-item') || [])].map(row => ({
          lebar: parseFloat(row.querySelector('.teralis-lebar')?.value) || 0,
          tinggi: parseFloat(row.querySelector('.teralis-tinggi')?.value) || 0,
          qty_unit: parseInt(row.querySelector('.teralis-qty')?.value, 10) || 1,
          jarak_jeruji: parseFloat(row.querySelector('.teralis-jarak')?.value) || 8,
          id_material_utama: parseInt(row.querySelector('.teralis-material')?.value, 10) || 0
        }));
        if (!items.length || items.some(item => item.lebar <= 0 || item.tinggi <= 0 || item.id_material_utama <= 0)) {
          showCalcError('Lengkapi lebar, tinggi, unit, jarak jeruji, dan jenis besi setiap item teralis.');
          return;
        }
        payload.items = items;
        payload.qty_unit = items.reduce((total, item) => total + item.qty_unit, 0);
      } else if (jpName.includes('kanopi')) {
        if (!idRangka || !idAtap) {
          showCalcError('Silakan pilih jenis rangka dan jenis atap untuk kanopi.');
          return;
        }
      } else {
        if (!idUtama) {
          showCalcError('Silakan pilih jenis material/model pengerjaan.');
          return;
        }
      }

      // Set Loading State
      if (submitBtn) {
        submitBtn.disabled = true;
        if (iconNormal) iconNormal.classList.add('hidden');
        if (iconLoading) iconLoading.classList.remove('hidden');
        if (btnText) btnText.textContent = 'Menghitung via Python...';
      }

      try {
        const response = await fetch(`${BASE_URL}/kalkulator/hitung`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: JSON.stringify(payload)
        });

        const resJson = await response.json();

        if (response.status === 401) {
          window.location.href = resJson.redirect || `${BASE_URL}/login`;
          return;
        }

        if (resJson.status !== 'success') {
          showCalcError(resJson.message || 'Gagal menghitung estimasi.');
          return;
        }

        const data = resJson.data;
        lastCalcPayload = payload;

        // Render Results into Card
        document.getElementById('res-nama-pekerjaan').textContent = data.nama_jp;
        document.getElementById('res-luas').textContent = `${parseFloat(data.luas).toFixed(2)} m²`;
        document.getElementById('res-subtotal').textContent = `Rp ${formatRupiah(data.subtotal)}`;
        document.getElementById('res-range').textContent = `Rp ${formatRupiah(data.estimasi_min)} - Rp ${formatRupiah(data.estimasi_max)}`;
        
        // Breakdown Table
        const tbody = document.getElementById('res-breakdown-body');
        tbody.innerHTML = '';
        if (Array.isArray(data.breakdown)) {
          data.breakdown.forEach(item => {
            const tr = document.createElement('tr');
            tr.className = 'hover:bg-slate-900/50 transition-colors';
            
            const badgeClass = item.kategori === 'jasa' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-blue-500/10 text-blue-400 border-blue-500/20';

            tr.innerHTML = `
              <td class="py-2.5 px-3 font-medium text-white flex items-center space-x-1.5">
                <span class="inline-block px-1.5 py-0.5 rounded text-[9px] font-mono uppercase border ${badgeClass}">${item.kategori}</span>
                <span>${item.nama_material}</span>
              </td>
              <td class="py-2.5 px-2 text-center font-mono">${parseFloat(item.qty).toFixed(1)} ${item.satuan}</td>
              <td class="py-2.5 px-3 text-right font-mono text-slate-400">Rp ${formatRupiah(item.harga)}</td>
              <td class="py-2.5 px-3 text-right font-bold font-mono text-slate-100">Rp ${formatRupiah(item.subtotal)}</td>
            `;
            tbody.appendChild(tr);
          });
        }

        // Catatan
        const resCatatanWrapper = document.getElementById('res-catatan-wrapper');
        const resCatatanText = document.getElementById('res-catatan-text');
        if (data.catatan && data.catatan.trim()) {
          resCatatanText.textContent = data.catatan;
          resCatatanWrapper.classList.remove('hidden');
        } else {
          resCatatanWrapper.classList.add('hidden');
        }

        // Disclaimer
        if (data.disclaimer) {
          document.getElementById('res-disclaimer').textContent = data.disclaimer;
        }

        // Show result card
        if (calcPlaceholder) calcPlaceholder.classList.add('hidden');
        if (calcResultCard) {
          calcResultCard.classList.remove('hidden');
          calcResultCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

      } catch (err) {
        showCalcError('Terjadi kesalahan saat memproses kalkulasi: ' + err.message);
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          if (iconNormal) iconNormal.classList.remove('hidden');
          if (iconLoading) iconLoading.classList.add('hidden');
          if (btnText) btnText.textContent = 'Hitung Estimasi';
        }
      }
    });
  }

  // Handle Save Estimate Button
  if (calcSaveSurveyBtn) {
    calcSaveSurveyBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      if (!lastCalcPayload) {
        showCalcError('Silakan lakukan perhitungan estimasi terlebih dahulu.');
        return;
      }

      calcSaveSurveyBtn.disabled = true;
      calcSaveSurveyBtn.innerHTML = `
        <svg class="animate-spin -ml-1 mr-2 h-5 w-5 text-white inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <span>Menyimpan & Menghubungkan...</span>
      `;

      try {
        const response = await fetch(`${BASE_URL}/kalkulator/simpan`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: JSON.stringify(lastCalcPayload)
        });

        const resJson = await response.json();

        if (resJson.status !== 'success') {
          showCalcError(resJson.message || 'Gagal menyimpan estimasi.');
          calcSaveSurveyBtn.disabled = false;
          calcSaveSurveyBtn.innerHTML = `
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            <span>Simpan Estimasi</span>
          `;
          return;
        }

        window.location.href = resJson.redirect || `${BASE_URL}/riwayat`;

      } catch (err) {
        showCalcError('Terjadi kesalahan jaringan saat menyimpan estimasi: ' + err.message);
        calcSaveSurveyBtn.disabled = false;
        calcSaveSurveyBtn.innerHTML = `
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
          <span>Simpan Estimasi</span>
        `;
      }
    });
  }
});


