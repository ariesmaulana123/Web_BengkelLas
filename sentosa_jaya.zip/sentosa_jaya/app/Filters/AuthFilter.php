<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        if (!$session->get('isLoggedIn')) {
            if ($request->isAJAX()) {
                return service('response')->setJSON([
                    'status'   => 'unauthorized',
                    'message'  => 'Silakan login terlebih dahulu untuk menggunakan fitur kalkulator dan mengajukan survey.',
                    'redirect' => base_url('login')
                ])->setStatusCode(401);
            }

            return redirect()->to(base_url('login'))->with('error', 'Silakan login terlebih dahulu untuk mengakses kalkulator.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do nothing
    }
}

