<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AdminFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();

        // 1. Cek Login
        if (!$session->get('isLoggedIn')) {
            if ($request->isAJAX()) {
                return service('response')->setJSON([
                    'status'   => 'unauthorized',
                    'message'  => 'Sesi Anda telah berakhir. Silakan login kembali.',
                    'redirect' => base_url('login')
                ])->setStatusCode(401);
            }

            return redirect()->to(base_url('login'))->with('error', 'Silakan login sebagai Admin atau Tim untuk mengakses panel ini.');
        }

        $role = $session->get('role');

        // 2. Cegah Customer biasa masuk ke Panel Admin
        if ($role === 'customer') {
            if ($request->isAJAX()) {
                return service('response')->setJSON([
                    'status'   => 'forbidden',
                    'message'  => 'Akses ditolak. Halaman ini hanya untuk Administrator dan Tim Teknis.'
                ])->setStatusCode(403);
            }

            return redirect()->to(base_url('/#kalkulator'))->with('error', 'Akses Ditolak: Anda tidak memiliki izin untuk membuka halaman Admin.');
        }

        // 3. Batasi Hak Akses Role "tukang"
        if ($role === 'tukang') {
            $uri = $request->getUri()->getPath(); // e.g. "admin/scm/harga", "sentosa_jaya/public/admin/scm/harga"
            
            $restrictedPatterns = [
                'admin/scm',
                'admin/users',
                'admin/pengaturan',
                'admin/crm/estimasi',
                'admin/crm/customer',
                'admin/laporan',
            ];

            foreach ($restrictedPatterns as $pattern) {
                if (str_contains($uri, $pattern)) {
                    if ($request->isAJAX()) {
                        return service('response')->setJSON([
                            'status'  => 'forbidden',
                            'message' => 'Akses Ditolak: Anda tidak memiliki izin untuk mengakses menu atau data ini.'
                        ])->setStatusCode(403);
                    }

                    return redirect()->to(base_url('admin/crm/proyek'))
                        ->with('error', 'Akses Ditolak: Anda tidak memiliki izin untuk mengakses menu tersebut.');
                }
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do nothing
    }
}