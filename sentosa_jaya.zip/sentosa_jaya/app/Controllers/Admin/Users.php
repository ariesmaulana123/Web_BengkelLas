<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseAdminController;

class Users extends BaseAdminController
{
    public function index()
    {
        $roleFilter = $this->request->getGet('role');
        $search = $this->request->getGet('q');

        $builder = $this->userModel->select('*');
        if ($roleFilter) {
            $builder->where('role', $roleFilter);
        }
        if ($search) {
            $builder->groupStart()
                ->like('nama', $search)
                ->orLike('email', $search)
                ->orLike('no_wa', $search)
                ->groupEnd();
        }
        $users = $builder->orderBy('role', 'ASC')->orderBy('nama', 'ASC')->findAll();

        $data = [
            'title'        => 'Manajemen Role & Hak Akses Pengguna',
            'pageTitle'    => 'Pengguna & Hak Akses Sistem',
            'pageSubtitle' => 'Kelola akun tim internal (Admin, Tukang) dan otorisasi hak akses pengguna.',
            'users'        => $users,
            'roleFilter'   => $roleFilter,
            'search'       => $search,
        ];

        return $this->renderAdmin('admin/users/index', $data);
    }

    public function store()
    {
        $rules = [
            'nama'     => 'required|min_length[3]|max_length[100]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'no_wa'    => 'required|min_length[8]|max_length[20]|is_unique[users.no_wa]',
            'password' => 'required|min_length[6]',
            'role'     => 'required|in_list[admin,tukang,customer]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Validasi gagal. Pastikan email & nomor WA unik serta password minimal 6 karakter.');
        }

        $this->userModel->insert([
            'nama'     => trim($this->request->getPost('nama')),
            'email'    => trim($this->request->getPost('email')),
            'no_wa'    => trim($this->request->getPost('no_wa')),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
            'role'     => $this->request->getPost('role'),
        ]);

        return redirect()->to(base_url('admin/users'))->with('success', 'Akun pengguna baru berhasil ditambahkan!');
    }

    public function update($id)
    {
        $id = (int) $id;
        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to(base_url('admin/users'))->with('error', 'Pengguna tidak ditemukan.');
        }

        $rules = [
            'nama'  => 'required|min_length[3]|max_length[100]',
            'email' => "required|valid_email|is_unique[users.email,id_user,{$id}]",
            'no_wa' => "required|min_length[8]|max_length[20]|is_unique[users.no_wa,id_user,{$id}]",
            'role'  => 'required|in_list[admin,tukang,customer]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Validasi formulir gagal.');
        }

        $updateData = [
            'nama'  => trim($this->request->getPost('nama')),
            'email' => trim($this->request->getPost('email')),
            'no_wa' => trim($this->request->getPost('no_wa')),
            'role'  => $this->request->getPost('role'),
        ];

        if (!empty($this->request->getPost('password'))) {
            $updateData['password'] = password_hash($this->request->getPost('password'), PASSWORD_BCRYPT);
        }

        $this->userModel->update($id, $updateData);

        return redirect()->to(base_url('admin/users'))->with('success', 'Data pengguna berhasil diperbarui!');
    }

    public function delete($id)
    {
        $id = (int) $id;
        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to(base_url('admin/users'))->with('error', 'Pengguna tidak ditemukan.');
        }

        if ($id === (int) session()->get('id_user')) {
            return redirect()->to(base_url('admin/users'))->with('error', 'Akun yang sedang digunakan tidak dapat dihapus.');
        }

        if ($user['role'] === 'admin') {
            $totalAdmin = $this->userModel->where('role', 'admin')->countAllResults();
            if ($totalAdmin <= 1) {
                return redirect()->to(base_url('admin/users'))->with('error', 'Admin terakhir tidak dapat dihapus.');
            }
        }

        $blockers = $this->getUserDeleteBlockers($id);
        if (!empty($blockers)) {
            return redirect()->to(base_url('admin/users'))
                ->with('error', 'Akun tidak dapat dihapus karena masih terhubung dengan: ' . implode(', ', $blockers) . '.');
        }

        if (!$this->userModel->delete($id)) {
            return redirect()->to(base_url('admin/users'))->with('error', 'Akun pengguna gagal dihapus.');
        }

        return redirect()->to(base_url('admin/users'))->with('success', 'Akun pengguna berhasil dihapus.');
    }

    private function getUserDeleteBlockers(int $id): array
    {
        $db = \Config\Database::connect();
        $blockers = [];

        if ($this->estimasiModel->where('id_user', $id)->countAllResults() > 0) {
            $blockers[] = 'estimasi/pekerjaan manual';
        }

        if ($this->proyekModel->where('id_user', $id)->countAllResults() > 0) {
            $blockers[] = 'proyek customer';
        }

        if ($this->proyekModel->where('id_tukang', $id)->countAllResults() > 0) {
            $blockers[] = 'penugasan proyek tukang';
        }

        if ($db->table('kasbon_tukang')->where('id_tukang', $id)->countAllResults() > 0) {
            $blockers[] = 'kasbon tukang';
        }

        if ($db->table('kasbon_tukang')->where('id_admin', $id)->countAllResults() > 0) {
            $blockers[] = 'kasbon yang dicatat admin';
        }

        if ($this->followUpModel->where('id_user_admin', $id)->countAllResults() > 0) {
            $blockers[] = 'riwayat follow up';
        }

        return $blockers;
    }
}
