<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseAdminController;
use Dompdf\Dompdf;
use Dompdf\Options;

class Laporan extends BaseAdminController
{
    public function index()
    {
        $db = \Config\Database::connect();

        $startDate = $this->request->getGet('start_date') ?: date('Y-m-01');
        $endDate   = $this->request->getGet('end_date') ?: date('Y-m-d');

        // Total Estimasi Per Periode
        $totalEstimasi = $this->estimasiModel
            ->where('created_at >=', $startDate . ' 00:00:00')
            ->where('created_at <=', $endDate . ' 23:59:59')
            ->countAllResults();

        // Total Proyek Deal & Omzet Per Periode
        $proyekStats = $db->table('proyek')
            ->select('COUNT(id_proyek) as total_proyek, SUM(nilai_proyek) as omzet, SUM(dp) as total_dp, SUM(sisa_pembayaran) as total_piutang')
            ->where('created_at >=', $startDate . ' 00:00:00')
            ->where('created_at <=', $endDate . ' 23:59:59')
            ->get()->getRowArray();

        // Daftar Proyek dalam periode
        $proyekList = $db->table('proyek')
            ->select('proyek.*, users.nama as nama_customer, jenis_pekerjaan.nama as nama_jp')
            ->join('users', 'proyek.id_user = users.id_user', 'inner')
            ->join('estimasi', 'proyek.id_estimasi = estimasi.id_estimasi', 'left')
            ->join('jenis_pekerjaan', 'estimasi.id_jp = jenis_pekerjaan.id_jp', 'left')
            ->where('proyek.created_at >=', $startDate . ' 00:00:00')
            ->where('proyek.created_at <=', $endDate . ' 23:59:59')
            ->orderBy('proyek.created_at', 'DESC')
            ->get()->getResultArray();

        // Estimasi per Jenis Pekerjaan
        $jpStats = $db->table('estimasi')
            ->select('jenis_pekerjaan.nama, COUNT(estimasi.id_estimasi) as total, SUM(estimasi.subtotal) as total_nilai')
            ->join('jenis_pekerjaan', 'estimasi.id_jp = jenis_pekerjaan.id_jp', 'left')
            ->where('estimasi.created_at >=', $startDate . ' 00:00:00')
            ->where('estimasi.created_at <=', $endDate . ' 23:59:59')
            ->groupBy('estimasi.id_jp')
            ->get()->getResultArray();

        $data = [
            'title'         => 'Laporan & Rekapitulasi Bisnis',
            'pageTitle'     => 'Laporan Kinerja & Keuangan',
            'pageSubtitle'  => 'Ringkasan performa omzet, volume estimasi, dan rekapitulasi proyek per periode.',
            'startDate'     => $startDate,
            'endDate'       => $endDate,
            'totalEstimasi' => $totalEstimasi,
            'proyekStats'   => $proyekStats,
            'proyekList'    => $proyekList,
            'jpStats'       => $jpStats,
        ];

        return $this->renderAdmin('admin/laporan/index', $data);
    }

    public function cetakPdf()
    {
        $db = \Config\Database::connect();

        $startDate = $this->request->getGet('start_date') ?: date('Y-m-01');
        $endDate   = $this->request->getGet('end_date') ?: date('Y-m-d');

        // Total Estimasi Per Periode
        $totalEstimasi = $this->estimasiModel
            ->where('created_at >=', $startDate . ' 00:00:00')
            ->where('created_at <=', $endDate . ' 23:59:59')
            ->countAllResults();

        // Total Proyek Deal & Omzet Per Periode
        $proyekStats = $db->table('proyek')
            ->select('COUNT(id_proyek) as total_proyek, SUM(nilai_proyek) as omzet, SUM(dp) as total_dp, SUM(sisa_pembayaran) as total_piutang')
            ->where('created_at >=', $startDate . ' 00:00:00')
            ->where('created_at <=', $endDate . ' 23:59:59')
            ->get()->getRowArray();

        // Daftar Proyek dalam periode
        $proyekList = $db->table('proyek')
            ->select('proyek.*, users.nama as nama_customer, jenis_pekerjaan.nama as nama_jp')
            ->join('users', 'proyek.id_user = users.id_user', 'inner')
            ->join('estimasi', 'proyek.id_estimasi = estimasi.id_estimasi', 'left')
            ->join('jenis_pekerjaan', 'estimasi.id_jp = jenis_pekerjaan.id_jp', 'left')
            ->where('proyek.created_at >=', $startDate . ' 00:00:00')
            ->where('proyek.created_at <=', $endDate . ' 23:59:59')
            ->orderBy('proyek.created_at', 'DESC')
            ->get()->getResultArray();

        // Estimasi per Jenis Pekerjaan
        $jpStats = $db->table('estimasi')
            ->select('jenis_pekerjaan.nama, COUNT(estimasi.id_estimasi) as total, SUM(estimasi.subtotal) as total_nilai')
            ->join('jenis_pekerjaan', 'estimasi.id_jp = jenis_pekerjaan.id_jp', 'left')
            ->where('estimasi.created_at >=', $startDate . ' 00:00:00')
            ->where('estimasi.created_at <=', $endDate . ' 23:59:59')
            ->groupBy('estimasi.id_jp')
            ->get()->getResultArray();

        $settings = $this->settingsModel->getSettings();

        $data = [
            'title'         => 'Laporan Rekapitulasi Proyek & Keuangan',
            'startDate'     => $startDate,
            'endDate'       => $endDate,
            'totalEstimasi' => $totalEstimasi,
            'proyekStats'   => $proyekStats,
            'proyekList'    => $proyekList,
            'jpStats'       => $jpStats,
            'settings'      => $settings,
            'adminName'     => session()->get('nama') ?? 'Administrator',
            'adminRole'     => session()->get('role') ?? 'Admin',
        ];

        $html = view('admin/laporan/cetak_pdf', $data);

        // Inisialisasi Dompdf
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isRemoteEnabled', true);
        $options->set('defaultFont', 'Helvetica');

        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $filename = 'Laporan_Penjualan_Proyek_' . date('Ymd', strtotime($startDate)) . '_' . date('Ymd', strtotime($endDate)) . '.pdf';
        return $this->response
            ->setHeader('Content-Type', 'application/pdf')
            ->setHeader('Content-Disposition', 'inline; filename="' . $filename . '"')
            ->setBody($dompdf->output());
    }
}