<?php

namespace App\Controllers\Admin\CRM;

use App\Controllers\Admin\BaseAdminController;

class Kasbon extends BaseAdminController
{
    public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        // Panggil parent initController agar properti dari BaseAdminController terinisialisasi
        parent::initController($request, $response, $logger);

        // Inisialisasi model jika belum otomatis ter-load di BaseAdminController
        $this->kasbonModel = new \App\Models\KasbonModel();
        $this->userModel   = new \App\Models\UserModel();
        $this->proyekModel = new \App\Models\ProyekModel();
    }

    public function index()
    {
        $role = session()->get('role');
        $id_user = (int) session()->get('id_user');

        $filterTukang = ($role === 'tukang') ? $id_user : ($this->request->getGet('id_tukang') ? (int) $this->request->getGet('id_tukang') : null);
        $filterProyek = $this->request->getGet('id_proyek') ? (int) $this->request->getGet('id_proyek') : null;

        $kasbonList = $this->kasbonModel->getAllKasbon($filterTukang, $filterProyek);
        $tukangList = ($role === 'admin') ? $this->userModel->getTukangList() : [];

        // Fetch projects for modal / filter
        $builder = $this->proyekModel->select('proyek.*, users.nama as nama_tukang')
            ->join('users', 'users.id_user = proyek.id_tukang', 'left');
        if ($role === 'tukang') {
            $builder->where('proyek.id_tukang', $id_user);
        }
        $proyekList = $builder->orderBy('proyek.created_at', 'DESC')->findAll();

        // Calculate summary metrics
        $totalKasbonDicairkan = 0;
        foreach ($kasbonList as $kb) {
            $totalKasbonDicairkan += (float) ($kb['nominal'] ?? 0);
        }

        $totalAlokasiUpah = 0;
        $activeProjectsForKasbon = [];
        foreach ($proyekList as $p) {
            $totalAlokasiUpah += (float) ($p['nilai_tukang'] ?? 0);
            if (!empty($p['id_tukang']) && (float)($p['nilai_tukang'] ?? 0) > 0) {
                $proyekKasbonTotal = $this->kasbonModel->getTotalKasbonByProyek((int)$p['id_proyek']);
                $sisaAlokasi = max(0, (float)$p['nilai_tukang'] - $proyekKasbonTotal);
                $p['sisa_alokasi'] = $sisaAlokasi;
                $p['total_kasbon'] = $proyekKasbonTotal;
                if ($sisaAlokasi > 0) {
                    $activeProjectsForKasbon[] = $p;
                }
            }
        }

        $totalSisaAlokasi = max(0, $totalAlokasiUpah - $totalKasbonDicairkan);

        $data = [
            'title'                    => ($role === 'tukang') ? 'Catatan Kasbon Saya' : 'CRM - Kasbon & DP Tukang',
            'pageTitle'                => ($role === 'tukang') ? 'Riwayat Kasbon & Uang Muka Anda' : 'Manajemen Kasbon & DP Tukang',
            'pageSubtitle'             => ($role === 'tukang') ? 'Pantau pencairan uang muka / kasbon upah pengerjaan proyek Anda secara transparan.' : 'Catat dan kelola pengiriman kasbon/DP untuk tukang dengan batasan otomatis sesuai nilai upah proyek.',
            'kasbonList'               => $kasbonList,
            'tukangList'               => $tukangList,
            'proyekList'               => $proyekList,
            'activeProjectsForKasbon' => $activeProjectsForKasbon,
            'totalKasbonDicairkan'     => $totalKasbonDicairkan,
            'totalAlokasiUpah'         => $totalAlokasiUpah,
            'totalSisaAlokasi'         => $totalSisaAlokasi,
            'selectedTukang'           => $filterTukang,
            'selectedProyek'           => $filterProyek,
            'role'                     => $role,
        ];

        return $this->renderAdmin('admin/crm/kasbon/index', $data);
    }

    public function store()
    {
        $role = session()->get('role');
        if ($role !== 'admin') {
            return redirect()->to(base_url('admin/crm/kasbon'))->with('error', 'Akses ditolak: Hanya admin yang dapat mencatat kasbon.');
        }

        $idProyek = (int) $this->request->getPost('id_proyek');
        $proyek = $this->proyekModel->find($idProyek);

        if (!$proyek) {
            return redirect()->to(base_url('admin/crm/kasbon'))->with('error', 'Proyek tidak ditemukan.');
        }

        if (empty($proyek['id_tukang'])) {
            return redirect()->to(base_url('admin/crm/kasbon'))->with('error', 'Tukang belum ditugaskan pada proyek ini.');
        }

        $nilaiTukang = (float) ($proyek['nilai_tukang'] ?? 0);
        if ($nilaiTukang <= 0) {
            return redirect()->to(base_url('admin/crm/kasbon'))->with('error', 'Alokasi upah tukang untuk proyek ini masih Rp 0.');
        }

        $totalKasbonSebelumnya = $this->kasbonModel->getTotalKasbonByProyek($idProyek);
        $sisaAlokasi = max(0, $nilaiTukang - $totalKasbonSebelumnya);

        $nominal = (float) str_replace(['.', ','], '', (string) $this->request->getPost('nominal'));
        if ($nominal <= 0) {
            return redirect()->to(base_url('admin/crm/kasbon'))->with('error', 'Nominal kasbon harus lebih dari 0.');
        }

        if ($nominal > $sisaAlokasi) {
            return redirect()->to(base_url('admin/crm/kasbon'))->with('error', 'Nominal kasbon (Rp ' . number_format($nominal, 0, ',', '.') . ') melebihi sisa alokasi upah tukang (Rp ' . number_format($sisaAlokasi, 0, ',', '.') . '). Transaksi dibatalkan.');
        }

        $buktiTransferName = null;
        $buktiFile = $this->request->getFile('bukti_transfer');
        if ($buktiFile && $buktiFile->isValid() && !$buktiFile->hasMoved()) {
            $buktiTransferName = $buktiFile->getRandomName();
            $uploadPath = ROOTPATH . 'public/uploads/kasbon';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            $buktiFile->move($uploadPath, $buktiTransferName);
        }

        $this->kasbonModel->insert([
            'id_proyek'         => $idProyek,
            'id_tukang'         => (int) $proyek['id_tukang'],
            'id_admin'          => (int) session()->get('id_user'),
            'nominal'           => $nominal,
            'tanggal_kasbon'    => $this->request->getPost('tanggal_kasbon') ?: date('Y-m-d'),
            'keterangan'        => trim($this->request->getPost('keterangan') ?? ''),
            'metode_pembayaran' => $this->request->getPost('metode_pembayaran') ?? 'transfer',
            'bukti_transfer'    => $buktiTransferName,
            'created_at'        => date('Y-m-d H:i:s'),
            'updated_at'        => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(base_url('admin/crm/kasbon'))
            ->with('success', 'Kasbon sebesar Rp ' . number_format($nominal, 0, ',', '.') . ' berhasil dicatat untuk proyek ' . ($proyek['kode_proyek'] ?? '') . '!');
    }

    public function delete($idKasbon)
    {
        $role = session()->get('role');
        if ($role !== 'admin') {
            return redirect()->to(base_url('admin/crm/kasbon'))->with('error', 'Akses ditolak.');
        }

        $idKasbon = (int) $idKasbon;
        $kasbon = $this->kasbonModel->find($idKasbon);

        if ($kasbon) {
            if (!empty($kasbon['bukti_transfer'])) {
                $filePath = ROOTPATH . 'public/uploads/kasbon/' . $kasbon['bukti_transfer'];
                if (file_exists($filePath)) {
                    @unlink($filePath);
                }
            }
            $this->kasbonModel->delete($idKasbon);
            return redirect()->to(base_url('admin/crm/kasbon'))->with('success', 'Data kasbon berhasil dihapus.');
        }

        return redirect()->to(base_url('admin/crm/kasbon'))->with('error', 'Data kasbon tidak ditemukan.');
    }
}