<?php

namespace App\Controllers\Admin\CRM;

use App\Controllers\Admin\BaseAdminController;

class FollowUp extends BaseAdminController
{
    public function index()
    {
        $list = $this->followUpModel->getFollowUpList();

        $data = [
            'title'        => 'CRM - Aktivitas Follow Up',
            'pageTitle'    => 'Log & Jadwal Follow Up',
            'pageSubtitle' => 'Pantau riwayat komunikasi dengan customer dari tahap survey hingga penyelesaian proyek.',
            'list'         => $list,
        ];

        return $this->renderAdmin('admin/crm/follow_up/index', $data);
    }

    public function store()
    {
        $rules = [
            'hasil'  => 'required|min_length[3]',
            'metode' => 'required|in_list[whatsapp,telepon,kunjungan,email,lainnya]',
            'tipe'   => 'required|string',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Validasi form follow up gagal.');
        }

        $idEstimasi = $this->request->getPost('id_estimasi') ? (int) $this->request->getPost('id_estimasi') : null;
        $idProyek = $this->request->getPost('id_proyek') ? (int) $this->request->getPost('id_proyek') : null;
        $tglNext = $this->request->getPost('tanggal_next_follow_up') ? $this->request->getPost('tanggal_next_follow_up') : null;

        $this->followUpModel->insert([
            'id_estimasi'            => $idEstimasi,
            'id_proyek'              => $idProyek,
            'id_user_admin'          => (int) session()->get('id_user'),
            'tipe'                   => $this->request->getPost('tipe'),
            'metode'                 => $this->request->getPost('metode'),
            'hasil'                  => trim($this->request->getPost('hasil')),
            'tanggal_follow_up'      => date('Y-m-d H:i:s'),
            'tanggal_next_follow_up' => $tglNext,
            'created_at'             => date('Y-m-d H:i:s'),
        ]);

        if ($idEstimasi) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $idEstimasi))->with('success', 'Catatan follow up berhasil ditambahkan!');
        }

        return redirect()->to(base_url('admin/crm/follow-up'))->with('success', 'Catatan follow up berhasil disimpan!');
    }
}