<?php

namespace App\Controllers\Admin\CRM\Concerns;

use App\Models\KasbonModel;

trait ManagesProjectFinance
{
    protected function parseMoneyInput($value): float
    {
        $value = trim((string) ($value ?? ''));
        if ($value === '') {
            return 0.0;
        }

        if (is_numeric($value)) {
            return max(0.0, (float) $value);
        }

        $digitsOnly = preg_replace('/[^0-9]/', '', $value);
        return $digitsOnly === '' ? 0.0 : (float) $digitsOnly;
    }

    protected function isValidTukang(int $idTukang): bool
    {
        $tukang = $this->userModel->find($idTukang);
        return $tukang && $tukang['role'] === 'tukang';
    }

    protected function storeKasbonForProject(array $proyek, string $redirectUrl)
    {
        if (empty($proyek['id_tukang'])) {
            return redirect()->to($redirectUrl)->with('error', 'Tukang belum ditugaskan pada proyek ini.');
        }

        $nilaiTukang = (float) ($proyek['nilai_tukang'] ?? 0);
        if ($nilaiTukang <= 0) {
            return redirect()->to($redirectUrl)->with('error', 'Alokasi upah tukang untuk proyek ini masih Rp 0.');
        }

        $kasbonModel = new KasbonModel();
        $totalKasbonSebelumnya = $kasbonModel->getTotalKasbonByProyek((int) $proyek['id_proyek']);
        $sisaAlokasi = max(0, $nilaiTukang - $totalKasbonSebelumnya);

        $nominal = $this->parseMoneyInput($this->request->getPost('nominal'));
        if ($nominal <= 0) {
            return redirect()->to($redirectUrl)->with('error', 'Nominal kasbon harus lebih dari Rp 0.');
        }

        if ($nominal > $sisaAlokasi) {
            return redirect()->to($redirectUrl)
                ->with('error', 'Nominal kasbon (Rp ' . number_format($nominal, 0, ',', '.') . ') melebihi sisa alokasi upah tukang (Rp ' . number_format($sisaAlokasi, 0, ',', '.') . ').');
        }

        $buktiTransferName = null;
        $buktiFile = $this->request->getFile('bukti_transfer');
        if ($buktiFile && $buktiFile->isValid() && !$buktiFile->hasMoved()) {
            $buktiTransferName = $buktiFile->getRandomName();
            $uploadPath = ROOTPATH . 'public/uploads/kasbon';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            $buktiFile->move($uploadPath, $buktiTransferName);
        }

        $kasbonModel->insert([
            'id_proyek'         => (int) $proyek['id_proyek'],
            'id_tukang'         => (int) $proyek['id_tukang'],
            'id_admin'          => (int) session()->get('id_user'),
            'nominal'           => $nominal,
            'tanggal_kasbon'    => $this->request->getPost('tanggal_kasbon') ?: date('Y-m-d'),
            'keterangan'        => trim($this->request->getPost('keterangan') ?? ''),
            'metode_pembayaran' => $this->request->getPost('metode_pembayaran') ?? 'transfer',
            'bukti_transfer'    => $buktiTransferName,
        ]);

        return redirect()->to($redirectUrl)
            ->with('success', 'Kasbon sebesar Rp ' . number_format($nominal, 0, ',', '.') . ' berhasil dicatat.');
    }
}
