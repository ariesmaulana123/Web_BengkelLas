<?php

namespace App\Controllers\Admin\CRM;

use App\Controllers\Admin\BaseAdminController;
use App\Controllers\Admin\CRM\Concerns\ManagesProjectFinance;
use App\Models\KasbonModel;

class Proyek extends BaseAdminController
{
    use ManagesProjectFinance;

    public function index()
    {
        $role = session()->get('role');
        $id_user = (int) session()->get('id_user');

        if ($this->request->getGet('mark_read') === '1') {
            session()->set($role === 'tukang' ? 'proyek_tukang_read_at' : 'proyek_admin_read_at', date('Y-m-d H:i:s'));
        }

        $status = $this->request->getGet('status');
        $filterTukang = ($role === 'tukang') ? $id_user : ($this->request->getGet('id_tukang') ? (int) $this->request->getGet('id_tukang') : null);

        $list = $this->proyekModel->getProyekList($filterTukang, $status, $role);
        $tukangList = ($role === 'admin') ? $this->userModel->getTukangList() : [];

        $data = [
            'title'          => ($role === 'tukang') ? 'Daftar Proyek & Tugas Fabrikasi' : 'CRM - Manajemen Proyek',
            'pageTitle'      => ($role === 'tukang') ? 'Tugas & Proyek Fabrikasi Anda' : 'Monitoring Proyek & Fabrikasi',
            'pageSubtitle'   => ($role === 'tukang') ? 'Pantau daftar pekerjaan yang dialokasikan kepada Anda dan perbarui progres fisik pengerjaan.' : 'Pantau jadwal produksi, alokasi tukang, progres pengerjaan, dan pembayaran proyek.',
            'list'           => $list,
            'tukangList'     => $tukangList,
            'selectedStatus' => $status,
            'selectedTukang' => $filterTukang,
            'badgeProyekAdmin' => 0,
            'badgeProyekTukang' => 0,
            'role'           => $role,
        ];

        return $this->renderAdmin('admin/crm/proyek/index', $data);
    }

    public function detail($id)
    {
        $id = (int) $id;
        $role = session()->get('role');
        $id_user = (int) session()->get('id_user');
        $proyek = $this->proyekModel->getProyekDetail($id, $role);
        if (!$proyek) {
            return redirect()->to(base_url('admin/crm/proyek'))->with('error', 'Data proyek tidak ditemukan.');
        }

        // Tukang can only access their assigned project
        if ($role === 'tukang' && (int)$proyek['id_tukang'] !== $id_user) {
            return redirect()->to(base_url('admin/crm/proyek'))->with('error', 'Akses Ditolak: Anda tidak ditugaskan pada proyek ini.');
        }

        $kasbonModel = new KasbonModel();
        $tukangList = ($role === 'admin') ? $this->userModel->getTukangList() : [];
        $followUps = ($role === 'admin') ? $this->followUpModel->getFollowUpList(null, $id) : [];
        $kasbonList = $kasbonModel->getKasbonByProyek($id);
        $totalKasbon = $kasbonModel->getTotalKasbonByProyek($id);

        $data = [
            'title'        => 'Detail Proyek ' . $proyek['kode_proyek'],
            'pageTitle'    => 'Detail Proyek: ' . $proyek['nama_proyek'],
            'pageSubtitle' => ($role === 'tukang') ? 'Rincian tugas pekerjaan, nilai alokasi Anda, dan form pembaruan progres fisik.' : 'Kelola progres fisik, jadwal penyerahan, alokasi tugas & nominal tukang, serta status pembayaran.',
            'proyek'       => $proyek,
            'tukangList'   => $tukangList,
            'followUps'    => $followUps,
            'kasbonList'   => $kasbonList,
            'totalKasbon'  => $totalKasbon,
            'sisaKasbon'   => max(0, (float) ($proyek['nilai_tukang'] ?? 0) - $totalKasbon),
            'role'         => $role,
        ];

        return $this->renderAdmin('admin/crm/proyek/detail', $data);
    }

    public function updateProgress($id)
    {
        $id = (int) $id;
        $role = session()->get('role');
        $id_user = (int) session()->get('id_user');

        $proyek = $this->proyekModel->find($id);
        if (!$proyek) {
            return redirect()->to(base_url('admin/crm/proyek'))->with('error', 'Proyek tidak ditemukan.');
        }

        // Tukang security check
        if ($role === 'tukang' && (int)$proyek['id_tukang'] !== $id_user) {
            return redirect()->to(base_url('admin/crm/proyek'))->with('error', 'Akses Ditolak: Anda tidak memiliki wewenang pada proyek ini.');
        }

        $progress = (int) $this->request->getPost('progress');
        if ($progress < 0) $progress = 0;
        if ($progress > 100) $progress = 100;

        $status = $this->request->getPost('status') ?? $proyek['status'];
        if ($progress === 100 && $status !== 'selesai') {
            $status = 'selesai';
        }

        $tglSelesai = ($status === 'selesai') ? date('Y-m-d') : null;
        $catatan = trim($this->request->getPost('catatan') ?? '');

        $updateData = [
            'progress'        => $progress,
            'status'          => $status,
            'tanggal_selesai' => $tglSelesai,
            'catatan'         => $catatan,
            'updated_at'      => date('Y-m-d H:i:s'),
        ];

        // If admin, they can also update tukang, dates, & payments
        $role = session()->get('role');
        // If admin, they can manage tukang assignment, allocation description, nominal, dates, & payments
        if ($role === 'admin') {
            if ($this->request->getPost('id_tukang') !== null) {
                $idTukang = $this->request->getPost('id_tukang') ? (int) $this->request->getPost('id_tukang') : null;
                if ($idTukang && !$this->isValidTukang($idTukang)) {
                    return redirect()->to(base_url('admin/crm/proyek/detail/' . $id))
                        ->with('error', 'Akun tukang yang dipilih tidak valid.');
                }
                $updateData['id_tukang'] = $idTukang;
            }
            if ($this->request->getPost('nilai_tukang') !== null) {
                $nilaiTukang = $this->parseMoneyInput($this->request->getPost('nilai_tukang'));
                if ($nilaiTukang < 0) $nilaiTukang = 0;
                if ($nilaiTukang > (float) $proyek['nilai_proyek']) {
                    return redirect()->to(base_url('admin/crm/proyek/detail/' . $id))
                        ->with('error', 'Alokasi upah tukang tidak boleh melebihi total nilai proyek.');
                }
                $updateData['nilai_tukang'] = $nilaiTukang;
            }
            if ($this->request->getPost('pekerjaan_tukang') !== null) {
                $updateData['pekerjaan_tukang'] = trim($this->request->getPost('pekerjaan_tukang'));
            }
            if ($this->request->getPost('tanggal_mulai')) {
                $updateData['tanggal_mulai'] = $this->request->getPost('tanggal_mulai');
            }
            if ($this->request->getPost('tanggal_target_selesai')) {
                $updateData['tanggal_target_selesai'] = $this->request->getPost('tanggal_target_selesai');
            }
            if ($this->request->getPost('dp') !== null) {
                $dp = $this->parseMoneyInput($this->request->getPost('dp'));
                $nilai = (float) $proyek['nilai_proyek'];
                if ($dp > $nilai) {
                    return redirect()->to(base_url('admin/crm/proyek/detail/' . $id))
                        ->with('error', 'DP customer tidak boleh melebihi total nilai proyek.');
                }
                $sisa = $nilai - $dp;
                if ($sisa < 0) $sisa = 0;
                $updateData['dp'] = $dp;
                $updateData['sisa_pembayaran'] = $sisa;
                $updateData['status_pembayaran'] = ($dp >= $nilai) ? 'lunas' : ($dp > 0 ? 'dp_terbayar' : 'belum_lunas');
            }
        }

        // Handle Photo Documentation Upload
        $fotoFile = $this->request->getFile('foto_dokumentasi');
        if ($fotoFile && $fotoFile->isValid() && !$fotoFile->hasMoved()) {
            $newName = $fotoFile->getRandomName();
            $uploadPath = ROOTPATH . 'public/uploads/proyek';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            $fotoFile->move($uploadPath, $newName);

            $existingFotos = !empty($proyek['foto_dokumentasi']) ? json_decode($proyek['foto_dokumentasi'], true) : [];
            if (!is_array($existingFotos)) $existingFotos = [];
            $existingFotos[] = [
                'file'       => $newName,
                'caption'    => trim($this->request->getPost('caption_foto') ?? 'Dokumentasi progres ' . $progress . '%'),
                'created_at' => date('Y-m-d H:i:s'),
            ];
            $updateData['foto_dokumentasi'] = json_encode($existingFotos);
        }

        $this->proyekModel->update($id, $updateData);

        return redirect()->to(base_url('admin/crm/proyek/detail/' . $id))
            ->with('success', 'Progress dan data proyek berhasil diperbarui!');
    }

    public function tambahKasbon($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('admin/crm/proyek/detail/' . (int) $id))
                ->with('error', 'Akses ditolak. Hanya admin yang dapat mencatat kasbon.');
        }

        $id = (int) $id;
        $proyek = $this->proyekModel->find($id);
        if (!$proyek) {
            return redirect()->to(base_url('admin/crm/proyek'))->with('error', 'Proyek tidak ditemukan.');
        }

        return $this->storeKasbonForProject($proyek, base_url('admin/crm/proyek/detail/' . $id));
    }

    public function hapusKasbon($idProyek, $idKasbon)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('admin/crm/proyek/detail/' . (int) $idProyek))
                ->with('error', 'Akses ditolak.');
        }

        $idProyek = (int) $idProyek;
        $idKasbon = (int) $idKasbon;
        $kasbonModel = new KasbonModel();
        $kasbon = $kasbonModel->where('id_proyek', $idProyek)->where('id_kasbon', $idKasbon)->first();

        if (!$kasbon) {
            return redirect()->to(base_url('admin/crm/proyek/detail/' . $idProyek))
                ->with('error', 'Data kasbon tidak ditemukan.');
        }

        if (!empty($kasbon['bukti_transfer'])) {
            $filePath = ROOTPATH . 'public/uploads/kasbon/' . $kasbon['bukti_transfer'];
            if (file_exists($filePath)) {
                @unlink($filePath);
            }
        }

        $kasbonModel->delete($idKasbon);

        return redirect()->to(base_url('admin/crm/proyek/detail/' . $idProyek))
            ->with('success', 'Data kasbon berhasil dihapus.');
    }

}
