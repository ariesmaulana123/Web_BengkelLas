<?php

namespace App\Controllers\Admin\CRM;

use App\Controllers\Admin\BaseAdminController;

class Customer extends BaseAdminController
{
    public function index()
    {
        $search = $this->request->getGet('q');
        $customers = $this->userModel->getCustomerList($search);

        $data = [
            'title'        => 'CRM - Data Customer',
            'pageTitle'    => 'Database Pelanggan',
            'pageSubtitle' => 'Kelola direktori customer yang mendaftar dan mengajukan estimasi.',
            'customers'    => $customers,
            'search'       => $search,
        ];

        return $this->renderAdmin('admin/crm/customer/index', $data);
    }

    public function detail($id)
    {
        $id = (int) $id;
        $customer = $this->userModel->find($id);
        if (!$customer || $customer['role'] !== 'customer') {
            return redirect()->to(base_url('admin/crm/customer'))->with('error', 'Data customer tidak ditemukan.');
        }

        $estimasiList = $this->estimasiModel->getEstimasiByUser($id);
        $proyekList = $this->proyekModel->where('id_user', $id)->orderBy('created_at', 'DESC')->findAll();

        $data = [
            'title'        => 'Detail Customer - ' . $customer['nama'],
            'pageTitle'    => 'Profil & Riwayat Pelanggan',
            'pageSubtitle' => 'Informasi kontak, seluruh arsip estimasi, dan proyek yang pernah dikerjakan.',
            'customer'     => $customer,
            'estimasiList' => $estimasiList,
            'proyekList'   => $proyekList,
        ];

        return $this->renderAdmin('admin/crm/customer/detail', $data);
    }
}