<?php

namespace App\Controllers\Admin\CRM;

use App\Controllers\Admin\BaseAdminController;
use App\Controllers\Admin\CRM\Concerns\ManagesProjectFinance;
use App\Models\KasbonModel;
use Dompdf\Dompdf;
use Dompdf\Options;

class Estimasi extends BaseAdminController
{
    use ManagesProjectFinance;

    public function index()
    {
        $status = $this->request->getGet('status');
        $search = $this->request->getGet('q');

        $list = $this->estimasiModel->getEstimasiCRM($status, $search);

        $data = [
            'title'          => 'CRM - Pencatatan Pekerjaan Manual',
            'pageTitle'      => 'Pencatatan Pekerjaan Manual',
            'pageSubtitle'   => 'Catat pekerjaan customer yang telah disepakati melalui WhatsApp. Seluruh spesifikasi dan harga diinput Admin.',
            'list'           => $list,
            'selectedStatus' => $status,
            'search'         => $search,
            'stats'          => $this->estimasiModel->getDashboardStats(),
        ];

        return $this->renderAdmin('admin/crm/estimasi/index', $data);
    }

    public function create()
    {
        return $this->renderAdmin('admin/crm/estimasi/form', [
            'title'        => 'Catat Pekerjaan Manual',
            'pageTitle'    => 'Catat Pekerjaan Manual',
            'pageSubtitle' => 'Masukkan detail kesepakatan customer secara manual.',
            'estimasi'     => null,
            'customerList' => $this->userModel->where('role', 'customer')->orderBy('nama', 'ASC')->findAll(),
            'jenisList'    => $this->jpModel->getActiveList(),
        ]);
    }

    public function store()
    {
        return $this->saveManual();
    }

    public function edit($id)
    {
        $estimasi = $this->findManualEstimasi((int) $id);
        if (!$estimasi) {
            return redirect()->to(base_url('admin/crm/estimasi'))->with('error', 'Catatan pekerjaan manual tidak ditemukan.');
        }

        return $this->renderAdmin('admin/crm/estimasi/form', [
            'title'        => 'Edit Pekerjaan Manual',
            'pageTitle'    => 'Edit Pekerjaan Manual',
            'pageSubtitle' => 'Perbarui detail pekerjaan dan nilai yang dicatat Admin.',
            'estimasi'     => $estimasi,
            'customerList' => $this->userModel->where('role', 'customer')->orderBy('nama', 'ASC')->findAll(),
            'jenisList'    => $this->jpModel->getActiveList(),
        ]);
    }

    public function update($id)
    {
        return $this->saveManual((int) $id);
    }

    private function saveManual(?int $id = null)
    {
        $estimasi = $id ? $this->findManualEstimasi($id) : null;
        if ($id && !$estimasi) {
            return redirect()->to(base_url('admin/crm/estimasi'))->with('error', 'Catatan pekerjaan manual tidak ditemukan.');
        }

        $rules = [
            'nama_customer_manual' => 'required|max_length[150]',
            'no_wa_manual'         => 'required|max_length[30]',
            'nama_pekerjaan'       => 'required|max_length[255]',
            'panjang'              => 'required|numeric|greater_than_equal_to[0]',
            'lebar'                => 'required|numeric|greater_than_equal_to[0]',
            'tinggi'               => 'permit_empty|numeric|greater_than_equal_to[0]',
            'ukuran_lubang'        => 'permit_empty|max_length[100]',
            'luas'                 => 'required|numeric|greater_than_equal_to[0]',
            'qty_unit'             => 'required|max_length[100]',
            'material_custom'      => 'required',
            'harga_bahan'          => 'required|numeric|greater_than_equal_to[0]',
            'harga_jasa'           => 'required|numeric|greater_than_equal_to[0]',
            'subtotal'             => 'required|numeric|greater_than_equal_to[0]',
            'total_final'          => 'required|numeric|greater_than_equal_to[0]',
            'catatan'              => 'permit_empty',
            'tanggal_survey'       => 'permit_empty',
            'lokasi_survey'        => 'permit_empty',
            'status'               => 'required|in_list[baru,dihubungi,survey,penawaran,deal,ditolak]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $noWa = trim($this->request->getPost('no_wa_manual'));
        if (!preg_match('/\A[0-9+() -]{8,30}\z/', $noWa)) {
            return redirect()->back()->withInput()->with('error', 'Nomor WhatsApp customer tidak valid.');
        }

        $idUser = $this->request->getPost('id_user') ? (int) $this->request->getPost('id_user') : null;
        if ($idUser) {
            $customer = $this->userModel->find($idUser);
            if (!$customer || $customer['role'] !== 'customer') {
                return redirect()->back()->withInput()->with('error', 'Akun yang dipilih bukan akun customer yang valid.');
            }
        }

        $idJp = $this->request->getPost('id_jp') ? (int) $this->request->getPost('id_jp') : null;
        if ($idJp && !$this->jpModel->find($idJp)) {
            return redirect()->back()->withInput()->with('error', 'Jenis pekerjaan yang dipilih tidak ditemukan.');
        }

        $tanggalSurveyInput = trim($this->request->getPost('tanggal_survey') ?? '');
        $tanggalSurvey = null;
        if ($tanggalSurveyInput !== '') {
            $date = \DateTime::createFromFormat('Y-m-d\\TH:i', $tanggalSurveyInput);
            if (!$date || $date->format('Y-m-d\\TH:i') !== $tanggalSurveyInput) {
                return redirect()->back()->withInput()->with('error', 'Tanggal pekerjaan/survey tidak valid.');
            }
            $tanggalSurvey = $date->format('Y-m-d H:i:s');
        }

        $data = [
            'id_user'             => $idUser,
            'nama_customer_manual'=> trim($this->request->getPost('nama_customer_manual')),
            'no_wa_manual'        => $noWa,
            'id_jp'               => $idJp,
            'nama_pekerjaan'      => trim($this->request->getPost('nama_pekerjaan')),
            'panjang'             => (float) $this->request->getPost('panjang'),
            'lebar'               => (float) $this->request->getPost('lebar'),
            'tinggi'              => $this->request->getPost('tinggi') !== '' ? (float) $this->request->getPost('tinggi') : null,
            'ukuran_lubang'       => trim($this->request->getPost('ukuran_lubang') ?? ''),
            'luas'                => (float) $this->request->getPost('luas'),
            'qty_unit'            => trim($this->request->getPost('qty_unit')),
            'material_custom'     => trim($this->request->getPost('material_custom')),
            'harga_bahan'         => (float) $this->request->getPost('harga_bahan'),
            'harga_jasa'          => (float) $this->request->getPost('harga_jasa'),
            'biaya_jasa'          => (float) $this->request->getPost('harga_jasa'),
            'subtotal'            => (float) $this->request->getPost('subtotal'),
            'total_final'         => (float) $this->request->getPost('total_final'),
            'catatan'             => trim($this->request->getPost('catatan') ?? ''),
            'tanggal_survey'      => $tanggalSurvey,
            'lokasi_survey'       => trim($this->request->getPost('lokasi_survey') ?? ''),
            'status'              => $this->request->getPost('status'),
            'sumber'              => 'manual',
        ];

        if ($id) {
            $this->estimasiModel->update($id, $data);
        } else {
            $this->estimasiModel->insert($data);
            $id = (int) $this->estimasiModel->getInsertID();
        }

        return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))->with('success', 'Catatan pekerjaan manual berhasil disimpan.');
    }

    public function detail($id)
    {
        $id = (int) $id;
        if (!$this->findManualEstimasi($id)) {
            return redirect()->to(base_url('admin/crm/estimasi'))->with('error', 'Catatan pekerjaan manual tidak ditemukan.');
        }

        $estimasi = $this->estimasiModel->getEstimasiDetail($id);

        $followUps = $this->followUpModel->getFollowUpList($id, null);
        $existingProyek = $this->proyekModel->where('id_estimasi', $id)->first();
        $tukangList = $this->userModel->getTukangList();
        $kasbonModel = new KasbonModel();
        $kasbonList = $existingProyek ? $kasbonModel->getKasbonByProyek((int) $existingProyek['id_proyek']) : [];
        $totalKasbon = $existingProyek ? $kasbonModel->getTotalKasbonByProyek((int) $existingProyek['id_proyek']) : 0;

        $data = [
            'title'          => 'Detail Pekerjaan Manual #' . str_pad((string)$id, 5, '0', STR_PAD_LEFT),
            'pageTitle'      => 'Detail Pekerjaan Manual',
            'pageSubtitle'   => 'Tinjau catatan pekerjaan dan nominal yang dimasukkan Admin.',
            'estimasi'       => $estimasi,
            'followUps'      => $followUps,
            'existingProyek' => $existingProyek,
            'tukangList'     => $tukangList,
            'kasbonList'     => $kasbonList,
            'totalKasbon'    => $totalKasbon,
            'sisaKasbon'     => $existingProyek ? max(0, (float) ($existingProyek['nilai_tukang'] ?? 0) - $totalKasbon) : 0,
        ];

        return $this->renderAdmin('admin/crm/estimasi/detail_manual', $data);
    }

    public function convertToProject($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . (int) $id))
                ->with('error', 'Akses ditolak. Hanya admin yang dapat menyimpan proyek.');
        }

        $id = (int) $id;
        $manualEstimasi = $this->findManualEstimasi($id);
        if (!$manualEstimasi) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Catatan pekerjaan manual tidak ditemukan.');
        }

        $estimasi = $this->estimasiModel->getEstimasiDetail($id);
        if (!$estimasi) {
            return redirect()->to(base_url('admin/crm/estimasi'))->with('error', 'Data estimasi tidak ditemukan.');
        }

        // Check if project already exists
        $existing = $this->proyekModel->where('id_estimasi', $id)->first();
        if ($existing) {
            return redirect()->to(base_url('admin/crm/proyek/detail/' . $existing['id_proyek']))
                ->with('warning', 'Proyek untuk estimasi ini sudah pernah dibuat.');
        }

        $nilaiProyek = $this->resolveManualProjectValue($estimasi);
        if ($nilaiProyek <= 0) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Nilai proyek masih Rp 0. Isi harga final/subtotal pekerjaan terlebih dahulu.');
        }

        $dp = $this->parseMoneyInput($this->request->getPost('dp'));
        if ($dp > $nilaiProyek) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'DP customer tidak boleh melebihi nilai proyek.');
        }

        $sisa = $nilaiProyek - $dp;
        if ($sisa < 0) $sisa = 0;

        $idTukang = $this->request->getPost('id_tukang') ? (int) $this->request->getPost('id_tukang') : null;
        if ($idTukang && !$this->isValidTukang($idTukang)) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Akun tukang yang dipilih tidak valid.');
        }

        $nilaiTukang = $this->parseMoneyInput($this->request->getPost('nilai_tukang'));
        if ($nilaiTukang > $nilaiProyek) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Alokasi upah tukang tidak boleh melebihi nilai proyek.');
        }

        $pekerjaanTukang = trim($this->request->getPost('pekerjaan_tukang') ?? '');
        $tglMulai = $this->request->getPost('tanggal_mulai') ? $this->request->getPost('tanggal_mulai') : date('Y-m-d');
        $tglTarget = $this->request->getPost('tanggal_target_selesai') ? $this->request->getPost('tanggal_target_selesai') : null;

        $kodeProyek = $this->proyekModel->generateKodeProyek();
        $namaProyek = 'Pengerjaan ' . $estimasi['nama_jp'] . ' - ' . $estimasi['nama_customer'];

        $db = \Config\Database::connect();
        $db->transBegin();

        $idCustomer = $this->ensureManualCustomer($estimasi);
        if (!$idCustomer) {
            $db->transRollback();

            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Customer tidak bisa dibuat/ditautkan. Pastikan nomor WhatsApp valid dan tidak dipakai akun non-customer.');
        }

        // 1. Insert ke Proyek
        $projectInserted = $this->proyekModel->insert([
            'id_estimasi'            => $id,
            'id_user'                => $idCustomer,
            'id_tukang'              => $idTukang,
            'nilai_tukang'           => $nilaiTukang,
            'pekerjaan_tukang'       => $pekerjaanTukang,
            'kode_proyek'            => $kodeProyek,
            'nama_proyek'            => $namaProyek,
            'nilai_proyek'           => $nilaiProyek,
            'dp'                     => $dp,
            'sisa_pembayaran'        => $sisa,
            'status_pembayaran'      => ($dp >= $nilaiProyek) ? 'lunas' : ($dp > 0 ? 'dp_terbayar' : 'belum_lunas'),
            'tanggal_mulai'          => $tglMulai,
            'tanggal_target_selesai' => $tglTarget,
            'progress'               => 0,
            'status'                 => 'rencana',
            'catatan'                => $estimasi['catatan'],
        ]);

        $idProyek = $this->proyekModel->getInsertID();
        if ($projectInserted === false || (int) $idProyek <= 0) {
            $db->transRollback();

            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Proyek gagal disimpan. Periksa kembali data pekerjaan dan customer.');
        }

        // 2. Update status estimasi menjadi deal dan tautkan akun customer jika sebelumnya catatan WA manual.
        $estimasiUpdated = $this->estimasiModel->update($id, [
            'id_user'    => $idCustomer,
            'status'     => 'deal',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        if ($estimasiUpdated === false) {
            $db->transRollback();

            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Status pekerjaan gagal diperbarui. Proyek belum disimpan.');
        }

        // 3. Log initial follow up
        $followUpInserted = $this->followUpModel->insert([
            'id_estimasi'            => $id,
            'id_proyek'              => $idProyek,
            'id_user_admin'          => (int) session()->get('id_user'),
            'tipe'                   => 'penawaran',
            'metode'                 => 'whatsapp',
            'hasil'                  => 'Customer menyetujui penawaran (DEAL). Proyek resmi dibuat dengan kode ' . $kodeProyek . '.',
            'tanggal_follow_up'      => date('Y-m-d H:i:s'),
            'tanggal_next_follow_up' => null,
            'created_at'             => date('Y-m-d H:i:s'),
        ]);
        if ($followUpInserted === false) {
            $db->transRollback();

            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Log follow up gagal dibuat. Proyek belum disimpan.');
        }

        if ($db->transStatus() === false) {
            $db->transRollback();

            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Proyek gagal disimpan. Silakan coba lagi.');
        }

        $db->transCommit();

        return redirect()->to(base_url('admin/crm/proyek/detail/' . $idProyek))
            ->with('success', 'Proyek berhasil disimpan: ' . $kodeProyek);
    }

    public function deal($id)
    {
        return $this->convertToProject($id);
    }

    public function updateAlokasi($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . (int) $id))
                ->with('error', 'Akses ditolak. Hanya admin yang dapat mengalokasikan pekerjaan.');
        }

        $id = (int) $id;
        if (!$this->findManualEstimasi($id)) {
            return redirect()->to(base_url('admin/crm/estimasi'))->with('error', 'Catatan pekerjaan manual tidak ditemukan.');
        }

        $proyek = $this->proyekModel->where('id_estimasi', $id)->first();
        if (!$proyek) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Proyek belum disimpan. Klik Simpan Proyek terlebih dahulu sebelum alokasikan pekerjaan.');
        }

        $idTukang = $this->request->getPost('id_tukang') ? (int) $this->request->getPost('id_tukang') : 0;
        if (!$idTukang || !$this->isValidTukang($idTukang)) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Pilih akun tukang yang valid untuk alokasi pekerjaan.');
        }

        $nilaiProyek = (float) ($proyek['nilai_proyek'] ?? 0);
        $nilaiTukang = $this->parseMoneyInput($this->request->getPost('nilai_tukang'));
        if ($nilaiTukang <= 0) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Nominal alokasi upah tukang harus lebih dari Rp 0.');
        }

        if ($nilaiTukang > $nilaiProyek) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Alokasi upah tukang (Rp ' . number_format($nilaiTukang, 0, ',', '.') . ') tidak boleh melebihi nilai proyek (Rp ' . number_format($nilaiProyek, 0, ',', '.') . ').');
        }

        $this->proyekModel->update((int) $proyek['id_proyek'], [
            'id_tukang'              => $idTukang,
            'nilai_tukang'           => $nilaiTukang,
            'pekerjaan_tukang'       => trim($this->request->getPost('pekerjaan_tukang') ?? ''),
            'tanggal_mulai'          => $this->request->getPost('tanggal_mulai') ?: ($proyek['tanggal_mulai'] ?? date('Y-m-d')),
            'tanggal_target_selesai' => $this->request->getPost('tanggal_target_selesai') ?: ($proyek['tanggal_target_selesai'] ?? null),
            'updated_at'             => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
            ->with('success', 'Alokasi pekerjaan tukang berhasil disimpan.');
    }

    public function simpanKasbon($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . (int) $id))
                ->with('error', 'Akses ditolak. Hanya admin yang dapat mencatat kasbon.');
        }

        $id = (int) $id;
        if (!$this->findManualEstimasi($id)) {
            return redirect()->to(base_url('admin/crm/estimasi'))->with('error', 'Catatan pekerjaan manual tidak ditemukan.');
        }

        $proyek = $this->proyekModel->where('id_estimasi', $id)->first();
        if (!$proyek) {
            return redirect()->to(base_url('admin/crm/estimasi/detail/' . $id))
                ->with('error', 'Proyek belum disimpan. Klik Simpan Proyek terlebih dahulu sebelum mencatat kasbon.');
        }

        return $this->storeKasbonForProject($proyek, base_url('admin/crm/estimasi/detail/' . $id));
    }

    public function cetakPdf($id)
    {
        $id = (int) $id;
        if (!$this->findManualEstimasi($id)) {
            return redirect()->to(base_url('admin/crm/estimasi'))->with('error', 'Catatan pekerjaan manual tidak ditemukan.');
        }

        $estimasi = $this->estimasiModel->getEstimasiDetail($id);
        if (!$estimasi) {
            return redirect()->to(base_url('admin/crm/estimasi'))->with('error', 'Data tidak ditemukan.');
        }

        $settings = $this->settingsModel->getSettings();

        $data = [
            'estimasi' => $estimasi,
            'settings' => $settings,
        ];

        $html = view('admin/crm/estimasi/laporan_manual_pdf', $data);

        // Inisialisasi Dompdf
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isRemoteEnabled', true);
        $options->set('defaultFont', 'Helvetica');

        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $filename = 'Penawaran_SentosaJaya_' . str_pad((string)$id, 5, '0', STR_PAD_LEFT) . '.pdf';
        return $this->response
            ->setHeader('Content-Type', 'application/pdf')
            ->setHeader('Content-Disposition', 'inline; filename="' . $filename . '"')
            ->setBody($dompdf->output());
    }

    private function findManualEstimasi(int $id): ?array
    {
        $estimasi = $this->estimasiModel->find($id);
        return $estimasi && $estimasi['sumber'] === 'manual' ? $estimasi : null;
    }

    private function resolveManualProjectValue(array $estimasi): float
    {
        $candidates = [
            $estimasi['total_final'] ?? 0,
            $estimasi['subtotal'] ?? 0,
            ((float) ($estimasi['harga_bahan'] ?? 0)) + ((float) ($estimasi['harga_jasa'] ?? 0)),
        ];

        foreach ($candidates as $candidate) {
            $value = (float) $candidate;
            if ($value > 0) {
                return $value;
            }
        }

        return 0.0;
    }

    private function normalizeManualPhone(string $phone): string
    {
        return preg_replace('/[^0-9]/', '', $phone) ?? '';
    }

    private function ensureManualCustomer(array $estimasi): ?int
    {
        if (!empty($estimasi['id_user'])) {
            $customer = $this->userModel->find((int) $estimasi['id_user']);
            return ($customer && $customer['role'] === 'customer') ? (int) $customer['id_user'] : null;
        }

        $noWa = $this->normalizeManualPhone($estimasi['no_wa_customer'] ?? $estimasi['no_wa_manual'] ?? '');
        if (strlen($noWa) < 8 || strlen($noWa) > 20) {
            return null;
        }

        $existingByWa = $this->userModel->where('no_wa', $noWa)->first();
        if ($existingByWa) {
            return $existingByWa['role'] === 'customer' ? (int) $existingByWa['id_user'] : null;
        }

        $email = $this->buildManualCustomerEmail('wa' . $noWa);
        $existingByEmail = $this->userModel->where('email', $email)->first();
        if ($existingByEmail) {
            $email = $this->buildManualCustomerEmail('wa' . $noWa . '.est' . (int) $estimasi['id_estimasi']);
        }

        $namaCustomer = trim($estimasi['nama_customer'] ?? $estimasi['nama_customer_manual'] ?? 'Customer WhatsApp');
        if (strlen($namaCustomer) < 3) {
            $namaCustomer = 'Customer WhatsApp';
        }

        $this->userModel->insert([
            'nama'     => $namaCustomer,
            'email'    => $email,
            'no_wa'    => $noWa,
            'password' => password_hash(bin2hex(random_bytes(8)), PASSWORD_BCRYPT),
            'role'     => 'customer',
        ]);

        $idCustomer = (int) $this->userModel->getInsertID();
        return $idCustomer > 0 ? $idCustomer : null;
    }

    private function buildManualCustomerEmail(string $localPart): string
    {
        $localPart = strtolower(preg_replace('/[^a-z0-9._-]/i', '', $localPart));
        if ($localPart === '') {
            $localPart = 'customer';
        }

        return $localPart . '@' . $this->resolveCustomerEmailDomain();
    }

    private function resolveCustomerEmailDomain(): string
    {
        $settings = $this->settingsModel->getSettings();
        $companyEmail = trim((string) ($settings['email'] ?? ''));
        if (str_contains($companyEmail, '@')) {
            $domain = strtolower(substr(strrchr($companyEmail, '@'), 1));
            if ($domain !== '') {
                return $domain;
            }
        }

        $host = $this->request->getUri()->getHost();
        if ($host === '') {
            $host = parse_url(config('App')->baseURL, PHP_URL_HOST) ?: '';
        }

        if ($host === '') {
            $host = gethostname() ?: 'local';
        }

        $domain = strtolower(trim(preg_replace('/[^a-z0-9.-]/i', '', $host), '.-'));
        if ($domain === '') {
            $domain = 'local';
        }
        if (!str_contains($domain, '.')) {
            $domain .= '.local';
        }

        return $domain;
    }
}
