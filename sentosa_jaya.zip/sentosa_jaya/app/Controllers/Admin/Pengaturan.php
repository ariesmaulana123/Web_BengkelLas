<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseAdminController;

class Pengaturan extends BaseAdminController
{
    public function index()
    {
        $settings = $this->settingsModel->getSettings();

        $data = [
            'title'        => 'Pengaturan Profil Perusahaan',
            'pageTitle'    => 'Pengaturan Usaha & Penawaran',
            'pageSubtitle' => 'Informasi identitas workshop, kontak WhatsApp, nomor rekening bank, dan format penawaran PDF.',
            'settings'     => $settings,
        ];

        return $this->renderAdmin('admin/pengaturan/index', $data);
    }

    public function update()
    {
        $rules = [
            'nama_perusahaan' => 'required|min_length[3]|max_length[150]',
            'alamat'          => 'required',
            'no_wa'           => 'required',
            'email'           => 'required|valid_email',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Validasi formulir pengaturan gagal.');
        }

        $updateData = [
            'nama_perusahaan'          => trim($this->request->getPost('nama_perusahaan')),
            'tagline'                  => trim($this->request->getPost('tagline')),
            'alamat'                   => trim($this->request->getPost('alamat')),
            'no_wa'                    => trim($this->request->getPost('no_wa')),
            'email'                    => trim($this->request->getPost('email')),
            'nama_bank'                => trim($this->request->getPost('nama_bank')),
            'no_rekening'              => trim($this->request->getPost('no_rekening')),
            'atas_nama_bank'           => trim($this->request->getPost('atas_nama_bank')),
            'nama_penanggung_jawab'    => trim($this->request->getPost('nama_penanggung_jawab')),
            'jabatan_penanggung_jawab' => trim($this->request->getPost('jabatan_penanggung_jawab')),
            'catatan_penawaran'        => trim($this->request->getPost('catatan_penawaran')),
            'updated_at'               => date('Y-m-d H:i:s'),
        ];

        $this->settingsModel->update(1, $updateData);

        return redirect()->to(base_url('admin/pengaturan'))->with('success', 'Pengaturan profil perusahaan dan penawaran PDF berhasil disimpan!');
    }
}