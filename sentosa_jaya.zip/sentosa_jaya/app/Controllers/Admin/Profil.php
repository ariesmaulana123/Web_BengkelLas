<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseAdminController;

class Profil extends BaseAdminController
{
    public function index()
    {
        $id_user = (int) session()->get('id_user');
        $user = $this->userModel->find($id_user);

        $data = [
            'title'        => 'Profil Saya',
            'pageTitle'    => 'Pengaturan Profil Akun',
            'pageSubtitle' => 'Kelola informasi identitas pribadi dan keamanan kata sandi Anda.',
            'user'         => $user,
        ];

        return $this->renderAdmin('admin/profil/index', $data);
    }

    public function update()
    {
        $id_user = (int) session()->get('id_user');
        $user = $this->userModel->find($id_user);
        if (!$user) {
            return redirect()->to(base_url('login'))->with('error', 'Sesi berakhir.');
        }

        $rules = [
            'nama'  => 'required|min_length[3]|max_length[100]',
            'no_wa' => "required|min_length[8]|max_length[20]|is_unique[users.no_wa,id_user,{$id_user}]",
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Validasi profil gagal. Nomor WhatsApp harus unik.');
        }

        $updateData = [
            'nama'       => trim($this->request->getPost('nama')),
            'no_wa'      => trim($this->request->getPost('no_wa')),
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        // Jika mengubah password
        $oldPassword = $this->request->getPost('old_password');
        $newPassword = $this->request->getPost('new_password');
        $confirmPassword = $this->request->getPost('confirm_password');

        if (!empty($newPassword)) {
            if (empty($oldPassword) || !password_verify($oldPassword, $user['password'])) {
                return redirect()->back()->with('error', 'Password lama yang Anda masukkan tidak sesuai.');
            }
            if (strlen($newPassword) < 6) {
                return redirect()->back()->with('error', 'Password baru minimal harus 6 karakter.');
            }
            if ($newPassword !== $confirmPassword) {
                return redirect()->back()->with('error', 'Konfirmasi password baru tidak cocok.');
            }
            $updateData['password'] = password_hash($newPassword, PASSWORD_BCRYPT);
        }

        $this->userModel->update($id_user, $updateData);

        // Update session
        session()->set('nama', $updateData['nama']);
        session()->set('no_wa', $updateData['no_wa']);

        return redirect()->to(base_url('admin/profil'))->with('success', 'Profil dan informasi akun berhasil diperbarui!');
    }
}