<?php

namespace App\Controllers\Admin\SCM;

use App\Controllers\Admin\BaseAdminController;

class Harga extends BaseAdminController
{
    public function index()
    {
        $id_jp = $this->request->getGet('id_jp') ? (int) $this->request->getGet('id_jp') : null;

        $list = $this->hargaModel->getHargaWithMaterial($id_jp);
        $jpList = $this->jpModel->orderBy('nama', 'ASC')->findAll();

        $data = [
            'title'        => 'SCM - Master Harga Bahan',
            'pageTitle'    => 'Pengaturan Harga Bahan & Jasa',
            'pageSubtitle' => 'Update harga acuan material aktif yang menjadi dasar hitung Kalkulator RAB Landing Page secara real-time.',
            'list'         => $list,
            'jpList'       => $jpList,
            'selectedJp'   => $id_jp,
        ];

        return $this->renderAdmin('admin/scm/harga', $data);
    }

    public function updateSingle($id_mharg)
    {
        $id_mharg = (int) $id_mharg;
        $hargaRow = $this->hargaModel->find($id_mharg);
        if (!$hargaRow) {
            return redirect()->to(base_url('admin/scm/harga'))->with('error', 'Data harga tidak ditemukan.');
        }

        $harga = (float) $this->request->getPost('harga');
        $status = $this->request->getPost('status') ?? 'aktif';

        if ($harga < 0) {
            return redirect()->back()->with('error', 'Harga tidak boleh bernilai negatif.');
        }

        $this->hargaModel->update($id_mharg, [
            'harga'      => $harga,
            'status'     => $status,
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(base_url('admin/scm/harga'))->with('success', 'Harga bahan berhasil diperbarui dan langsung aktif di kalkulator!');
    }

    public function bulkUpdate()
    {
        $prices = $this->request->getPost('prices');
        if (!is_array($prices) || empty($prices)) {
            return redirect()->to(base_url('admin/scm/harga'))->with('error', 'Tidak ada data harga yang dikirim.');
        }

        $db = \Config\Database::connect();
        $db->transStart();

        foreach ($prices as $id_mharg => $val) {
            $id = (int) $id_mharg;
            $newHarga = (float) $val;
            if ($newHarga >= 0) {
                $this->hargaModel->update($id, [
                    'harga'      => $newHarga,
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
            }
        }

        $db->transComplete();

        return redirect()->to(base_url('admin/scm/harga'))->with('success', 'Pembaruan harga massal berhasil disimpan!');
    }
}