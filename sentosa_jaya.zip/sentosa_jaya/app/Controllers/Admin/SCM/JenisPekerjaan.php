<?php

namespace App\Controllers\Admin\SCM;

use App\Controllers\Admin\BaseAdminController;

class JenisPekerjaan extends BaseAdminController
{
    public function index()
    {
        $list = $this->jpModel->orderBy('id_jp', 'ASC')->findAll();

        $data = [
            'title'        => 'SCM - Jenis Pekerjaan',
            'pageTitle'    => 'Master Jenis Pekerjaan',
            'pageSubtitle' => 'Kelola kategori pekerjaan konstruksi besi yang tersedia pada sistem dan kalkulator.',
            'list'         => $list,
        ];

        return $this->renderAdmin('admin/scm/jenis_pekerjaan', $data);
    }

    public function store()
    {
        $rules = [
            'nama'      => 'required|min_length[3]|max_length[100]',
            'deskripsi' => 'permit_empty|string',
            'status'    => 'required|in_list[aktif,nonaktif]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Validasi gagal. Pastikan form terisi dengan benar.');
        }

        $this->jpModel->insert([
            'nama'      => trim($this->request->getPost('nama')),
            'deskripsi' => trim($this->request->getPost('deskripsi')),
            'status'    => $this->request->getPost('status'),
        ]);

        return redirect()->to(base_url('admin/scm/jenis-pekerjaan'))->with('success', 'Jenis pekerjaan baru berhasil ditambahkan!');
    }

    public function update($id)
    {
        $id = (int) $id;
        $jp = $this->jpModel->find($id);
        if (!$jp) {
            return redirect()->to(base_url('admin/scm/jenis-pekerjaan'))->with('error', 'Data tidak ditemukan.');
        }

        $rules = [
            'nama'      => 'required|min_length[3]|max_length[100]',
            'deskripsi' => 'permit_empty|string',
            'status'    => 'required|in_list[aktif,nonaktif]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Validasi gagal.');
        }

        $this->jpModel->update($id, [
            'nama'      => trim($this->request->getPost('nama')),
            'deskripsi' => trim($this->request->getPost('deskripsi')),
            'status'    => $this->request->getPost('status'),
        ]);

        return redirect()->to(base_url('admin/scm/jenis-pekerjaan'))->with('success', 'Data jenis pekerjaan berhasil diperbarui!');
    }

    public function toggleStatus($id)
    {
        $id = (int) $id;
        $jp = $this->jpModel->find($id);
        if (!$jp) {
            return redirect()->to(base_url('admin/scm/jenis-pekerjaan'))->with('error', 'Data tidak ditemukan.');
        }

        $newStatus = ($jp['status'] === 'aktif') ? 'nonaktif' : 'aktif';
        $this->jpModel->update($id, ['status' => $newStatus]);

        return redirect()->to(base_url('admin/scm/jenis-pekerjaan'))->with('success', "Status jenis pekerjaan {$jp['nama']} diubah menjadi " . strtoupper($newStatus));
    }
}