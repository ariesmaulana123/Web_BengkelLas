<?php

namespace App\Controllers\Admin\SCM;

use App\Controllers\Admin\BaseAdminController;

class Material extends BaseAdminController
{
    public function index()
    {
        $id_jp = $this->request->getGet('id_jp') ? (int) $this->request->getGet('id_jp') : null;
        $kategori = $this->request->getGet('kategori') ? trim($this->request->getGet('kategori')) : null;

        $list = $this->materialModel->getAllMaterialsWithPrice($id_jp, $kategori);
        $jpList = $this->jpModel->orderBy('nama', 'ASC')->findAll();

        $data = [
            'title'        => 'SCM - Master Material',
            'pageTitle'    => 'Katalog Material & Bahan',
            'pageSubtitle' => 'Kelola database material komponen, rangka, atap, dan jasa yang terintegrasi dengan kalkulator.',
            'list'         => $list,
            'jpList'       => $jpList,
            'selectedJp'   => $id_jp,
            'selectedKat'  => $kategori,
        ];

        return $this->renderAdmin('admin/scm/material', $data);
    }

    public function store()
    {
        $rules = [
            'id_jp'         => 'required|is_natural_no_zero',
            'kategori'      => 'required|in_list[rangka,atap,tiang,jasa,utama,aksesoris,lainnya]',
            'nama_material' => 'required|min_length[3]|max_length[150]',
            'satuan'        => 'required|max_length[20]',
            'panjang_standar' => 'required|numeric|greater_than[0]',
            'harga'         => 'required|numeric|greater_than_equal_to[0]',
            'status'        => 'required|in_list[aktif,nonaktif]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Validasi form material gagal. Periksa kembali input Anda.');
        }

        $db = \Config\Database::connect();
        $db->transStart();

        $this->materialModel->insert([
            'id_jp'         => (int) $this->request->getPost('id_jp'),
            'kategori'      => $this->request->getPost('kategori'),
            'nama_material' => trim($this->request->getPost('nama_material')),
            'satuan'        => trim($this->request->getPost('satuan')),
            'panjang_standar' => (float) $this->request->getPost('panjang_standar'),
            'status'        => $this->request->getPost('status'),
        ]);

        $id_material = $this->materialModel->getInsertID();

        // Simpan harga di master_harga
        $this->hargaModel->setHargaMaterial(
            (int) $id_material,
            (float) $this->request->getPost('harga'),
            $this->request->getPost('status')
        );

        $db->transComplete();

        return redirect()->to(base_url('admin/scm/material'))->with('success', 'Material baru beserta harga berhasil disimpan ke database!');
    }

    public function update($id)
    {
        $id = (int) $id;
        $mat = $this->materialModel->find($id);
        if (!$mat) {
            return redirect()->to(base_url('admin/scm/material'))->with('error', 'Material tidak ditemukan.');
        }

        $rules = [
            'id_jp'         => 'required|is_natural_no_zero',
            'kategori'      => 'required|in_list[rangka,atap,tiang,jasa,utama,aksesoris,lainnya]',
            'nama_material' => 'required|min_length[3]|max_length[150]',
            'satuan'        => 'required|max_length[20]',
            'panjang_standar' => 'required|numeric|greater_than[0]',
            'harga'         => 'required|numeric|greater_than_equal_to[0]',
            'status'        => 'required|in_list[aktif,nonaktif]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Validasi gagal.');
        }

        $db = \Config\Database::connect();
        $db->transStart();

        $this->materialModel->update($id, [
            'id_jp'         => (int) $this->request->getPost('id_jp'),
            'kategori'      => $this->request->getPost('kategori'),
            'nama_material' => trim($this->request->getPost('nama_material')),
            'satuan'        => trim($this->request->getPost('satuan')),
            'panjang_standar' => (float) $this->request->getPost('panjang_standar'),
            'status'        => $this->request->getPost('status'),
        ]);

        $this->hargaModel->setHargaMaterial(
            $id,
            (float) $this->request->getPost('harga'),
            $this->request->getPost('status')
        );

        $db->transComplete();

        return redirect()->to(base_url('admin/scm/material'))->with('success', 'Data material dan harga berhasil diperbarui!');
    }

    public function toggleStatus($id)
    {
        $id = (int) $id;
        $mat = $this->materialModel->find($id);
        if (!$mat) {
            return redirect()->to(base_url('admin/scm/material'))->with('error', 'Material tidak ditemukan.');
        }

        $newStatus = ($mat['status'] === 'aktif') ? 'nonaktif' : 'aktif';
        $this->materialModel->update($id, ['status' => $newStatus]);
        $this->hargaModel->where('id_material', $id)->set(['status' => $newStatus])->update();

        return redirect()->to(base_url('admin/scm/material'))->with('success', "Status material {$mat['nama_material']} diubah menjadi " . strtoupper($newStatus));
    }
}