<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\EstimasiModel;
use App\Models\EstimasiDetailModel;
use App\Models\JenisPekerjaanModel;
use App\Models\MaterialModel;
use App\Models\MasterHargaModel;
use App\Models\ProyekModel;
use App\Models\FollowUpModel;
use App\Models\PengaturanPerusahaanModel;

class BaseAdminController extends BaseController
{
    protected UserModel $userModel;
    protected EstimasiModel $estimasiModel;
    protected EstimasiDetailModel $detailModel;
    protected JenisPekerjaanModel $jpModel;
    protected MaterialModel $materialModel;
    protected MasterHargaModel $hargaModel;
    protected ProyekModel $proyekModel;
    protected FollowUpModel $followUpModel;
    protected PengaturanPerusahaanModel $settingsModel;

    protected array $sharedData = [];

    public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        $this->userModel      = new UserModel();
        $this->estimasiModel  = new EstimasiModel();
        $this->detailModel    = new EstimasiDetailModel();
        $this->jpModel        = new JenisPekerjaanModel();
        $this->materialModel  = new MaterialModel();
        $this->hargaModel     = new MasterHargaModel();
        $this->proyekModel    = new ProyekModel();
        $this->followUpModel  = new FollowUpModel();
        $this->settingsModel  = new PengaturanPerusahaanModel();

        // Notifikasi proyek dipisahkan per peran dan hilang setelah halaman proyek dibuka.
        $badgeEstimasiBaru = $this->estimasiModel
            ->where('sumber', 'manual')
            ->whereIn('status', ['baru', 'pengajuan_survey', 'dihitung'])
            ->countAllResults();
        $currentUserRole = session()->get('role');
        $currentUserId = (int) session()->get('id_user');
        $projectReadAt = session()->get($currentUserRole === 'tukang' ? 'proyek_tukang_read_at' : 'proyek_admin_read_at');
        $projectNotificationQuery = $this->proyekModel
            ->where('created_at >', $projectReadAt ?: '1970-01-01 00:00:00');

        if ($currentUserRole === 'tukang') {
            $badgeProyekTukang = $projectNotificationQuery
                ->where('id_tukang', $currentUserId)
                ->whereIn('status', ['rencana', 'proses_fabrikasi', 'finishing', 'pemasangan'])
                ->countAllResults();
            $badgeProyekAdmin = 0;
        } else {
            $badgeProyekAdmin = $projectNotificationQuery
                ->whereIn('status', ['rencana', 'proses_fabrikasi', 'finishing', 'pemasangan'])
                ->countAllResults();
            $badgeProyekTukang = 0;
        }

        $this->sharedData = [
            'badgeEstimasiBaru' => $badgeEstimasiBaru,
            'badgeProyekAdmin'  => $badgeProyekAdmin,
            'badgeProyekTukang' => $badgeProyekTukang,
            'companySettings'   => $this->settingsModel->getSettings(),
            'currentUserId'     => $currentUserId,
            'currentUserRole'   => $currentUserRole,
            'currentUserName'   => session()->get('nama'),
        ];
    }

    /**
     * Render admin view with merged shared layout data
     */
    protected function renderAdmin(string $viewPath, array $data = [])
    {
        $mergedData = array_merge($this->sharedData, $data);
        return view($viewPath, $mergedData);
    }
}