<?php

namespace App\Controllers\Admin;

class Dashboard extends BaseAdminController
{
    public function index()
    {
        $role = session()->get('role');
        $id_user = (int) session()->get('id_user');
        $db = \Config\Database::connect();

        if ($role === 'tukang') {
            // METRIK KHUSUS TUKANG (Hanya data alokasi pekerjaan pribadi)
            $alokasiRow = $db->table('proyek')
                ->selectSum('nilai_tukang', 'total_alokasi')
                ->where('id_tukang', $id_user)
                ->get()->getRowArray();

            $totalNilaiAlokasiTukang = (float) ($alokasiRow['total_alokasi'] ?? 0);

            // Total Proyek Aktif
            $proyekAktifCount = $this->proyekModel
                ->where('id_tukang', $id_user)
                ->whereIn('status', ['rencana', 'proses_fabrikasi', 'finishing', 'pemasangan'])
                ->countAllResults();

            $proyekSelesaiCount = $this->proyekModel
                ->where('id_tukang', $id_user)
                ->where('status', 'selesai')
                ->countAllResults();

            $totalProyekTukang = $this->proyekModel
                ->where('id_tukang', $id_user)
                ->countAllResults();

            // Recent Projects (Top 5)
            $recentProyek = $this->proyekModel->getProyekList($id_user, null, 'tukang');
            $recentProyek = array_slice($recentProyek, 0, 5);

            $data = [
                'title'                   => 'Dashboard Teknisi Fabrikasi',
                'pageTitle'               => 'Portal Kerja Teknisi',
                'pageSubtitle'            => 'Pantau tugas pengerjaan bengkel, status progres fabrikasi, dan ringkasan nilai alokasi Anda.',
                'role'                    => 'tukang',
                'totalNilaiAlokasiTukang' => $totalNilaiAlokasiTukang,
                'proyekAktifCount'        => $proyekAktifCount,
                'proyekSelesaiCount'      => $proyekSelesaiCount,
                'totalProyekTukang'       => $totalProyekTukang,
                'recentProyek'            => $recentProyek,
                // Nilai finansial dan estimasi kosong demi keamanan data
                'totalOmzet'              => 0,
                'totalDp'                 => 0,
                'totalSisa'               => 0,
                'totalAlokasiTukang'      => 0,
                'estStats'                => ['total' => 0, 'baru' => 0, 'dihubungi' => 0, 'survey' => 0, 'penawaran' => 0, 'deal' => 0, 'ditolak' => 0],
                'totalCustomer'           => 0,
                'recentEstimasi'          => [],
                'recentFollowUp'          => [],
            ];
        } else {
            // METRIK LENGKAP EKSEKUTIF ADMIN
            $totalOmzetRow = $db->table('proyek')
                ->selectSum('nilai_proyek', 'total_omzet')
                ->selectSum('dp', 'total_dp')
                ->selectSum('sisa_pembayaran', 'total_sisa')
                ->selectSum('nilai_tukang', 'total_nilai_tukang')
                ->get()->getRowArray();

            $totalOmzet         = (float) ($totalOmzetRow['total_omzet'] ?? 0);
            $totalDp            = (float) ($totalOmzetRow['total_dp'] ?? 0);
            $totalSisa          = (float) ($totalOmzetRow['total_sisa'] ?? 0);
            $totalAlokasiTukang = (float) ($totalOmzetRow['total_nilai_tukang'] ?? 0);

            // Estimasi Stats
            $estStats = $this->estimasiModel->getDashboardStats();

            // Total Proyek Aktif
            $proyekAktifCount = $this->proyekModel->whereIn('status', ['rencana', 'proses_fabrikasi', 'finishing', 'pemasangan'])->countAllResults();
            $proyekSelesaiCount = $this->proyekModel->where('status', 'selesai')->countAllResults();

            // Total Customer
            $totalCustomer = $this->userModel->where('role', 'customer')->countAllResults();

            // Recent Estimations (Top 5)
            $recentEstimasi = $this->estimasiModel->getEstimasiCRM(null, null);
            $recentEstimasi = array_slice($recentEstimasi, 0, 5);

            // Recent Projects (Top 5)
            $recentProyek = $this->proyekModel->getProyekList(null, null, 'admin');
            $recentProyek = array_slice($recentProyek, 0, 5);

            // Upcoming Follow Ups (Top 5)
            $recentFollowUp = $this->followUpModel->getFollowUpList();
            $recentFollowUp = array_slice($recentFollowUp, 0, 5);

            $data = [
                'title'                   => 'Dashboard Eksekutif',
                'pageTitle'               => 'Dashboard Bengkel',
                'pageSubtitle'            => 'Ringkasan operasional workshop, pengajuan estimasi pelanggan, dan status proyek aktif.',
                'role'                    => 'admin',
                'totalOmzet'              => $totalOmzet,
                'totalDp'                 => $totalDp,
                'totalSisa'               => $totalSisa,
                'totalAlokasiTukang'      => $totalAlokasiTukang,
                'estStats'                => $estStats,
                'proyekAktifCount'        => $proyekAktifCount,
                'proyekSelesaiCount'      => $proyekSelesaiCount,
                'totalCustomer'           => $totalCustomer,
                'recentEstimasi'          => $recentEstimasi,
                'recentProyek'            => $recentProyek,
                'recentFollowUp'          => $recentFollowUp,
                'totalNilaiAlokasiTukang' => 0,
                'totalProyekTukang'       => 0,
            ];
        }

        return $this->renderAdmin('admin/dashboard/index', $data);
    }
}