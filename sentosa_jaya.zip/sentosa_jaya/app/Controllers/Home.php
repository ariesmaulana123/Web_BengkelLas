<?php

namespace App\Controllers;

use App\Models\JenisPekerjaanModel;
use App\Models\PengaturanPerusahaanModel;

class Home extends BaseController
{
    public function index(): string
    {
        $jpModel = new JenisPekerjaanModel();
        $jenisPekerjaan = $jpModel->getActiveList();
        $settings = (new PengaturanPerusahaanModel())->getSettings();
        $clientTestimonials = $this->getClientTestimonials();

        $data = [
            'title'          => 'Sentosa Jaya Las - Bengkel Las & Steel Fabrication Profesional Bekasi',
            'isLoggedIn'     => session()->get('isLoggedIn') ?? false,
            'currentUser'    => session()->get('isLoggedIn') ? [
                'id_user' => session()->get('id_user'),
                'nama'    => session()->get('nama'),
                'email'   => session()->get('email'),
                'no_wa'   => session()->get('no_wa'),
                'role'    => session()->get('role'),
            ] : null,
            'jenisPekerjaan' => $jenisPekerjaan,
            'companySettings'=> $settings,
            'clientTestimonials' => $clientTestimonials,
            'company' => [
                'name'     => $settings['nama_perusahaan'] ?? 'Sentosa Jaya Las',
                'tagline'  => $settings['tagline'] ?? 'Solusi Fabrikasi Besi untuk Hunian, Bisnis & Proyek',
                'phone'    => $settings['no_wa'] ?? '087766364557',
                'whatsapp' => $settings['no_wa'] ?? '087766364557',
                'email'    => $settings['email'] ?? 'sentosajayalas.1@gmail.com',
                'address'  => $settings['alamat'] ?? 'Jl. Raya Setu, Kec. Setu, Kabupaten Bekasi, Jawa Barat 17320',
                'hours'    => 'Senin - Sabtu: 08.00 - 17.00 WIB',
            ],
        ];

        return view('landing', $data);
    }

    public function submitRating()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Request tidak valid.',
            ]);
        }

        $input = $this->request->getJSON(true) ?? $this->request->getPost();

        if (!empty($input['website'] ?? '')) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Terima kasih atas rating Anda.',
            ]);
        }

        $testimonial = [
            'id' => 'rtg-' . date('YmdHis') . '-' . bin2hex(random_bytes(3)),
            'rating' => max(1, min(5, (int) ($input['rating'] ?? 5))),
            'name' => $this->cleanText($input['name'] ?? '', 80),
            'project' => $this->cleanText($input['project'] ?? '', 120),
            'message' => $this->cleanText($input['message'] ?? '', 260),
            'created_at' => date('Y-m-d H:i:s'),
        ];

        if ($testimonial['name'] === '' || $testimonial['project'] === '' || $testimonial['message'] === '') {
            return $this->response->setStatusCode(422)->setJSON([
                'status' => 'error',
                'message' => 'Mohon lengkapi nama, proyek/lokasi, dan ulasan.',
            ]);
        }

        $testimonials = $this->getClientTestimonials();
        array_unshift($testimonials, $testimonial);
        $testimonials = array_slice($testimonials, 0, 20);
        $this->saveClientTestimonials($testimonials);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Rating berhasil ditambahkan ke Testimoni Klien.',
            'data' => $testimonial,
        ]);
    }

    private function cleanText($value, int $maxLength): string
    {
        $value = trim(strip_tags((string) $value));
        $value = preg_replace('/\s+/', ' ', $value);

        if (function_exists('mb_substr')) {
            return mb_substr($value, 0, $maxLength);
        }

        return substr($value, 0, $maxLength);
    }

    private function getClientTestimonials(): array
    {
        $path = $this->getTestimonialsPath();
        if (!is_file($path)) {
            return [];
        }

        $contents = file_get_contents($path);
        $data = json_decode($contents ?: '[]', true);

        return is_array($data) ? $data : [];
    }

    private function saveClientTestimonials(array $testimonials): void
    {
        $path = $this->getTestimonialsPath();
        $dir = dirname($path);

        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        file_put_contents(
            $path,
            json_encode($testimonials, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );
    }

    private function getTestimonialsPath(): string
    {
        return WRITEPATH . 'data' . DIRECTORY_SEPARATOR . 'client_testimonials.json';
    }
}
