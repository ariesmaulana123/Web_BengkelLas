<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    protected UserModel $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    /**
     * Halaman Login
     */
    public function login()
    {
        if (session()->get('isLoggedIn')) {
            $role = session()->get('role');
            if ($role === 'admin' || $role === 'tukang') {
                return redirect()->to(base_url('admin/dashboard'));
            }
            return redirect()->to(base_url('riwayat'));
        }

        $data = [
            'title'    => 'Masuk ke Akun - Sentosa Jaya Las',
            'redirect' => $this->request->getGet('redirect') ?? '',
        ];

        return view('auth/login', $data);
    }

    /**
     * Proses Login
     */
    public function processLogin()
    {
        $rules = [
            'email'    => 'required|valid_email',
            'password' => 'required',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $email    = trim($this->request->getPost('email'));
        $password = $this->request->getPost('password');

        $user = $this->userModel->findByEmail($email);

        if (!$user) {
            return redirect()->back()->withInput()->with('error', 'Email tidak ditemukan.');
        }

        if (!password_verify($password, $user['password'])) {
            return redirect()->back()->withInput()->with('error', 'Password yang Anda masukkan salah.');
        }

        // Set session
        $sessionData = [
            'id_user'    => (int) $user['id_user'],
            'nama'       => $user['nama'],
            'email'      => $user['email'],
            'no_wa'      => $user['no_wa'],
            'role'       => $user['role'],
            'isLoggedIn' => true,
        ];
        session()->set($sessionData);

        $redirect = $this->request->getPost('redirect');
        if (!empty($redirect) && str_starts_with($redirect, '/')) {
            return redirect()->to(base_url($redirect));
        }

        if ($user['role'] === 'admin' || $user['role'] === 'tukang') {
            return redirect()->to(base_url('admin/dashboard'))->with('success', 'Selamat datang kembali di Admin Portal, ' . esc($user['nama']) . '!');
        }

        return redirect()->to(base_url('riwayat'))->with('success', 'Selamat datang kembali, ' . esc($user['nama']) . '!');
    }

    /**
     * Halaman Registrasi
     */
    public function register()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to(base_url('riwayat'));
        }

        $data = [
            'title' => 'Daftar Akun Baru - Sentosa Jaya Las',
        ];

        return view('auth/register', $data);
    }

    /**
     * Proses Registrasi
     */
    public function processRegister()
    {
        $rules = [
            'nama'             => 'required|min_length[3]|max_length[100]',
            'email'            => 'required|valid_email|is_unique[users.email]',
            'no_wa'            => 'required|min_length[8]|max_length[20]|is_unique[users.no_wa]',
            'password'         => 'required|min_length[6]',
            'password_confirm' => 'required|matches[password]',
        ];

        $messages = [
            'email' => [
                'is_unique' => 'Email ini sudah terdaftar. Silakan login.',
            ],
            'no_wa' => [
                'is_unique' => 'Nomor WhatsApp ini sudah terdaftar.',
            ],
            'password_confirm' => [
                'matches' => 'Konfirmasi password tidak cocok dengan password.',
            ],
        ];

        if (!$this->validate($rules, $messages)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $userData = [
            'nama'       => trim($this->request->getPost('nama')),
            'email'      => trim($this->request->getPost('email')),
            'no_wa'      => trim($this->request->getPost('no_wa')),
            'password'   => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
            'role'       => 'customer',
        ];

        $this->userModel->insert($userData);
        $userId = $this->userModel->getInsertID();

        // Auto login
        $sessionData = [
            'id_user'    => (int) $userId,
            'nama'       => $userData['nama'],
            'email'      => $userData['email'],
            'no_wa'      => $userData['no_wa'],
            'role'       => 'customer',
            'isLoggedIn' => true,
        ];
        session()->set($sessionData);

        return redirect()->to(base_url('/#kalkulator'))->with('success', 'Pendaftaran akun berhasil! Selamat datang di Sentosa Jaya Las.');
    }

    /**
     * Logout
     */
    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('/'))->with('info', 'Anda telah berhasil keluar.');
    }
}

