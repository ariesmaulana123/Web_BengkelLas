<?php

namespace App\Controllers;

use App\Models\JenisPekerjaanModel;
use App\Models\MaterialModel;
use App\Models\EstimasiModel;
use App\Models\EstimasiDetailModel;
use App\Models\UserModel;

class Kalkulator extends BaseController
{
    protected JenisPekerjaanModel $jpModel;
    protected MaterialModel $materialModel;
    protected EstimasiModel $estimasiModel;
    protected EstimasiDetailModel $detailModel;
    protected UserModel $userModel;

    public function __construct()
    {
        $this->jpModel       = new JenisPekerjaanModel();
        $this->materialModel = new MaterialModel();
        $this->estimasiModel = new EstimasiModel();
        $this->detailModel   = new EstimasiDetailModel();
        $this->userModel     = new UserModel();
    }

    /**
     * API: Mengambil daftar material aktif berdasarkan id_jp
     */
    public function getMaterials($id_jp)
    {
        $id_jp = (int) $id_jp;
        $materials = $this->materialModel->getMaterialsByJp($id_jp);

        return $this->response->setJSON([
            'status' => 'success',
            'data'   => $materials,
        ]);
    }

    /**
     * API: Menghitung estimasi dengan mendelegasikan logika ke engine Python
     */
    public function hitung()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(400)->setJSON([
                'status'  => 'error',
                'message' => 'Invalid request method.',
            ]);
        }

        $input = $this->request->getJSON(true) ?? $this->request->getPost();

        $payload = [
            'id_jp'              => (int) ($input['id_jp'] ?? 0),
            'panjang'            => (float) ($input['panjang'] ?? 0),
            'lebar'              => (float) ($input['lebar'] ?? 0),
            'tinggi'             => isset($input['tinggi']) && $input['tinggi'] !== '' ? (float) $input['tinggi'] : null,
            'id_material_rangka' => !empty($input['id_material_rangka']) ? (int) $input['id_material_rangka'] : null,
            'id_material_atap'   => !empty($input['id_material_atap']) ? (int) $input['id_material_atap'] : null,
            'id_material_tiang'  => !empty($input['id_material_tiang']) ? (int) $input['id_material_tiang'] : null,
            'id_material_utama'  => !empty($input['id_material_utama']) ? (int) $input['id_material_utama'] : null,
            'qty_unit'           => max(1, (int) ($input['qty_unit'] ?? 1)),
            'jarak_jeruji'       => (float) ($input['jarak_jeruji'] ?? 8),
            'items'              => is_array($input['items'] ?? null) ? $input['items'] : null,
            'catatan'            => trim($input['catatan'] ?? ''),
        ];

        // Jalankan kalkulator engine Python
        $pythonPath = 'python';
        $pythonPath = $this->getPythonPath();
        $scriptPath = APPPATH . 'Python' . DIRECTORY_SEPARATOR . 'estimator.py';

        if (!file_exists($scriptPath)) {
            return $this->response->setStatusCode(500)->setJSON([
                'status'  => 'error',
                'message' => 'Engine kalkulator Python tidak ditemukan di server.',
            ]);
        }

        $command = escapeshellcmd($pythonPath) . ' ' . escapeshellarg($scriptPath);
        $command = '"' . $pythonPath . '" "' . $scriptPath . '"';
        $descriptors = [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];

        $process = proc_open($command, $descriptors, $pipes, ROOTPATH);
        if (!is_resource($process)) {
            return $this->response->setStatusCode(500)->setJSON([
                'status'  => 'error',
                'message' => 'Gagal mengeksekusi engine kalkulator Python.',
            ]);
        }

        // Kirim data JSON ke Python melalui STDIN
        fwrite($pipes[0], json_encode($payload));
        fclose($pipes[0]);

        $stdout = stream_get_contents($pipes[1]);
        fclose($pipes[1]);

        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[2]);

        $exitCode = proc_close($process);

        $result = json_decode($stdout, true);

        if (!$result) {
            return $this->response->setStatusCode(500)->setJSON([
                'status'  => 'error',
                'message' => 'Gagal membaca respon kalkulasi dari engine Python.',
                'raw'     => $stdout,
                'stderr'  => $stderr,
            ]);
        }

        if (isset($result['status']) && $result['status'] === 'error') {
            return $this->response->setStatusCode(422)->setJSON($result);
        }

        return $this->response->setJSON($result);
    }

    /**
     * API: Menyimpan data estimasi ke database dan menyiapkan notifikasi pengajuan survey
     */
    public function simpan()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(400)->setJSON([
                'status'  => 'error',
                'message' => 'Invalid request method.',
            ]);
        }

        $input = $this->request->getJSON(true) ?? $this->request->getPost();
        $sessionUserId = session()->get('isLoggedIn') ? (int) session()->get('id_user') : 0;
        $user = $sessionUserId > 0 ? $this->userModel->find($sessionUserId) : null;
        $id_user = $user ? $sessionUserId : null;

        // 1. Eksekusi kalkulasi ulang di Python untuk menjamin integritas data (mencegah manipulasi harga dari client)
        $payload = [
            'id_jp'              => (int) ($input['id_jp'] ?? 0),
            'panjang'            => (float) ($input['panjang'] ?? 0),
            'lebar'              => (float) ($input['lebar'] ?? 0),
            'tinggi'             => isset($input['tinggi']) && $input['tinggi'] !== '' ? (float) $input['tinggi'] : null,
            'id_material_rangka' => !empty($input['id_material_rangka']) ? (int) $input['id_material_rangka'] : null,
            'id_material_atap'   => !empty($input['id_material_atap']) ? (int) $input['id_material_atap'] : null,
            'id_material_tiang'  => !empty($input['id_material_tiang']) ? (int) $input['id_material_tiang'] : null,
            'id_material_utama'  => !empty($input['id_material_utama']) ? (int) $input['id_material_utama'] : null,
            'qty_unit'           => max(1, (int) ($input['qty_unit'] ?? 1)),
            'jarak_jeruji'       => (float) ($input['jarak_jeruji'] ?? 8),
            'items'              => is_array($input['items'] ?? null) ? $input['items'] : null,
            'catatan'            => trim($input['catatan'] ?? ''),
        ];

        $pythonPath = $this->getPythonPath();
        $scriptPath = APPPATH . 'Python' . DIRECTORY_SEPARATOR . 'estimator.py';
        $command = escapeshellcmd('python') . ' ' . escapeshellarg($scriptPath);
        $command = '"' . $pythonPath . '" "' . $scriptPath . '"';
        $descriptors = [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];

        $process = proc_open($command, $descriptors, $pipes, ROOTPATH);
        if (!is_resource($process)) {
            return $this->response->setStatusCode(500)->setJSON([
                'status'  => 'error',
                'message' => 'Gagal memvalidasi data kalkulasi pada server.',
            ]);
        }

        fwrite($pipes[0], json_encode($payload));
        fclose($pipes[0]);
        $stdout = stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[2]);
        proc_close($process);

        $calcResult = json_decode($stdout, true);
        if (!$calcResult || ($calcResult['status'] ?? '') !== 'success') {
            return $this->response->setStatusCode(422)->setJSON([
                'status'  => 'error',
                'message' => $calcResult['message'] ?? 'Validasi perhitungan gagal.',
            ]);
        }

        $calcData = $calcResult['data'];

        // 2. Simpan ke tabel `estimasi`
        $db = \Config\Database::connect();
        $db->transStart();

        $estimasiData = [
            'id_user'      => $id_user,
            'id_jp'        => (int) $calcData['id_jp'],
            'panjang'      => (float) $calcData['panjang'],
            'lebar'        => (float) $calcData['lebar'],
            'tinggi'       => $calcData['tinggi'] !== null ? (float) $calcData['tinggi'] : null,
            'luas'         => (float) $calcData['luas'],
            'subtotal'     => (float) $calcData['subtotal'],
            'estimasi_min' => (float) $calcData['estimasi_min'],
            'estimasi_max' => (float) $calcData['estimasi_max'],
            'catatan'      => $calcData['catatan'] ?? '',
            'sumber'       => 'kalkulator',
            'status'       => 'dihitung',
        ];

        $this->estimasiModel->insert($estimasiData);
        $id_estimasi = $this->estimasiModel->getInsertID();

        // 3. Simpan rincian ke tabel `estimasi_detail`
        if (!empty($calcData['breakdown']) && is_array($calcData['breakdown'])) {
            foreach ($calcData['breakdown'] as $item) {
                $detailData = [
                    'id_estimasi' => (int) $id_estimasi,
                    'id_material' => (int) $item['id_material'],
                    'qty'         => (float) $item['qty'],
                    'harga'       => (float) $item['harga'],
                    'subtotal'    => (float) $item['subtotal'],
                    'created_at'  => date('Y-m-d H:i:s'),
                ];
                $this->detailModel->insert($detailData);
            }
        }

        $db->transComplete();

        if ($db->transStatus() === false) {
            return $this->response->setStatusCode(500)->setJSON([
                'status'  => 'error',
                'message' => 'Gagal menyimpan transaksi estimasi ke database.',
            ]);
        }

        if (!$id_user) {
            $guestIds = session()->get('guest_estimasi_ids') ?? [];
            $guestIds = is_array($guestIds) ? $guestIds : [];
            $guestIds[] = (int) $id_estimasi;
            session()->set('guest_estimasi_ids', array_values(array_unique(array_map('intval', $guestIds))));
        }

        return $this->response->setJSON([
            'status'      => 'success',
            'message'     => 'Estimasi berhasil disimpan ke riwayat.',
            'id_estimasi' => $id_estimasi,
            'redirect'    => base_url('riwayat'),
        ]);
    }

    /**
     * Halaman Khusus Riwayat Hasil Estimasi & Pengajuan Survey Pelanggan
     */
    public function riwayat()
    {
        $sessionUserId = session()->get('isLoggedIn') ? (int) session()->get('id_user') : 0;
        $user = $sessionUserId > 0 ? $this->userModel->find($sessionUserId) : null;
        $guestIds = session()->get('guest_estimasi_ids') ?? [];
        $estimasiList = $user
            ? $this->estimasiModel->getEstimasiByUser($sessionUserId)
            : $this->estimasiModel->getEstimasiRiwayat(null, is_array($guestIds) ? $guestIds : []);

        // Ambil rincian material untuk setiap estimasi
        foreach ($estimasiList as &$est) {
            $est['details'] = $this->detailModel->getDetails((int) $est['id_estimasi']);
        }
        unset($est);

        $data = [
            'title'        => 'Riwayat Estimasi Saya - Sentosa Jaya Las',
            'currentUser'  => $user ?? ['nama' => 'Pengunjung', 'no_wa' => '-'],
            'isLoggedIn'   => (bool) $user,
            'estimasiList' => $estimasiList,
        ];

        return view('kalkulator/riwayat', $data);
    }

    /**
     * Mendapatkan path binary Python yang valid di server / Windows
     */
    protected function getPythonPath(): string
    {
        // 1. Cek environment variable jika dikonfigurasi
        $envPython = getenv('PYTHON_PATH');
        if ($envPython && file_exists($envPython)) {
            return $envPython;
        }

        // 2. Daftar kandidat path instalasi Python umum di Windows
        $candidates = [
            'C:\\Users\\maula\\AppData\\Local\\Programs\\Python\\Python314\\python.exe',
            'C:\\Users\\maula\\AppData\\Local\\Programs\\Python\\Python313\\python.exe',
            'C:\\Users\\maula\\AppData\\Local\\Programs\\Python\\Python312\\python.exe',
            'C:\\Users\\maula\\AppData\\Local\\Programs\\Python\\Python311\\python.exe',
            'C:\\laragon\\bin\\python\\python.exe',
            'C:\\Python314\\python.exe',
            'C:\\Python313\\python.exe',
            'C:\\Python312\\python.exe',
            'C:\\Python311\\python.exe',
            'C:\\Program Files\\Python314\\python.exe',
            'C:\\Program Files\\Python313\\python.exe',
            'C:\\Program Files\\Python312\\python.exe',
            'C:\\Program Files\\Python311\\python.exe',
            'C:\\Windows\\py.exe',
        ];

        foreach ($candidates as $path) {
            if (file_exists($path)) {
                return $path;
            }
        }

        // 3. Cek via where.exe di Windows jika tersedia di PATH
        if (DIRECTORY_SEPARATOR === '\\') {
            $where = @shell_exec('where.exe python 2>NUL');
            if ($where) {
                $lines = explode("\n", trim($where));
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!empty($line) && file_exists($line) && !str_contains($line, 'WindowsApps')) {
                        return $line;
                    }
                }
            }
        }

        return 'python';
    }
}

