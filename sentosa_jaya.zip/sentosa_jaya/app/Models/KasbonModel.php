<?php

namespace App\Models;

use CodeIgniter\Model;

class KasbonModel extends Model
{
    protected $table            = 'kasbon_tukang';
    protected $primaryKey       = 'id_kasbon';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'id_proyek',
        'id_tukang',
        'id_admin',
        'nominal',
        'tanggal_kasbon',
        'keterangan',
        'metode_pembayaran',
        'bukti_transfer',
        'created_at',
        'updated_at',
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    /**
     * Get all kasbon with joined project, tukang, and admin info
     */
    public function getAllKasbon(?int $idTukang = null, ?int $idProyek = null)
    {
        $builder = $this->select('kasbon_tukang.*, 
                                  proyek.kode_proyek, proyek.nama_proyek, proyek.nilai_tukang, proyek.status as status_proyek,
                                  tukang.nama as nama_tukang, tukang.no_wa as no_wa_tukang,
                                  admin.nama as nama_admin')
            ->join('proyek', 'proyek.id_proyek = kasbon_tukang.id_proyek', 'left')
            ->join('users as tukang', 'tukang.id_user = kasbon_tukang.id_tukang', 'left')
            ->join('users as admin', 'admin.id_user = kasbon_tukang.id_admin', 'left');

        if ($idTukang !== null) {
            $builder->where('kasbon_tukang.id_tukang', $idTukang);
        }

        if ($idProyek !== null) {
            $builder->where('kasbon_tukang.id_proyek', $idProyek);
        }

        return $builder->orderBy('kasbon_tukang.tanggal_kasbon', 'DESC')
                       ->orderBy('kasbon_tukang.id_kasbon', 'DESC')
                       ->findAll();
    }

    /**
     * Get kasbon history for a specific project
     */
    public function getKasbonByProyek(int $idProyek)
    {
        return $this->select('kasbon_tukang.*, tukang.nama as nama_tukang, admin.nama as nama_admin')
            ->join('users as tukang', 'tukang.id_user = kasbon_tukang.id_tukang', 'left')
            ->join('users as admin', 'admin.id_user = kasbon_tukang.id_admin', 'left')
            ->where('kasbon_tukang.id_proyek', $idProyek)
            ->orderBy('kasbon_tukang.tanggal_kasbon', 'DESC')
            ->orderBy('kasbon_tukang.id_kasbon', 'DESC')
            ->findAll();
    }

    /**
     * Calculate total kasbon disbursed for a specific project
     */
    public function getTotalKasbonByProyek(int $idProyek): float
    {
        $result = $this->selectSum('nominal', 'total')
            ->where('id_proyek', $idProyek)
            ->first();

        return (float) ($result['total'] ?? 0);
    }

    /**
     * Calculate total kasbon disbursed for a specific tukang
     */
    public function getTotalKasbonByTukang(int $idTukang): float
    {
        $result = $this->selectSum('nominal', 'total')
            ->where('id_tukang', $idTukang)
            ->first();

        return (float) ($result['total'] ?? 0);
    }
}
