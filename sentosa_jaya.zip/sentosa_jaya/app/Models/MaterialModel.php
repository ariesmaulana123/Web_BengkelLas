<?php

namespace App\Models;

use CodeIgniter\Model;

class MaterialModel extends Model
{
    protected $table            = 'material';
    protected $primaryKey       = 'id_material';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['id_jp', 'kategori', 'nama_material', 'satuan', 'panjang_standar', 'status'];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    /**
     * Mengambil daftar material aktif beserta harga aktif berdasarkan jenis pekerjaan (digunakan kalkulator)
     */
    public function getMaterialsByJp(int $id_jp)
    {
        return $this->select('material.id_material, material.id_jp, material.kategori, material.nama_material, material.satuan, master_harga.harga')
            ->join('master_harga', 'material.id_material = master_harga.id_material AND master_harga.status = "aktif"', 'inner')
            ->where('material.id_jp', $id_jp)
            ->where('material.status', 'aktif')
            ->orderBy('material.kategori', 'ASC')
            ->orderBy('material.nama_material', 'ASC')
            ->findAll();
    }

    /**
     * Mengambil seluruh material untuk admin SCM (termasuk yang non-aktif beserta harganya)
     */
    public function getAllMaterialsWithPrice(?int $id_jp = null, ?string $kategori = null)
    {
        $builder = $this->select('material.*, jenis_pekerjaan.nama AS nama_jp, master_harga.harga, master_harga.id_mharg, master_harga.status AS status_harga')
            ->join('jenis_pekerjaan', 'material.id_jp = jenis_pekerjaan.id_jp', 'inner')
            ->join('master_harga', 'material.id_material = master_harga.id_material', 'left');

        if ($id_jp) {
            $builder->where('material.id_jp', $id_jp);
        }

        if ($kategori) {
            $builder->where('material.kategori', $kategori);
        }

        return $builder->orderBy('jenis_pekerjaan.nama', 'ASC')
            ->orderBy('material.kategori', 'ASC')
            ->orderBy('material.nama_material', 'ASC')
            ->findAll();
    }
}