<?php

namespace App\Models;

use CodeIgniter\Model;

class MasterHargaModel extends Model
{
    protected $table            = 'master_harga';
    protected $primaryKey       = 'id_mharg';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['id_material', 'harga', 'status'];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    /**
     * Ambil data harga beserta informasi material dan jenis pekerjaan
     */
    public function getHargaWithMaterial(?int $id_jp = null)
    {
        $builder = $this->select('master_harga.*, material.nama_material, material.kategori, material.satuan, material.id_jp, jenis_pekerjaan.nama AS nama_jp')
            ->join('material', 'master_harga.id_material = material.id_material', 'inner')
            ->join('jenis_pekerjaan', 'material.id_jp = jenis_pekerjaan.id_jp', 'inner');

        if ($id_jp) {
            $builder->where('material.id_jp', $id_jp);
        }

        return $builder->orderBy('jenis_pekerjaan.nama', 'ASC')
            ->orderBy('material.kategori', 'ASC')
            ->orderBy('material.nama_material', 'ASC')
            ->findAll();
    }

    /**
     * Simpan atau update harga aktif untuk suatu material
     */
    public function setHargaMaterial(int $id_material, float $harga, string $status = 'aktif')
    {
        $existing = $this->where('id_material', $id_material)->first();
        if ($existing) {
            return $this->update($existing['id_mharg'], [
                'harga'  => $harga,
                'status' => $status,
            ]);
        }

        return $this->insert([
            'id_material' => $id_material,
            'harga'       => $harga,
            'status'      => $status,
        ]);
    }
}