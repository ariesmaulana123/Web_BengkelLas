<?php

namespace App\Models;

use CodeIgniter\Model;

class PengaturanPerusahaanModel extends Model
{
    protected $table            = 'pengaturan_perusahaan';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'nama_perusahaan',
        'tagline',
        'alamat',
        'no_wa',
        'email',
        'nama_bank',
        'no_rekening',
        'atas_nama_bank',
        'logo',
        'nama_penanggung_jawab',
        'jabatan_penanggung_jawab',
        'catatan_penawaran'
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    /**
     * Ambil data profil perusahaan singleton
     */
    public function getSettings()
    {
        $settings = $this->find(1);
        if (!$settings) {
            $settings = [
                'id'                      => 1,
                'nama_perusahaan'         => 'Sentosa Jaya Las',
                'tagline'                 => 'Bengkel Las & Konstruksi Baja Presisi Bergaransi',
                'alamat'                  => 'Jl. Raya Industri Metal No. 88, Jabodetabek',
                'no_wa'                   => '087766364557',
                'email'                   => 'info@sentosajayalas.com',
                'nama_bank'               => 'Bank Central Asia (BCA)',
                'no_rekening'             => '8735-0912-33',
                'atas_nama_bank'          => 'Sentosa Jaya Las',
                'logo'                    => null,
                'nama_penanggung_jawab'   => 'Bambang Sentosa',
                'jabatan_penanggung_jawab'=> 'Kepala Workshop & Estimator Senior',
                'catatan_penawaran'       => "1. Harga sudah termasuk material, fabrikasi, dan pemasangan di lokasi.\n2. Garansi konstruksi 12 bulan.",
            ];
            $this->insert($settings);
            $settings = $this->find(1);
        }
        return $settings;
    }
}
