<?php

namespace App\Models;

use CodeIgniter\Model;

class FollowUpModel extends Model
{
    protected $table            = 'follow_up';
    protected $primaryKey       = 'id_follow_up';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'id_estimasi',
        'id_proyek',
        'id_user_admin',
        'tipe',
        'metode',
        'hasil',
        'tanggal_follow_up',
        'tanggal_next_follow_up',
        'created_at'
    ];

    protected $useTimestamps = false;

    /**
     * Mengambil daftar follow-up dengan informasi relasi
     */
    public function getFollowUpList(?int $id_estimasi = null, ?int $id_proyek = null)
    {
        $builder = $this->select('follow_up.*, admin.nama AS nama_admin, estimasi.id_user AS id_customer, customer.nama AS nama_customer, customer.no_wa AS no_wa_customer, proyek.kode_proyek, proyek.nama_proyek')
            ->join('users AS admin', 'follow_up.id_user_admin = admin.id_user', 'inner')
            ->join('estimasi', 'follow_up.id_estimasi = estimasi.id_estimasi', 'left')
            ->join('users AS customer', 'estimasi.id_user = customer.id_user', 'left')
            ->join('proyek', 'follow_up.id_proyek = proyek.id_proyek', 'left');

        if ($id_estimasi) {
            $builder->where('follow_up.id_estimasi', $id_estimasi);
        }

        if ($id_proyek) {
            $builder->where('follow_up.id_proyek', $id_proyek);
        }

        return $builder->orderBy('follow_up.tanggal_follow_up', 'DESC')->findAll();
    }
}