<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id_user';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $allowedFields    = ['nama', 'email', 'no_wa', 'password', 'role'];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Validation
    protected $validationRules = [
        'nama'     => 'required|min_length[3]|max_length[100]',
        'email'    => 'required|valid_email|is_unique[users.email,id_user,{id_user}]',
        'no_wa'    => 'required|min_length[8]|max_length[20]|is_unique[users.no_wa,id_user,{id_user}]',
    ];

    protected $validationMessages = [
        'email' => [
            'is_unique' => 'Email ini sudah terdaftar. Silakan gunakan email lain atau login.',
        ],
        'no_wa' => [
            'is_unique' => 'Nomor WhatsApp ini sudah terdaftar.',
        ],
    ];

    public function findByEmail(string $email)
    {
        return $this->where('email', $email)->first();
    }

    /**
     * Mengambil daftar customer beserta riwayat total estimasi dan proyek mereka
     */
    public function getCustomerList(?string $search = null)
    {
        $builder = $this->select('users.*, 
            COUNT(DISTINCT estimasi.id_estimasi) AS total_estimasi,
            COUNT(DISTINCT proyek.id_proyek) AS total_proyek,
            COALESCE(SUM(proyek.nilai_proyek), 0) AS total_nilai_proyek')
            ->where('users.role', 'customer')
            ->join('estimasi', 'users.id_user = estimasi.id_user', 'left')
            ->join('proyek', 'users.id_user = proyek.id_user', 'left')
            ->groupBy('users.id_user');

        if ($search) {
            $builder->groupStart()
                ->like('users.nama', $search)
                ->orLike('users.email', $search)
                ->orLike('users.no_wa', $search)
                ->groupEnd();
        }

        return $builder->orderBy('users.created_at', 'DESC')->findAll();
    }

    /**
     * Mengambil daftar tukang aktif
     */
    public function getTukangList()
    {
        return $this->where('role', 'tukang')->orderBy('nama', 'ASC')->findAll();
    }
}