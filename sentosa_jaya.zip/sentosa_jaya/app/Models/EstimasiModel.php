<?php

namespace App\Models;

use CodeIgniter\Model;

class EstimasiModel extends Model
{
    protected $table            = 'estimasi';
    protected $primaryKey       = 'id_estimasi';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'id_user',
        'nama_customer_manual',
        'no_wa_manual',
        'id_jp',
        'nama_pekerjaan',
        'panjang',
        'lebar',
        'tinggi',
        'ukuran_lubang',
        'luas',
        'qty_unit',
        'material_custom',
        'subtotal',
        'harga_bahan',
        'harga_jasa',
        'estimasi_min',
        'estimasi_max',
        'biaya_jasa',
        'biaya_pengiriman',
        'biaya_tambahan',
        'diskon',
        'total_final',
        'catatan',
        'catatan_admin',
        'tanggal_survey',
        'lokasi_survey',
        'sumber',
        'status'
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    /**
     * Mengambil riwayat estimasi user beserta relasi jenis pekerjaan
     */
    public function getEstimasiByUser(int $id_user)
    {
        return $this->select("estimasi.*, COALESCE(NULLIF(estimasi.nama_pekerjaan, ''), jenis_pekerjaan.nama, 'Estimasi Fabrikasi') AS nama_jp")
            ->join('jenis_pekerjaan', 'estimasi.id_jp = jenis_pekerjaan.id_jp', 'left')
            ->where('estimasi.id_user', $id_user)
            ->where('estimasi.sumber', 'kalkulator')
            ->orderBy('estimasi.created_at', 'DESC')
            ->findAll();
    }

    /**
     * Mengambil riwayat estimasi untuk pengguna login atau pengunjung guest
     */
    public function getEstimasiRiwayat(?int $id_user = null, array $guestIds = [])
    {
        $builder = $this->select("estimasi.*, COALESCE(NULLIF(estimasi.nama_pekerjaan, ''), jenis_pekerjaan.nama, 'Estimasi Fabrikasi') AS nama_jp")
            ->join('jenis_pekerjaan', 'estimasi.id_jp = jenis_pekerjaan.id_jp', 'left')
            ->where('estimasi.sumber', 'kalkulator');

        if ($id_user && $id_user > 0) {
            $builder->where('estimasi.id_user', $id_user);
        } elseif (!empty($guestIds)) {
            $builder->whereIn('estimasi.id_estimasi', $guestIds);
        } else {
            return [];
        }

        return $builder->orderBy('estimasi.created_at', 'DESC')->findAll();
    }

    /**
     * Mengambil seluruh data pekerjaan manual untuk Admin (dengan filter status & pencarian)
     */
    public function getEstimasiCRM(?string $status = null, ?string $search = null, ?string $sumber = 'manual')
    {
        $builder = $this->select("estimasi.*, 
            COALESCE(NULLIF(estimasi.nama_customer_manual, ''), NULLIF(users.nama, ''), 'Customer WhatsApp') AS nama_customer, 
            COALESCE(NULLIF(users.email, ''), '-') AS email_customer, 
            COALESCE(NULLIF(estimasi.no_wa_manual, ''), NULLIF(users.no_wa, ''), '-') AS no_wa_customer, 
            COALESCE(NULLIF(estimasi.nama_pekerjaan, ''), jenis_pekerjaan.nama, 'Pekerjaan Custom') AS nama_jp,
            jenis_pekerjaan.nama AS nama_jenis_pekerjaan")
            ->join('users', 'estimasi.id_user = users.id_user', 'left')
            ->join('jenis_pekerjaan', 'estimasi.id_jp = jenis_pekerjaan.id_jp', 'left');

        if ($sumber && $sumber !== 'all') {
            $builder->where('estimasi.sumber', $sumber);
        }

        if ($status && $status !== 'all') {
            if ($status === 'baru') {
                $builder->whereIn('estimasi.status', ['baru', 'pengajuan_survey', 'dihitung', 'deal_wa']);
            } else {
                $builder->where('estimasi.status', $status);
            }
        }

        if ($search) {
            $cleanId = str_replace(['#EST-', '#est-', '#PKJ-', '#pkj-', 'EST-', 'est-', 'PKJ-', 'pkj-'], '', $search);
            $builder->groupStart()
                ->like('users.nama', $search)
                ->orLike('estimasi.nama_customer_manual', $search)
                ->orLike('users.no_wa', $search)
                ->orLike('estimasi.no_wa_manual', $search)
                ->orLike('estimasi.nama_pekerjaan', $search)
                ->orLike('jenis_pekerjaan.nama', $search)
                ->orLike('estimasi.material_custom', $search)
                ->orLike('estimasi.catatan', $search)
                ->orLike('estimasi.id_estimasi', $cleanId)
                ->groupEnd();
        }

        return $builder->orderBy('estimasi.created_at', 'DESC')->findAll();
    }

    /**
     * Mengambil detail lengkap 1 pekerjaan / estimasi beserta customer dan jenis pekerjaan
     */
    public function getEstimasiDetail(int $id_estimasi)
    {
        return $this->select("estimasi.*, 
            COALESCE(NULLIF(estimasi.nama_customer_manual, ''), NULLIF(users.nama, ''), 'Customer WhatsApp') AS nama_customer, 
            COALESCE(NULLIF(users.email, ''), '-') AS email_customer, 
            COALESCE(NULLIF(estimasi.no_wa_manual, ''), NULLIF(users.no_wa, ''), '-') AS no_wa_customer, 
            COALESCE(NULLIF(estimasi.nama_pekerjaan, ''), jenis_pekerjaan.nama, 'Pekerjaan Custom') AS nama_jp,
            jenis_pekerjaan.nama AS nama_jenis_pekerjaan,
            jenis_pekerjaan.deskripsi AS deskripsi_jp")
            ->join('users', 'estimasi.id_user = users.id_user', 'left')
            ->join('jenis_pekerjaan', 'estimasi.id_jp = jenis_pekerjaan.id_jp', 'left')
            ->where('estimasi.id_estimasi', $id_estimasi)
            ->first();
    }

    /**
     * Menghitung total statistik pekerjaan manual untuk Dashboard
     */
    public function getDashboardStats()
    {
        $totalEstimasi = (new self())->where('sumber', 'manual')->countAllResults();
        $baru = (new self())->where('sumber', 'manual')->whereIn('status', ['baru', 'pengajuan_survey', 'dihitung', 'deal_wa'])->countAllResults();
        $survey = (new self())->where('sumber', 'manual')->where('status', 'survey')->countAllResults();
        $penawaran = (new self())->where('sumber', 'manual')->where('status', 'penawaran')->countAllResults();
        $deal = (new self())->where('sumber', 'manual')->where('status', 'deal')->countAllResults();
        $ditolak = (new self())->where('sumber', 'manual')->where('status', 'ditolak')->countAllResults();

        return [
            'total'     => $totalEstimasi,
            'baru'      => $baru,
            'survey'    => $survey,
            'penawaran' => $penawaran,
            'deal'      => $deal,
            'ditolak'   => $ditolak,
        ];
    }
}
