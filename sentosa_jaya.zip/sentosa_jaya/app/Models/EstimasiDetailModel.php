<?php

namespace App\Models;

use CodeIgniter\Model;

class EstimasiDetailModel extends Model
{
    protected $table            = 'estimasi_detail';
    protected $primaryKey       = 'id_detail_est';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'id_estimasi',
        'id_material',
        'qty',
        'harga',
        'subtotal',
        'created_at'
    ];

    protected $useTimestamps = false; // Only created_at in schema

    /**
     * Mengambil detail material dari sebuah estimasi
     */
    public function getDetails(int $id_estimasi)
    {
        return $this->select('estimasi_detail.*, material.nama_material, material.kategori, material.satuan')
            ->join('material', 'estimasi_detail.id_material = material.id_material', 'left')
            ->where('estimasi_detail.id_estimasi', $id_estimasi)
            ->findAll();
    }
}

