<?php

namespace App\Models;

use CodeIgniter\Model;

class ProyekModel extends Model
{
    protected $table            = 'proyek';
    protected $primaryKey       = 'id_proyek';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'id_estimasi',
        'id_user',
        'id_tukang',
        'nilai_tukang',
        'pekerjaan_tukang',
        'kode_proyek',
        'nama_proyek',
        'nilai_proyek',
        'dp',
        'sisa_pembayaran',
        'status_pembayaran',
        'tanggal_mulai',
        'tanggal_target_selesai',
        'tanggal_selesai',
        'progress',
        'status',
        'catatan',
        'foto_dokumentasi'
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    /**
     * Mengambil daftar proyek dengan join user (customer), tukang, dan estimasi
     * Jika role = tukang, nilai_proyek, dp, sisa_pembayaran, dan status_pembayaran tidak diseleksi demi keamanan data.
     */
    public function getProyekList(?int $id_tukang = null, ?string $status = null, string $role = 'admin')
    {
        $builder = $this->db->table($this->table);

        if ($role === 'tukang') {
            // Whitelist fields khusus Tukang: tidak menyertakan nilai_proyek, dp, sisa_pembayaran, status_pembayaran
            $builder->select('proyek.id_proyek, proyek.id_estimasi, proyek.id_user, proyek.id_tukang, 
                             proyek.nilai_tukang, proyek.pekerjaan_tukang, proyek.kode_proyek, proyek.nama_proyek, 
                             proyek.tanggal_mulai, proyek.tanggal_target_selesai, proyek.tanggal_selesai, 
                             proyek.progress, proyek.status, proyek.catatan, proyek.foto_dokumentasi, 
                             proyek.created_at, proyek.updated_at, 
                             customer.nama AS nama_customer, customer.no_wa AS no_wa_customer, customer.email AS email_customer, 
                             tukang.nama AS nama_tukang, jenis_pekerjaan.nama AS nama_jp');
        } else {
            $builder->select('proyek.*, customer.nama AS nama_customer, customer.no_wa AS no_wa_customer, customer.email AS email_customer, tukang.nama AS nama_tukang, jenis_pekerjaan.nama AS nama_jp');
        }

        $builder->join('users AS customer', 'proyek.id_user = customer.id_user', 'inner')
            ->join('users AS tukang', 'proyek.id_tukang = tukang.id_user', 'left')
            ->join('estimasi', 'proyek.id_estimasi = estimasi.id_estimasi', 'left')
            ->join('jenis_pekerjaan', 'estimasi.id_jp = jenis_pekerjaan.id_jp', 'left');

        if ($id_tukang) {
            $builder->where('proyek.id_tukang', $id_tukang);
        }

        if ($status) {
            $builder->where('proyek.status', $status);
        }

        return $builder->orderBy('proyek.created_at', 'DESC')->get()->getResultArray();
    }

    /**
     * Mengambil detail lengkap 1 proyek
     * Jika role = tukang, data finansial total proyek disembunyikan.
     */
    public function getProyekDetail(int $id_proyek, string $role = 'admin')
    {
        $builder = $this->db->table($this->table);

        if ($role === 'tukang') {
            // Whitelist fields khusus Tukang: tidak menyertakan nilai_proyek, dp, sisa_pembayaran, status_pembayaran, total_final
            $builder->select('proyek.id_proyek, proyek.id_estimasi, proyek.id_user, proyek.id_tukang, 
                             proyek.nilai_tukang, proyek.pekerjaan_tukang, proyek.kode_proyek, proyek.nama_proyek, 
                             proyek.tanggal_mulai, proyek.tanggal_target_selesai, proyek.tanggal_selesai, 
                             proyek.progress, proyek.status, proyek.catatan, proyek.foto_dokumentasi, 
                             proyek.created_at, proyek.updated_at, 
                             customer.nama AS nama_customer, customer.no_wa AS no_wa_customer, customer.email AS email_customer, 
                             tukang.nama AS nama_tukang, tukang.no_wa AS no_wa_tukang, jenis_pekerjaan.nama AS nama_jp, 
                             estimasi.panjang, estimasi.lebar, estimasi.tinggi, estimasi.luas, estimasi.catatan AS catatan_estimasi');
        } else {
            $builder->select('proyek.*, customer.nama AS nama_customer, customer.no_wa AS no_wa_customer, customer.email AS email_customer, tukang.nama AS nama_tukang, tukang.no_wa AS no_wa_tukang, jenis_pekerjaan.nama AS nama_jp, estimasi.panjang, estimasi.lebar, estimasi.tinggi, estimasi.luas, estimasi.total_final, estimasi.catatan AS catatan_estimasi');
        }

        $builder->join('users AS customer', 'proyek.id_user = customer.id_user', 'inner')
            ->join('users AS tukang', 'proyek.id_tukang = tukang.id_user', 'left')
            ->join('estimasi', 'proyek.id_estimasi = estimasi.id_estimasi', 'left')
            ->join('jenis_pekerjaan', 'estimasi.id_jp = jenis_pekerjaan.id_jp', 'left')
            ->where('proyek.id_proyek', $id_proyek);

        return $builder->get()->getRowArray();
    }

    /**
     * Generate Nomor/Kode Proyek Unik (Format: PRJ-YYYYMM-XXXX)
     */
    public function generateKodeProyek(): string
    {
        $prefix = 'PRJ-' . date('Ym') . '-';
        $last = $this->like('kode_proyek', $prefix, 'after')
            ->orderBy('id_proyek', 'DESC')
            ->first();

        if ($last) {
            $lastNum = (int) substr($last['kode_proyek'], -4);
            $nextNum = $lastNum + 1;
        } else {
            $nextNum = 1;
        }

        return $prefix . str_pad((string)$nextNum, 4, '0', STR_PAD_LEFT);
    }
}