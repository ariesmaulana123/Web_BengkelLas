<?php

namespace App\Models;

use CodeIgniter\Model;

class JenisPekerjaanModel extends Model
{
    protected $table            = 'jenis_pekerjaan';
    protected $primaryKey       = 'id_jp';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['nama', 'deskripsi', 'status'];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function getActiveList()
    {
        return $this->where('status', 'aktif')->orderBy('id_jp', 'ASC')->findAll();
    }
}

