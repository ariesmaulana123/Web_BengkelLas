#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sentosa Jaya Las - Estimator Engine (Python)
Menghitung estimasi biaya pekerjaan fabrikasi besi (Kanopi, Pagar, Railing, Teralis)
berdasarkan master harga dari database MySQL sentosa_jaya.
"""

import sys
import json
import os
import io
import math

# Pastikan encoding UTF-8 di Windows dan Linux
if hasattr(sys.stdout, 'buffer'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
if hasattr(sys.stderr, 'buffer'):
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
if hasattr(sys.stdin, 'buffer'):
    sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8')

import mysql.connector

# Konfigurasi Database (Bisa di-override lewat environment variables)
DB_HOST = os.environ.get("DB_HOST", "localhost")
DB_USER = os.environ.get("DB_USER", "root")
DB_PASS = os.environ.get("DB_PASS", "")
DB_NAME = os.environ.get("DB_NAME", "sentosa_jaya")
DB_PORT = int(os.environ.get("DB_PORT", 3306))

def get_db_connection():
    """Membuka koneksi aman ke database MySQL sentosa_jaya."""
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME,
        port=DB_PORT,
        charset="utf8mb4"
    )

def fetch_material_with_price(cursor, id_material):
    """Mengambil data material dan harga aktif dari database."""
    query = """
        SELECT m.id_material, m.id_jp, m.kategori, m.nama_material, m.satuan, m.panjang_standar,
               h.harga, jp.nama AS nama_jp
        FROM material m
        JOIN master_harga h ON m.id_material = h.id_material AND h.status = 'aktif'
        JOIN jenis_pekerjaan jp ON m.id_jp = jp.id_jp
        WHERE m.id_material = %s AND m.status = 'aktif'
        LIMIT 1
    """
    cursor.execute(query, (id_material,))
    row = cursor.fetchone()
    if not row:
        return None
    return {
        "id_material": row[0],
        "id_jp": row[1],
        "kategori": row[2],
        "nama_material": row[3],
        "satuan": row[4],
        "panjang_standar": float(row[5] or 0),
        "harga": float(row[6]),
        "nama_jp": row[7]
    }

def fetch_all_active_services(cursor, id_jp):
    """Mengambil semua komponen jasa aktif untuk jenis pekerjaan tertentu dari database."""
    query = """
        SELECT m.id_material, m.id_jp, m.kategori, m.nama_material, m.satuan, m.panjang_standar,
               h.harga, jp.nama AS nama_jp
        FROM material m
        JOIN master_harga h ON m.id_material = h.id_material AND h.status = 'aktif'
        JOIN jenis_pekerjaan jp ON m.id_jp = jp.id_jp
        WHERE m.id_jp = %s AND m.kategori IN ('jasa', 'aksesoris', 'lainnya') AND m.status = 'aktif'
        ORDER BY m.id_material ASC
    """
    cursor.execute(query, (id_jp,))
    rows = cursor.fetchall()
    services = []
    for row in rows:
        services.append({
            "id_material": row[0],
            "id_jp": row[1],
            "kategori": row[2],
            "nama_material": row[3],
            "satuan": row[4],
            "panjang_standar": float(row[5] or 0),
            "harga": float(row[6]),
            "nama_jp": row[7]
        })
    return services

def fetch_default_jasa(cursor, id_jp):
    """Mengambil jasa standar pertama untuk jenis pekerjaan tertentu."""
    services = fetch_all_active_services(cursor, id_jp)
    return services[0] if services else None

def calculate_estimation(payload):
    """
    Validasi dan kalkulasi estimasi biaya pekerjaan besi.
    Mendukung Kanopi, Pagar, Railing, serta kalkulasi berbasis kebutuhan material & ukuran untuk Teralis.
    """
    try:
        id_jp = int(payload.get("id_jp", 0))
        panjang = float(payload.get("panjang", 0) or 0)
        lebar = float(payload.get("lebar", 0) or 0)
        tinggi = float(payload.get("tinggi", 0)) if payload.get("tinggi") is not None and payload.get("tinggi") != '' else 0.0
        catatan = str(payload.get("catatan", "")).strip()
        
        # ID Material
        id_material_rangka = payload.get("id_material_rangka")
        id_material_atap = payload.get("id_material_atap")
        id_material_tiang = payload.get("id_material_tiang")
        id_material_utama = payload.get("id_material_utama")
        
        # Parameter Teralis spesifik
        jarak_jeruji = float(payload.get("jarak_jeruji", 8.0) or 8.0) # dalam cm
        qty_unit = int(payload.get("qty_unit", 1) or 1)
        items_payload = payload.get("items")
    except (ValueError, TypeError) as e:
        return {
            "status": "error",
            "message": f"Format input tidak valid: {str(e)}"
        }

    # 1. Koneksi ke Database
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
    except Exception as e:
        return {
            "status": "error",
            "message": f"Gagal terhubung ke database master harga: {str(e)}"
        }

    try:
        # Cek jenis pekerjaan di database
        cursor.execute("SELECT id_jp, nama FROM jenis_pekerjaan WHERE id_jp = %s AND status = 'aktif'", (id_jp,))
        jp_row = cursor.fetchone()
        if not jp_row:
            return {
                "status": "error",
                "message": f"Jenis pekerjaan dengan ID {id_jp} tidak ditemukan atau tidak aktif."
            }
        nama_jp = jp_row[1]
        nama_jp_lower = nama_jp.lower()

        breakdown = []
        subtotal = 0.0

        # =====================================================================
        # 2. LOGIKA KHUSUS TERALIS (Material-Requirement Based Calculation)
        # =====================================================================
        if nama_jp_lower in ["teralis", "tralis"]:
            # Normalisasi daftar item teralis (Multi-item support)
            tralis_items = []
            if items_payload and isinstance(items_payload, list) and len(items_payload) > 0:
                for idx, it in enumerate(items_payload):
                    it_lebar = float(it.get("lebar", 0) or 0)
                    it_tinggi = float(it.get("tinggi", 0) or it.get("panjang", 0) or 0)
                    if it_lebar <= 0 and float(it.get("panjang", 0) or 0) > 0:
                        it_lebar = float(it.get("panjang", 0))
                    it_qty = int(it.get("qty_unit", 1) or 1)
                    it_jarak = float(it.get("jarak_jeruji", jarak_jeruji) or jarak_jeruji)
                    it_mat_id = int(it.get("id_material_utama") or id_material_utama or id_material_rangka or 0)
                    
                    if it_lebar <= 0 or it_tinggi <= 0:
                        return {
                            "status": "error",
                            "message": f"Dimensi lebar dan tinggi pada item teralis #{idx+1} harus lebih besar dari 0."
                        }
                    if it_qty <= 0:
                        it_qty = 1
                    if not it_mat_id:
                        return {
                            "status": "error",
                            "message": f"Silakan pilih jenis besi untuk item teralis #{idx+1}."
                        }
                    
                    tralis_items.append({
                        "index": idx + 1,
                        "lebar": it_lebar,
                        "tinggi": it_tinggi,
                        "qty_unit": it_qty,
                        "jarak_jeruji": it_jarak,
                        "id_material_utama": it_mat_id,
                        "label": it.get("label", f"Teralis #{idx+1}")
                    })
            else:
                # Single item dari input standar
                selected_mat_id = id_material_utama or id_material_rangka
                if not selected_mat_id:
                    return {
                        "status": "error",
                        "message": "Silakan pilih jenis besi untuk teralis."
                    }
                
                # Gunakan lebar & tinggi yang diinput (atau panjang jika lebar/tinggi diisi di panjang)
                dim_lebar = lebar if lebar > 0 else panjang
                dim_tinggi = tinggi if tinggi > 0 else (panjang if lebar > 0 else 1.0)
                
                if dim_lebar <= 0 or dim_tinggi <= 0:
                    return {
                        "status": "error",
                        "message": "Lebar dan tinggi teralis harus lebih besar dari 0 meter."
                    }
                
                tralis_items.append({
                    "index": 1,
                    "lebar": dim_lebar,
                    "tinggi": dim_tinggi,
                    "qty_unit": max(1, qty_unit),
                    "jarak_jeruji": max(3.0, jarak_jeruji),
                    "id_material_utama": int(selected_mat_id),
                    "label": "Teralis Jendela"
                })

            # Hitung kebutuhan material & dimensi per item
            total_luas = 0.0
            total_units = 0
            material_meters_map = {} # {id_material: total_meter}
            item_summaries = []

            for it in tralis_items:
                w_m = it["lebar"]
                h_m = it["tinggi"]
                q = it["qty_unit"]
                s_cm = it["jarak_jeruji"]
                s_m = s_cm / 100.0 # konversi cm ke meter
                mat_id = it["id_material_utama"]

                # 1. Dimensi & Luas
                luas_1_unit = round(w_m * h_m, 3)
                luas_item_total = round(luas_1_unit * q, 2)
                total_luas += luas_item_total
                total_units += q

                # 2. Hitung Kebutuhan Besi Frame (Bingkai Keliling per unit)
                panjang_frame_1_unit = round(2.0 * (w_m + h_m), 2)
                panjang_frame_total = round(panjang_frame_1_unit * q, 2)

                # 3. Hitung Kebutuhan Besi Jeruji (Ruji-ruji vertikal per unit)
                jumlah_jeruji_1_unit = max(1, math.ceil(w_m / s_m) - 1)
                panjang_jeruji_1_unit = round(jumlah_jeruji_1_unit * h_m, 2)
                
                # Palang penguat horizontal tengah jika tinggi >= 1.0 meter
                palang_penguat_1_unit = round(1.0 * w_m, 2) if h_m >= 1.0 else 0.0
                
                # Total panjang besi per 1 unit teralis
                panjang_besi_1_unit = round(panjang_frame_1_unit + panjang_jeruji_1_unit + palang_penguat_1_unit, 2)
                panjang_besi_item_total = round(panjang_besi_1_unit * q, 2)

                # Akumulasi meter per material
                material_meters_map[mat_id] = material_meters_map.get(mat_id, 0.0) + panjang_besi_item_total

                # Catat ringkasan per item
                item_summaries.append({
                    "index": it["index"],
                    "label": it["label"],
                    "lebar": w_m,
                    "tinggi": h_m,
                    "qty_unit": q,
                    "jarak_jeruji_cm": s_cm,
                    "luas_per_unit": luas_1_unit,
                    "luas_total": luas_item_total,
                    "frame_per_unit_m": panjang_frame_1_unit,
                    "jeruji_per_unit_count": jumlah_jeruji_1_unit,
                    "jeruji_per_unit_m": panjang_jeruji_1_unit,
                    "palang_per_unit_m": palang_penguat_1_unit,
                    "total_meter_1_unit": panjang_besi_1_unit,
                    "total_meter_item": panjang_besi_item_total,
                    "id_material": mat_id
                })

            # 4. Hitung Biaya Material Besi (Berdasarkan jumlah batang standar 6 meter dari database)
            total_biaya_material = 0.0
            for mat_id, total_meter in material_meters_map.items():
                mat_info = fetch_material_with_price(cursor, mat_id)
                if not mat_info:
                    return {
                        "status": "error",
                        "message": f"Material besi ID {mat_id} tidak ditemukan atau belum memiliki harga aktif di database."
                    }

                # Konversi ke jumlah batang utuh standar 6 meter (dengan safety waste factor)
                panjang_batang = mat_info["panjang_standar"]
                if panjang_batang <= 0:
                    return {
                        "status": "error",
                        "message": f"Panjang standar material {mat_info['nama_material']} belum diatur di database."
                    }

                jumlah_batang = int(math.ceil(total_meter / panjang_batang))
                if jumlah_batang < 1:
                    jumlah_batang = 1

                harga_per_batang = mat_info["harga"]
                if "batang" in mat_info["satuan"].lower():
                    subtotal_mat = round(jumlah_batang * harga_per_batang, 2)
                    qty_display = float(jumlah_batang)
                    satuan_display = f"batang ({panjang_batang:g}m)"
                elif mat_info["satuan"].lower() == "m":
                    subtotal_mat = round(total_meter * harga_per_batang, 2)
                    qty_display = round(total_meter, 2)
                    satuan_display = "m"
                else:
                    subtotal_mat = round(jumlah_batang * harga_per_batang, 2)
                    qty_display = float(jumlah_batang)
                    satuan_display = f"batang ({panjang_batang:g}m)"

                breakdown.append({
                    "id_material": mat_info["id_material"],
                    "nama_material": f"{mat_info['nama_material']} (Total {total_meter:.1f} m)",
                    "kategori": "material",
                    "qty": qty_display,
                    "satuan": satuan_display,
                    "harga": harga_per_batang,
                    "subtotal": subtotal_mat
                })
                total_biaya_material += subtotal_mat
                subtotal += subtotal_mat

            # 5. Hitung Biaya Jasa Finishing, Fabrikasi, Pemasangan & Transport dari Database
            active_services = fetch_all_active_services(cursor, id_jp)
            total_biaya_jasa = 0.0
            
            if active_services:
                for srv in active_services:
                    srv_satuan = srv["satuan"].lower()
                    if "unit" in srv_satuan or "buah" in srv_satuan or "titik" in srv_satuan:
                        qty_srv = float(total_units)
                        subtotal_srv = round(qty_srv * srv["harga"], 2)
                    elif "m2" in srv_satuan:
                        qty_srv = float(total_luas)
                        subtotal_srv = round(qty_srv * srv["harga"], 2)
                    elif "m" in srv_satuan:
                        total_all_m = sum(material_meters_map.values())
                        qty_srv = float(round(total_all_m, 1))
                        subtotal_srv = round(qty_srv * srv["harga"], 2)
                    else:
                        qty_srv = float(total_units)
                        subtotal_srv = round(qty_srv * srv["harga"], 2)

                    breakdown.append({
                        "id_material": srv["id_material"],
                        "nama_material": srv["nama_material"],
                        "kategori": "jasa",
                        "qty": qty_srv,
                        "satuan": srv["satuan"],
                        "harga": srv["harga"],
                        "subtotal": subtotal_srv
                    })
                    total_biaya_jasa += subtotal_srv
                    subtotal += subtotal_srv

            # 6. Hitung Harga Satuan per 1 Unit Teralis dan Subtotal per Item
            harga_rata_rata_per_unit = round(subtotal / total_units, 2) if total_units > 0 else subtotal

            for it_sum in item_summaries:
                total_m_all = sum(material_meters_map.values())
                proporsi = it_sum["total_meter_item"] / total_m_all if total_m_all > 0 else 1.0
                it_subtotal = round(subtotal * proporsi, 2)
                it_sum["subtotal"] = it_subtotal
                it_sum["harga_per_unit"] = round(it_subtotal / it_sum["qty_unit"], 2)

            if len(item_summaries) == 1:
                first_it = item_summaries[0]
                panjang_disp = first_it["lebar"]
                lebar_disp = first_it["tinggi"]
                tinggi_disp = first_it["tinggi"]
            else:
                panjang_disp = item_summaries[0]["lebar"]
                lebar_disp = item_summaries[0]["tinggi"]
                tinggi_disp = None

            subtotal = round(subtotal, 2)
            estimasi_min = round(subtotal * 0.90, 2)
            estimasi_max = round(subtotal * 1.10, 2)

            return {
                "status": "success",
                "data": {
                    "id_jp": id_jp,
                    "nama_jp": nama_jp,
                    "panjang": panjang_disp,
                    "lebar": lebar_disp,
                    "tinggi": tinggi_disp,
                    "luas": round(total_luas, 2),
                    "total_units": total_units,
                    "harga_per_unit": harga_rata_rata_per_unit,
                    "item_summaries": item_summaries,
                    "breakdown": breakdown,
                    "subtotal": subtotal,
                    "estimasi_min": estimasi_min,
                    "estimasi_max": estimasi_max,
                    "catatan": catatan,
                    "disclaimer": "Perhitungan teralis di atas dihitung berdasarkan kebutuhan panjang besi aktual (jeruji, frame & palang tengah), konversi jumlah batang standar 6 meter, serta jasa finishing dan pemasangan dari database Sentosa Jaya Las. Total biaya final akan dikonfirmasi setelah survey pengukuran presisi di lokasi."
                }
            }

        # =====================================================================
        # 3. LOGIKA KANOPI
        # =====================================================================
        elif nama_jp_lower == "kanopi":
            # Validasi Dimensi & Luas Minimum
            if panjang <= 0 or lebar <= 0:
                return {
                    "status": "error",
                    "message": "Panjang dan lebar kanopi harus lebih besar dari 0 meter."
                }

            luas = round(panjang * lebar, 2)
            if luas < 2.0:
                return {
                    "status": "error",
                    "message": f"Luas pengerjaan ({luas:.2f} m²) kurang dari batas minimal 2.00 m²."
                }

            if not id_material_rangka or not id_material_atap:
                return {
                    "status": "error",
                    "message": "Silakan pilih jenis rangka dan jenis atap untuk kanopi."
                }

            # A. Rangka
            mat_rangka = fetch_material_with_price(cursor, id_material_rangka)
            if not mat_rangka:
                return {"status": "error", "message": "Material rangka tidak ditemukan atau belum memiliki harga aktif."}
            
            subtotal_rangka = round(luas * mat_rangka["harga"], 2)
            breakdown.append({
                "id_material": mat_rangka["id_material"],
                "nama_material": mat_rangka["nama_material"],
                "kategori": mat_rangka["kategori"],
                "qty": luas,
                "satuan": mat_rangka["satuan"],
                "harga": mat_rangka["harga"],
                "subtotal": subtotal_rangka
            })
            subtotal += subtotal_rangka

            # B. Atap
            mat_atap = fetch_material_with_price(cursor, id_material_atap)
            if not mat_atap:
                return {"status": "error", "message": "Material atap tidak ditemukan atau belum memiliki harga aktif."}
            
            subtotal_atap = round(luas * mat_atap["harga"], 2)
            breakdown.append({
                "id_material": mat_atap["id_material"],
                "nama_material": mat_atap["nama_material"],
                "kategori": mat_atap["kategori"],
                "qty": luas,
                "satuan": mat_atap["satuan"],
                "harga": mat_atap["harga"],
                "subtotal": subtotal_atap
            })
            subtotal += subtotal_atap

            # C. Tiang (Jika ada tinggi tiang yang diisi)
            if tinggi > 0:
                mat_tiang = fetch_material_with_price(cursor, id_material_tiang) if id_material_tiang else None
                if not mat_tiang:
                    cursor.execute("""
                        SELECT m.id_material FROM material m 
                        JOIN master_harga h ON m.id_material = h.id_material 
                        WHERE m.id_jp = %s AND m.kategori = 'tiang' AND m.status = 'aktif' LIMIT 1
                    """, (id_jp,))
                    t_row = cursor.fetchone()
                    if t_row:
                        mat_tiang = fetch_material_with_price(cursor, t_row[0])
                
                if mat_tiang:
                    qty_tiang = round(tinggi * 2.0, 2) if tinggi <= 4.0 else round(tinggi, 2)
                    subtotal_tiang = round(qty_tiang * mat_tiang["harga"], 2)
                    breakdown.append({
                        "id_material": mat_tiang["id_material"],
                        "nama_material": f"{mat_tiang['nama_material']} ({qty_tiang} m)",
                        "kategori": "tiang",
                        "qty": qty_tiang,
                        "satuan": mat_tiang["satuan"],
                        "harga": mat_tiang["harga"],
                        "subtotal": subtotal_tiang
                    })
                    subtotal += subtotal_tiang

            # D. Jasa Fabrikasi & Pemasangan Kanopi
            mat_jasa = fetch_default_jasa(cursor, id_jp)
            if mat_jasa:
                subtotal_jasa = round(luas * mat_jasa["harga"], 2)
                breakdown.append({
                    "id_material": mat_jasa["id_material"],
                    "nama_material": mat_jasa["nama_material"],
                    "kategori": "jasa",
                    "qty": luas,
                    "satuan": mat_jasa["satuan"],
                    "harga": mat_jasa["harga"],
                    "subtotal": subtotal_jasa
                })
                subtotal += subtotal_jasa

        # =====================================================================
        # 4. LOGIKA PAGAR & RAILING TANGGA
        # =====================================================================
        else:
            if panjang <= 0 or lebar <= 0:
                return {
                    "status": "error",
                    "message": "Panjang dan lebar harus lebih besar dari 0 meter."
                }

            luas = round(panjang * lebar, 2)
            if luas < 2.0:
                return {
                    "status": "error",
                    "message": f"Luas pengerjaan ({luas:.2f} m²) kurang dari batas minimal 2.00 m²."
                }

            selected_mat_id = id_material_utama or id_material_rangka
            if not selected_mat_id:
                return {
                    "status": "error",
                    "message": f"Silakan pilih jenis material/model untuk {nama_jp}."
                }

            mat_utama = fetch_material_with_price(cursor, selected_mat_id)
            if not mat_utama:
                return {"status": "error", "message": "Material tidak ditemukan atau belum memiliki harga aktif."}
            
            subtotal_utama = round(luas * mat_utama["harga"], 2)
            breakdown.append({
                "id_material": mat_utama["id_material"],
                "nama_material": mat_utama["nama_material"],
                "kategori": mat_utama["kategori"],
                "qty": luas,
                "satuan": mat_utama["satuan"],
                "harga": mat_utama["harga"],
                "subtotal": subtotal_utama
            })
            subtotal += subtotal_utama

            # Jasa Pasang & Fabrikasi
            mat_jasa = fetch_default_jasa(cursor, id_jp)
            if mat_jasa:
                subtotal_jasa = round(luas * mat_jasa["harga"], 2)
                breakdown.append({
                    "id_material": mat_jasa["id_material"],
                    "nama_material": mat_jasa["nama_material"],
                    "kategori": "jasa",
                    "qty": luas,
                    "satuan": mat_jasa["satuan"],
                    "harga": mat_jasa["harga"],
                    "subtotal": subtotal_jasa
                })
                subtotal += subtotal_jasa

        # 5. Hitung Range Estimasi (±10%)
        subtotal = round(subtotal, 2)
        estimasi_min = round(subtotal * 0.90, 2)
        estimasi_max = round(subtotal * 1.10, 2)

        return {
            "status": "success",
            "data": {
                "id_jp": id_jp,
                "nama_jp": nama_jp,
                "panjang": panjang,
                "lebar": lebar,
                "tinggi": tinggi if tinggi > 0 else None,
                "luas": luas,
                "breakdown": breakdown,
                "subtotal": subtotal,
                "estimasi_min": estimasi_min,
                "estimasi_max": estimasi_max,
                "catatan": catatan,
                "disclaimer": "Perhitungan di atas merupakan estimasi perkiraan awal. Total biaya final dan kebutuhan material riil akan ditentukan setelah tim Sentosa Jaya Las melakukan survey lokasi dan pengukuran detail secara langsung."
            }
        }

    except Exception as e:
        return {
            "status": "error",
            "message": f"Terjadi kesalahan saat memproses kalkulasi: {str(e)}"
        }
    finally:
        cursor.close()
        conn.close()

def main():
    """Fungsi utama pembaca input JSON dari argumen atau STDIN."""
    raw_input = ""
    if len(sys.argv) > 1:
        raw_input = sys.argv[1]
    else:
        raw_input = sys.stdin.read()

    if not raw_input or not raw_input.strip():
        print(json.dumps({
            "status": "error",
            "message": "Tidak ada data input yang diterima oleh engine kalkulator."
        }))
        sys.exit(1)

    raw_input = raw_input.strip().lstrip('\ufeff')

    try:
        payload = json.loads(raw_input)
    except Exception as e:
        print(json.dumps({
            "status": "error",
            "message": f"Format JSON input tidak valid: {str(e)}"
        }))
        sys.exit(1)

    result = calculate_estimation(payload)
    print(json.dumps(result, ensure_ascii=False))
    if result.get("status") == "error":
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == "__main__":
    main()
