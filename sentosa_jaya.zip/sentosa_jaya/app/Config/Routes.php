<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->post('/rating-bengkel', 'Home::submitRating');

// Auth Routes
$routes->get('/login', 'Auth::login');
$routes->post('/login', 'Auth::processLogin');
$routes->get('/register', 'Auth::register');
$routes->post('/register', 'Auth::processRegister');
$routes->get('/logout', 'Auth::logout');
$routes->post('/logout', 'Auth::logout');

// Customer Kalkulator Estimasi & Riwayat Routes
$routes->get('/kalkulator/materials/(:num)', 'Kalkulator::getMaterials/$1');
$routes->post('/kalkulator/hitung', 'Kalkulator::hitung');
$routes->post('/kalkulator/simpan', 'Kalkulator::simpan');
$routes->get('/riwayat', 'Kalkulator::riwayat');
$routes->get('/kalkulator/riwayat', 'Kalkulator::riwayat');

// ==========================================
// ADMIN PANEL ROUTES (Protected by 'admin' Filter)
// ADMIN & TUKANG PANEL ROUTES (Protected by 'admin' Filter)
// ==========================================
$routes->group('admin', ['filter' => 'admin'], static function ($routes) {
    // Dashboard
    $routes->get('/', 'Admin\Dashboard::index');
    $routes->get('dashboard', 'Admin\Dashboard::index');

    // SCM (Supply Chain Management)
    $routes->group('scm', static function ($routes) {
        // Jenis Pekerjaan
        $routes->get('jenis-pekerjaan', 'Admin\SCM\JenisPekerjaan::index');
        $routes->post('jenis-pekerjaan/store', 'Admin\SCM\JenisPekerjaan::store');
        $routes->post('jenis-pekerjaan/update/(:num)', 'Admin\SCM\JenisPekerjaan::update/$1');
        $routes->get('jenis-pekerjaan/toggle/(:num)', 'Admin\SCM\JenisPekerjaan::toggleStatus/$1');

        // Material
        $routes->get('material', 'Admin\SCM\Material::index');
        $routes->post('material/store', 'Admin\SCM\Material::store');
        $routes->post('material/update/(:num)', 'Admin\SCM\Material::update/$1');
        $routes->get('material/toggle/(:num)', 'Admin\SCM\Material::toggleStatus/$1');

        // Master Harga
        $routes->get('harga', 'Admin\SCM\Harga::index');
        $routes->post('harga/update/(:num)', 'Admin\SCM\Harga::updateSingle/$1');
        $routes->post('harga/bulk', 'Admin\SCM\Harga::bulkUpdate');
    });

    // CRM (Customer Relationship Management) & Proyek
    // CRM (Customer Relationship Management) & Proyek & Kasbon
    $routes->group('crm', static function ($routes) {
        // Estimasi
        $routes->get('estimasi', 'Admin\CRM\Estimasi::index');
        $routes->get('estimasi/create', 'Admin\CRM\Estimasi::create');
        $routes->post('estimasi/store', 'Admin\CRM\Estimasi::store');
        $routes->get('estimasi/edit/(:num)', 'Admin\CRM\Estimasi::edit/$1');
        $routes->post('estimasi/update/(:num)', 'Admin\CRM\Estimasi::update/$1');
        $routes->get('estimasi/detail/(:num)', 'Admin\CRM\Estimasi::detail/$1');
        $routes->post('estimasi/deal/(:num)', 'Admin\CRM\Estimasi::deal/$1');
        $routes->post('estimasi/alokasi/(:num)', 'Admin\CRM\Estimasi::updateAlokasi/$1');
        $routes->post('estimasi/kasbon/(:num)', 'Admin\CRM\Estimasi::simpanKasbon/$1');
        $routes->post('estimasi/convert/(:num)', 'Admin\CRM\Estimasi::convertToProject/$1');
        $routes->get('estimasi/pdf/(:num)', 'Admin\CRM\Estimasi::cetakPdf/$1');

        // Customer
        $routes->get('customer', 'Admin\CRM\Customer::index');
        $routes->get('customer/detail/(:num)', 'Admin\CRM\Customer::detail/$1');

        // Proyek
        $routes->get('proyek', 'Admin\CRM\Proyek::index');
        $routes->get('proyek/detail/(:num)', 'Admin\CRM\Proyek::detail/$1');
        $routes->post('proyek/update-progress/(:num)', 'Admin\CRM\Proyek::updateProgress/$1');
        $routes->post('proyek/tambah-kasbon/(:num)', 'Admin\CRM\Proyek::tambahKasbon/$1');
        $routes->get('proyek/hapus-kasbon/(:num)/(:num)', 'Admin\CRM\Proyek::hapusKasbon/$1/$2');

        // Kasbon Tukang (Dedicated Menu)
        $routes->get('kasbon', 'Admin\CRM\Kasbon::index');
        $routes->post('kasbon/store', 'Admin\CRM\Kasbon::store');
        $routes->get('kasbon/hapus/(:num)', 'Admin\CRM\Kasbon::delete/$1');

        // Follow Up
        $routes->get('follow-up', 'Admin\CRM\FollowUp::index');
        $routes->post('follow-up/store', 'Admin\CRM\FollowUp::store');
    });

    // Laporan
    $routes->get('laporan', 'Admin\Laporan::index');
    $routes->get('laporan/pdf', 'Admin\Laporan::cetakPdf');

    // Pengaturan Perusahaan & PDF
    $routes->get('pengaturan', 'Admin\Pengaturan::index');
    $routes->post('pengaturan/update', 'Admin\Pengaturan::update');

    // Manajemen Role & Pengguna
    $routes->get('users', 'Admin\Users::index');
    $routes->post('users/store', 'Admin\Users::store');
    $routes->post('users/update/(:num)', 'Admin\Users::update/$1');
    $routes->post('users/delete/(:num)', 'Admin\Users::delete/$1');

    // Profil Admin & Tukang
    $routes->get('profil', 'Admin\Profil::index');
    $routes->post('profil/update', 'Admin\Profil::update');
});
