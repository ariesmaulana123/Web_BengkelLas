<!-- Client Rating Section -->
<section id="rating-bengkel" class="py-20 bg-slate-950 relative overflow-hidden border-t border-slate-800">
  <div class="absolute inset-0 bg-industrial-grid opacity-25 pointer-events-none"></div>

  <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
      <div class="lg:col-span-5 space-y-5 reveal-fade-up">
        <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider">
          <span>Rating Bengkel Las</span>
        </div>

        <h2 class="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-display tracking-tight leading-tight">
          Bagikan Pengalaman Anda
        </h2>

        <p class="text-slate-300 text-base sm:text-lg font-normal leading-relaxed">
          Ceritakan kualitas pengerjaan, kerapian las, ketepatan jadwal, dan pelayanan tim Sentosa Jaya Las setelah proyek selesai.
        </p>

        <div class="grid grid-cols-3 gap-3 pt-3">
          <div class="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
            <p class="text-2xl font-black text-white font-mono">5.0</p>
            <p class="text-[11px] text-slate-400 uppercase tracking-wider">Target Rating</p>
          </div>
          <div class="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
            <p class="text-2xl font-black text-white font-mono">100%</p>
            <p class="text-[11px] text-slate-400 uppercase tracking-wider">Transparan</p>
          </div>
          <div class="rounded-2xl bg-slate-900/80 border border-slate-800 p-4">
            <p class="text-2xl font-black text-white font-mono">SNI</p>
            <p class="text-[11px] text-slate-400 uppercase tracking-wider">Material</p>
          </div>
        </div>
      </div>

      <div class="lg:col-span-7 reveal-fade-up">
        <form id="client-rating-form" class="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
          <input type="text" id="client-rating-website" name="website" class="hidden" tabindex="-1" autocomplete="off">

          <div id="rating-success-alert" class="hidden rounded-2xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">
            Terima kasih, rating Anda sudah ditambahkan ke Testimoni Klien.
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Rating pengerjaan</label>
            <input type="hidden" id="client-rating-value" value="5">
            <div class="flex items-center gap-2" role="group" aria-label="Pilih rating bengkel las">
              <?php for ($star = 1; $star <= 5; $star++): ?>
                <button type="button" class="rating-star-btn text-amber-400 hover:text-amber-300 transition-colors" data-rating-value="<?= $star ?>" aria-label="<?= $star ?> dari 5">
                  <svg class="w-9 h-9 fill-current" viewBox="0 0 20 20" aria-hidden="true">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                  </svg>
                </button>
              <?php endfor; ?>
            </div>
            <p id="client-rating-text" class="mt-2 text-xs text-amber-300 font-semibold">5 dari 5 - Sangat puas</p>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label for="client-reviewer-name" class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Nama klien</label>
              <input id="client-reviewer-name" type="text" maxlength="80" required placeholder="Contoh: Arief Maulana" class="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/60 focus:border-blue-500 text-sm">
            </div>
            <div>
              <label for="client-reviewer-project" class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Proyek / lokasi</label>
              <input id="client-reviewer-project" type="text" maxlength="120" required placeholder="Contoh: Kanopi rumah di Bekasi" class="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/60 focus:border-blue-500 text-sm">
            </div>
          </div>

          <div>
            <label for="client-reviewer-message" class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Ulasan</label>
            <textarea id="client-reviewer-message" rows="4" maxlength="260" required placeholder="Tulis pengalaman Anda dengan hasil pengerjaan Sentosa Jaya Las..." class="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/60 focus:border-blue-500 text-sm resize-none"></textarea>
          </div>

          <button type="submit" class="w-full inline-flex items-center justify-center px-6 py-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-base shadow-xl shadow-blue-600/25 hover:shadow-blue-500/40 transition-all duration-300">
            <span>Kirim Rating</span>
            <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
            </svg>
          </button>
        </form>
      </div>
    </div>
  </div>
</section>

