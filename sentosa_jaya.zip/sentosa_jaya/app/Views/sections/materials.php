<!-- Material & Finishing Section -->
<section class="py-24 bg-slate-900 relative overflow-hidden border-t border-slate-800">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Header -->
    <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Standar Mutu Material</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        Kombinasi Material SNI & <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Proteksi Anti-Karat Maksimal</span>
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Ketahanan sebuah struktur dimulai dari integritas bahan baku dan teknologi pelapisan cat yang tepat.
      </p>
    </div>

    <!-- 6 Material Cards Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      
      <!-- 1. Besi Hollow Galvanis -->
      <div class="p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 shadow-xl transition-all duration-300 group reveal-fade-up">
        <div class="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"/>
          </svg>
        </div>
        <h3 class="text-lg font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">Besi Hollow Galvanis SNI</h3>
        <p class="text-xs text-slate-400 leading-relaxed mb-4">
          Dilapisi zinc galvanis anti-karat dari pabrik dengan ketebalan profil 1.4mm hingga 2.3mm. Tidak mudah keropos terkena air hujan.
        </p>
        <span class="inline-block text-[11px] font-semibold text-blue-400 bg-blue-500/10 px-2.5 py-1 rounded-md border border-blue-500/20">
          Standar Pagar & Kanopi
        </span>
      </div>

      <!-- 2. Baja WF & H-Beam -->
      <div class="p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-sky-500/50 shadow-xl transition-all duration-300 group reveal-fade-up" style="transition-delay: 100ms;">
        <div class="w-12 h-12 rounded-xl bg-sky-600/10 border border-sky-500/20 text-sky-400 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-sky-600 group-hover:text-white transition-all">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5"/>
          </svg>
        </div>
        <h3 class="text-lg font-bold text-white mb-2 group-hover:text-sky-400 transition-colors">Baja WF & H-Beam Struktur</h3>
        <p class="text-xs text-slate-400 leading-relaxed mb-4">
          Baja profil berat untuk mezzanine beban tinggi, konstruksi gedung, dan rangka atap bentang lebar dengan sertifikasi uji tarik SNI.
        </p>
        <span class="inline-block text-[11px] font-semibold text-sky-400 bg-sky-500/10 px-2.5 py-1 rounded-md border border-sky-500/20">
          Kapasitas Beban Berat
        </span>
      </div>

      <!-- 3. Plat Besi CNC -->
      <div class="p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 shadow-xl transition-all duration-300 group reveal-fade-up" style="transition-delay: 200ms;">
        <div class="w-12 h-12 rounded-xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5"/>
          </svg>
        </div>
        <h3 class="text-lg font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">Plat Laser Cutting CNC</h3>
        <p class="text-xs text-slate-400 leading-relaxed mb-4">
          Plat baja SPHC 2.0mm - 3.0mm dipotong dengan mesin laser fiber berakurasi tinggi, menghasilkan motif ornamen geometris dan floral yang sangat presisi.
        </p>
        <span class="inline-block text-[11px] font-semibold text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-md border border-indigo-500/20">
          Estetika Mewah Modern
        </span>
      </div>

      <!-- 4. Stainless Steel 304 -->
      <div class="p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-cyan-500/50 shadow-xl transition-all duration-300 group reveal-fade-up">
        <div class="w-12 h-12 rounded-xl bg-cyan-600/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-cyan-600 group-hover:text-white transition-all">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/>
          </svg>
        </div>
        <h3 class="text-lg font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">Stainless Steel Grade 304</h3>
        <p class="text-xs text-slate-400 leading-relaxed mb-4">
          Logam nirkarat food & marine grade pilihan untuk railing balkon pantai, pintu pagar premium, serta aksen interior mirror/hairline finish.
        </p>
        <span class="inline-block text-[11px] font-semibold text-cyan-400 bg-cyan-500/10 px-2.5 py-1 rounded-md border border-cyan-500/20">
          100% Bebas Karat
        </span>
      </div>

      <!-- 5. Atap Alderon & Solarflat -->
      <div class="p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 shadow-xl transition-all duration-300 group reveal-fade-up" style="transition-delay: 100ms;">
        <div class="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 00-9.78 2.096A4.001 4.001 0 003 15z"/>
          </svg>
        </div>
        <h3 class="text-lg font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">Atap Premium Bergaransi</h3>
        <p class="text-xs text-slate-400 leading-relaxed mb-4">
          Pilihan atap uPVC Alderon Twinwall peredam panas & suara hujan, Solarflat solid anti-pecah 3mm, dan Kaca Tempered 8mm-10mm.
        </p>
        <span class="inline-block text-[11px] font-semibold text-blue-400 bg-blue-500/10 px-2.5 py-1 rounded-md border border-blue-500/20">
          Peredam Panas & Kedap Suara
        </span>
      </div>

      <!-- 6. Cat Epoxy & Polyurethane -->
      <div class="p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-sky-500/50 shadow-xl transition-all duration-300 group reveal-fade-up" style="transition-delay: 200ms;">
        <div class="w-12 h-12 rounded-xl bg-sky-600/10 border border-sky-500/20 text-sky-400 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-sky-600 group-hover:text-white transition-all">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/>
          </svg>
        </div>
        <h3 class="text-lg font-bold text-white mb-2 group-hover:text-sky-400 transition-colors">Finishing Cat Epoxy & PU</h3>
        <p class="text-xs text-slate-400 leading-relaxed mb-4">
          Aplikasi Zinc-Chromate Epoxy Primer 2 lapis dilanjutkan Topcoat Polyurethane (PU) 2K atau Powder Coating berdaya lekat tinggi tahan sinar UV matahari.
        </p>
        <span class="inline-block text-[11px] font-semibold text-sky-400 bg-sky-500/10 px-2.5 py-1 rounded-md border border-sky-500/20">
          Warna Awet Tahan Cuaca
        </span>
      </div>

    </div>

  </div>
</section>

