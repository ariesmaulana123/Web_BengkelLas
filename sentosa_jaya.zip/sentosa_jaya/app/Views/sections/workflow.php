<!-- Proses Kerja Section -->
<section id="proses-kerja" class="py-24 bg-slate-950 relative overflow-hidden">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Header -->
    <div class="text-center max-w-3xl mx-auto mb-20 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Alur Kerja Transparan</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        6 Tahapan Kerja <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Terstruktur & Rapi</span>
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Dari survey pengukuran hingga serah terima garansi, setiap langkah dijalankan dengan SOP yang disiplin demi kepuasan Anda.
      </p>
    </div>

    <!-- 6 Steps Grid with Step Numbers -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      
      <!-- Step 1: Konsultasi -->
      <div class="p-7 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/50 shadow-xl transition-all duration-300 relative group reveal-fade-up">
        <div class="flex items-center justify-between mb-6">
          <div class="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
            </svg>
          </div>
          <span class="text-3xl font-black text-slate-800 group-hover:text-blue-500/30 transition-colors font-display">01</span>
        </div>
        <h3 class="text-xl font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">1. Konsultasi</h3>
        <p class="text-xs text-slate-400 leading-relaxed">
          Diskusi mendalam mengenai kebutuhan desain, fungsi bangunan, preferensi material, serta kisaran anggaran yang Anda rencanakan.
        </p>
      </div>

      <!-- Step 2: Survey -->
      <div class="p-7 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-sky-500/50 shadow-xl transition-all duration-300 relative group reveal-fade-up" style="transition-delay: 100ms;">
        <div class="flex items-center justify-between mb-6">
          <div class="w-12 h-12 rounded-xl bg-sky-600/10 border border-sky-500/20 text-sky-400 flex items-center justify-center group-hover:bg-sky-600 group-hover:text-white transition-colors">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/>
            </svg>
          </div>
          <span class="text-3xl font-black text-slate-800 group-hover:text-sky-500/30 transition-colors font-display">02</span>
        </div>
        <h3 class="text-xl font-bold text-white mb-2 group-hover:text-sky-400 transition-colors">2. Survey Lokasi</h3>
        <p class="text-xs text-slate-400 leading-relaxed">
          Tim teknis kami datang langsung ke lokasi untuk mengukur dimensi secara akurat menggunakan alat ukur presisi dan mengecek kekuatan struktur dudukan.
        </p>
      </div>

      <!-- Step 3: Penawaran -->
      <div class="p-7 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-indigo-500/50 shadow-xl transition-all duration-300 relative group reveal-fade-up" style="transition-delay: 200ms;">
        <div class="flex items-center justify-between mb-6">
          <div class="w-12 h-12 rounded-xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
            </svg>
          </div>
          <span class="text-3xl font-black text-slate-800 group-hover:text-indigo-500/30 transition-colors font-display">03</span>
        </div>
        <h3 class="text-xl font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">3. Penawaran & Estimasi</h3>
        <p class="text-xs text-slate-400 leading-relaxed">
          Penyusunan rincian anggaran biaya (RAB) tertulis dengan spesifikasi jenis besi, ketebalan profil, tipe atap/cat, dan estimasi waktu selesai.
        </p>
      </div>

      <!-- Step 4: Produksi -->
      <div class="p-7 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 shadow-xl transition-all duration-300 relative group reveal-fade-up">
        <div class="flex items-center justify-between mb-6">
          <div class="w-12 h-12 rounded-xl bg-cyan-600/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center group-hover:bg-cyan-600 group-hover:text-white transition-colors">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"/>
            </svg>
          </div>
          <span class="text-3xl font-black text-slate-800 group-hover:text-cyan-500/30 transition-colors font-display">04</span>
        </div>
        <h3 class="text-xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">4. Produksi Workshop</h3>
        <p class="text-xs text-slate-400 leading-relaxed">
          Proses fabrikasi di workshop mencakup pemotongan, pengelasan matang, penghalusan gerinda, dan aplikasi primer epoxy anti-karat sebelum dikirim.
        </p>
      </div>

      <!-- Step 5: Instalasi -->
      <div class="p-7 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/50 shadow-xl transition-all duration-300 relative group reveal-fade-up" style="transition-delay: 100ms;">
        <div class="flex items-center justify-between mb-6">
          <div class="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
          </div>
          <span class="text-3xl font-black text-slate-800 group-hover:text-blue-500/30 transition-colors font-display">05</span>
        </div>
        <h3 class="text-xl font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">5. Instalasi di Lokasi</h3>
        <p class="text-xs text-slate-400 leading-relaxed">
          Pemasangan rapi dan kokoh menggunakan dynabolt/chemical anchor berkualitas oleh tim ahli. Area kerja dipastikan bersih pasca pengerjaan.
        </p>
      </div>

      <!-- Step 6: Serah Terima -->
      <div class="p-7 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 shadow-xl transition-all duration-300 relative group reveal-fade-up" style="transition-delay: 200ms;">
        <div class="flex items-center justify-between mb-6">
          <div class="w-12 h-12 rounded-xl bg-emerald-600/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
            </svg>
          </div>
          <span class="text-3xl font-black text-slate-800 group-hover:text-emerald-500/30 transition-colors font-display">06</span>
        </div>
        <h3 class="text-xl font-bold text-white mb-2 group-hover:text-emerald-400 transition-colors">6. Serah Terima & Garansi</h3>
        <p class="text-xs text-slate-400 leading-relaxed">
          Pengecekan bersama hasil akhir. Kami memberikan jaminan garansi kekuatan konstruksi serta layanan purna jual yang sigap.
        </p>
      </div>

    </div>

  </div>
</section>

