<?php
  $clientTestimonials = is_array($clientTestimonials ?? null) ? array_slice($clientTestimonials, 0, 20) : [];
  $makeInitials = static function (string $name): string {
      $parts = preg_split('/\s+/', trim($name)) ?: [];
      $letters = '';

      foreach ($parts as $part) {
          if ($part !== '') {
              $letters .= strtoupper(substr($part, 0, 1));
          }

          if (strlen($letters) >= 2) {
              break;
          }
      }

      return $letters !== '' ? $letters : 'SJ';
  };
?>
<!-- Testimonial Carousel Section -->
<section id="testimoni" class="py-24 bg-slate-900 relative overflow-hidden border-t border-slate-800">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Header -->
    <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Testimoni Klien</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        Kepercayaan dari <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Pemilik Rumah & Pengembang</span>
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Kepuasan klien atas ketepatan jadwal, kerapian las, dan transparansi harga adalah reputasi utama kami.
      </p>
    </div>

    <!-- Carousel Container -->
    <div id="testimonials-wrapper" class="relative max-w-4xl mx-auto overflow-hidden rounded-3xl bg-slate-950/80 border border-slate-800 p-6 sm:p-12 shadow-2xl reveal-fade-up">
      
      <!-- Track -->
      <div id="testimonials-track" class="carousel-track">
        
        <!-- Slide 1 -->
        <div class="testi-slide w-full shrink-0 px-2 sm:px-6 space-y-6">
          <div class="flex items-center space-x-1 text-amber-400">
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
          </div>

          <p class="text-base sm:text-xl text-slate-200 italic leading-relaxed font-light">
            "Sangat puas dengan hasil kanopi Alderon dan pagar minimalis buatan Sentosa Jaya Las. Pengelasannya rapi sekali, catnya tebal tidak mudah baret, dan pemasangan di lokasi sangat cepat serta bersih. Spesifikasi besi betul-betul sesuai dengan RAB."
          </p>

          <div class="flex items-center space-x-4 pt-4 border-t border-slate-800">
            <div class="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-base">
              HW
            </div>
            <div>
              <h4 class="text-base font-bold text-white">Hendra Wijaya</h4>
              <p class="text-xs text-slate-400">Pemilik Rumah di Grand Wisata, Tambun</p>
              <span class="text-[11px] text-blue-400 font-semibold">Proyek: Pagar & Kanopi Carport</span>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="testi-slide w-full shrink-0 px-2 sm:px-6 space-y-6">
          <div class="flex items-center space-x-1 text-amber-400">
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
          </div>

          <p class="text-base sm:text-xl text-slate-200 italic leading-relaxed font-light">
            "Kami mempercayakan pembuatan mezzanine struktur baja WF dan tangga putar untuk workshop kami di Cikarang. Tim Sentosa Jaya Las sangat paham kalkulasi beban teknis dan bekerja profesional sesuai timeline proyek tanpa keterlambatan."
          </p>

          <div class="flex items-center space-x-4 pt-4 border-t border-slate-800">
            <div class="w-12 h-12 rounded-full bg-sky-600 flex items-center justify-center text-white font-bold text-base">
              BS
            </div>
            <div>
              <h4 class="text-base font-bold text-white">Bambang Susanto</h4>
              <p class="text-xs text-slate-400">Operations Manager, Logistik Cikarang</p>
              <span class="text-[11px] text-sky-400 font-semibold">Proyek: Mezzanine Baja WF & Tangga Putar</span>
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="testi-slide w-full shrink-0 px-2 sm:px-6 space-y-6">
          <div class="flex items-center space-x-1 text-amber-400">
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <svg class="w-5 h-5 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
          </div>

          <p class="text-base sm:text-xl text-slate-200 italic leading-relaxed font-light">
            "Sebagai arsitek, saya cukup selektif memilih bengkel las rekanan. Sentosa Jaya Las mampu membaca gambar kerja teknis dengan sempurna dan mengerjakan railing laser cut presisi tinggi tanpa cacat. Sangat recommended!"
          </p>

          <div class="flex items-center space-x-4 pt-4 border-t border-slate-800">
            <div class="w-12 h-12 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold text-base">
              DN
            </div>
            <div>
              <h4 class="text-base font-bold text-white">Dian Novitasari, S.Ars</h4>
              <p class="text-xs text-slate-400">Principal Architect, Studio Arsitektur Bekasi</p>
              <span class="text-[11px] text-indigo-400 font-semibold">Proyek: Railing Laser Cut & Fasad Besi</span>
            </div>
          </div>
        </div>

        <?php foreach ($clientTestimonials as $testimonial): ?>
          <?php
            $rating = max(1, min(5, (int)($testimonial['rating'] ?? 5)));
            $name = (string)($testimonial['name'] ?? 'Klien Sentosa Jaya');
            $project = (string)($testimonial['project'] ?? 'Proyek Bengkel Las');
            $message = (string)($testimonial['message'] ?? '');
            $initials = $makeInitials($name);
            $testimonialId = (string)($testimonial['id'] ?? '');
          ?>
          <?php if ($message !== ''): ?>
            <div class="testi-slide w-full shrink-0 px-2 sm:px-6 space-y-6" data-testimonial-id="<?= esc($testimonialId) ?>">
              <div class="flex items-center space-x-1">
                <?php for ($star = 1; $star <= 5; $star++): ?>
                  <svg class="w-5 h-5 fill-current <?= $star <= $rating ? 'text-amber-400' : 'text-slate-700' ?>" viewBox="0 0 20 20" aria-hidden="true">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                  </svg>
                <?php endfor; ?>
              </div>

              <p class="text-base sm:text-xl text-slate-200 italic leading-relaxed font-light">
                "<?= esc($message) ?>"
              </p>

              <div class="flex items-center space-x-4 pt-4 border-t border-slate-800">
                <div class="w-12 h-12 rounded-full bg-emerald-600 flex items-center justify-center text-white font-bold text-base">
                  <?= esc($initials) ?>
                </div>
                <div>
                  <h4 class="text-base font-bold text-white"><?= esc($name) ?></h4>
                  <p class="text-xs text-slate-400">Klien Sentosa Jaya Las</p>
                  <span class="text-[11px] text-emerald-400 font-semibold">Proyek: <?= esc($project) ?></span>
                </div>
              </div>
            </div>
          <?php endif; ?>
        <?php endforeach; ?>

      </div>

      <!-- Controls: Navigation Arrows & Dots -->
      <div class="flex items-center justify-between mt-8 pt-6 border-t border-slate-800">
        <!-- Dots -->
        <div id="testi-dots" class="flex items-center space-x-2"></div>

        <!-- Buttons -->
        <div class="flex items-center space-x-3">
          <button 
            id="testi-prev-btn" 
            type="button" 
            class="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center border border-slate-700 transition-colors"
            aria-label="Testimoni Sebelumnya"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
          </button>
          <button 
            id="testi-next-btn" 
            type="button" 
            class="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center border border-slate-700 transition-colors"
            aria-label="Testimoni Berikutnya"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
          </button>
        </div>
      </div>

    </div>

  </div>
</section>

