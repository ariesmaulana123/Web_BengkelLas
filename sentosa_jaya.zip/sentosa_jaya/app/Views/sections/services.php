<!-- Layanan Section -->
<section id="layanan" class="py-24 bg-slate-900 relative overflow-hidden border-t border-slate-800">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Header -->
    <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Layanan Lengkap</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        Spesialisasi Fabrikasi & <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-blue-500">Konstruksi Logam</span>
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Kami menyediakan 8 pilar layanan fabrikasi presisi dengan jaminan ketahanan struktural dan standar finishing kelas industri.
      </p>
    </div>

    <!-- 8 Services Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      
      <!-- 1. Pagar -->
      <div class="group p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 shadow-xl hover:shadow-2xl hover:shadow-blue-900/20 transition-all duration-300 flex flex-col justify-between reveal-fade-up">
        <div>
          <div class="h-44 rounded-xl overflow-hidden mb-5 relative">
            <img 
             src="<?= base_url('assets/gambar/Pagar_gerbang.jpeg') ?>" 
              alt="Pagar Besi Sentosa Jaya Las" 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
            <span class="absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-bold bg-blue-600/90 text-white backdrop-blur-sm">
              01. Pagar
            </span>
          </div>
          <h3 class="text-lg font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">Pagar Besi & Gerbang</h3>
          <p class="text-xs text-slate-400 leading-relaxed mb-4">
            Pagar minimalis modern, plat laser cutting bermotif, kombinasi woodplank (GRC), dan pintu dorong sliding presisi.
          </p>
          <ul class="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3">
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-blue-400 mr-2"></span>Pagar Plat Laser Cutting CNC</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-blue-400 mr-2"></span>Pagar Besi Hollow Galvanis Minimalis</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-blue-400 mr-2"></span>Pagar Dorong Rel Stainless & Sliding</li>
          </ul>
        </div>
      </div>

      <!-- 2. Kanopi -->
      <div class="group p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-sky-500/50 shadow-xl hover:shadow-2xl hover:shadow-sky-900/20 transition-all duration-300 flex flex-col justify-between reveal-fade-up" style="transition-delay: 100ms;">
        <div>
          <div class="h-44 rounded-xl overflow-hidden mb-5 relative">
            <img 
              src="<?= base_url('assets/gambar/Kanopi_atap_alderon.jpeg') ?>" 
              alt="Kanopi Minimalis Sentosa Jaya Las" 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
            <span class="absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-bold bg-sky-600/90 text-white backdrop-blur-sm">
              02. Kanopi
            </span>
          </div>
          <h3 class="text-lg font-bold text-white mb-2 group-hover:text-sky-400 transition-colors">Kanopi Modern</h3>
          <p class="text-xs text-slate-400 leading-relaxed mb-4">
            Rangka besi kokoh dengan atap Alderon peredam panas, Solarflat transparan elegan, Kaca Tempered, atau Polycarbonate.
          </p>
          <ul class="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3">
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-sky-400 mr-2"></span>Kanopi Alderon Twinwall / RS</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-sky-400 mr-2"></span>Kanopi Kaca Tempered & Solarflat</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-sky-400 mr-2"></span>Kanopi Rangka Baja Ringan / Besi Hollow</li>
          </ul>
        </div>
      </div>

      <!-- 3. Railing -->
      <div class="group p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 shadow-xl hover:shadow-2xl hover:shadow-indigo-900/20 transition-all duration-300 flex flex-col justify-between reveal-fade-up" style="transition-delay: 200ms;">
        <div>
          <div class="h-44 rounded-xl overflow-hidden mb-5 relative">
            <img 
              src="<?= base_url('assets/gambar/Railing_tangga.jpeg') ?>" 
              alt="Railing Tangga Sentosa Jaya Las" 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
            <span class="absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-600/90 text-white backdrop-blur-sm">
              03. Railing
            </span>
          </div>
          <h3 class="text-lg font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">Railing Balkon & Tangga</h3>
          <p class="text-xs text-slate-400 leading-relaxed mb-4">
            Railing pengaman ergonomis, kuat, dan estetis untuk area tangga dalam, void lantai atas, dan balkon eksterior.
          </p>
          <ul class="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3">
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-indigo-400 mr-2"></span>Railing Balkon Minimalis & Kaca</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-indigo-400 mr-2"></span>Railing Tangga Wood-Grip Handrail</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-indigo-400 mr-2"></span>Railing Stainless Steel 304</li>
          </ul>
        </div>
      </div>

      <!-- 4. Tangga -->
      <div class="group p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-cyan-500/50 shadow-xl hover:shadow-2xl hover:shadow-cyan-900/20 transition-all duration-300 flex flex-col justify-between reveal-fade-up" style="transition-delay: 300ms;">
        <div>
          <div class="h-44 rounded-xl overflow-hidden mb-5 relative">
            <img 
              src="<?= base_url('assets/gambar/Tangga_besi.jpg') ?>" 
              alt="Tangga Besi" 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
            <span class="absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-bold bg-cyan-600/90 text-white backdrop-blur-sm">
              04. Tangga Besi
            </span>
          </div>
          <h3 class="text-lg font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">Tangga Besi & Mezzanine</h3>
          <p class="text-xs text-slate-400 leading-relaxed mb-4">
            Konstruksi tangga rebah balok tunggal/ganda, tangga putar hemat ruang, tangga service akses atap, dan floating stairs.
          </p>
          <ul class="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3">
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-cyan-400 mr-2"></span>Tangga Putar (Spiral Staircase)</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-cyan-400 mr-2"></span>Tangga Rebah Trap Plat Bordes / Kayu</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-cyan-400 mr-2"></span>Tangga Akses Toren & Service</li>
          </ul>
        </div>
      </div>

      <!-- 5. Pintu Besi -->
      <div class="group p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 shadow-xl hover:shadow-2xl hover:shadow-blue-900/20 transition-all duration-300 flex flex-col justify-between reveal-fade-up">
        <div>
          <div class="h-44 rounded-xl overflow-hidden mb-5 relative">
            <img 
              src="<?= base_url('assets/gambar/Pintu_besi.jpeg') ?>" 
              alt="Pintu Besi Garasi Sentosa Jaya Las" 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
            <span class="absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-bold bg-blue-600/90 text-white backdrop-blur-sm">
              05. Pintu Besi
            </span>
          </div>
          <h3 class="text-lg font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">Pintu Besi & Garasi</h3>
          <p class="text-xs text-slate-400 leading-relaxed mb-4">
            Pintu garasi sistem tikung sliding Henderson, pintu lipat ruko, pintu emergency darurat gedung, dan pintu akses pengaman.
          </p>
          <ul class="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3">
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-blue-400 mr-2"></span>Pintu Garasi Tikung Rel Henderson</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-blue-400 mr-2"></span>Pintu Lipat Plat Tekuk / Perforated</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-blue-400 mr-2"></span>Pintu Besi Double Kunci Deadbolt</li>
          </ul>
        </div>
      </div>

      <!-- 6. Teralis -->
      <div class="group p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-sky-500/50 shadow-xl hover:shadow-2xl hover:shadow-sky-900/20 transition-all duration-300 flex flex-col justify-between reveal-fade-up" style="transition-delay: 100ms;">
        <div>
          <div class="h-44 rounded-xl overflow-hidden mb-5 relative">
            <img 
              src="<?= base_url('assets/gambar/Tralis.jpeg') ?>" 
              alt="Teralis Jendela Sentosa Jaya Las" 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
            <span class="absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-bold bg-sky-600/90 text-white backdrop-blur-sm">
              06. Teralis
            </span>
          </div>
          <h3 class="text-lg font-bold text-white mb-2 group-hover:text-sky-400 transition-colors">Teralis Jendela & Pintu</h3>
          <p class="text-xs text-slate-400 leading-relaxed mb-4">
            Pengaman jendela hunian dan kantor dengan desain minimalis elegan, besi nako padat / hollow tebal, serta pintu kawat nyamuk baja.
          </p>
          <ul class="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3">
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-sky-400 mr-2"></span>Teralis Jendela Nako Padat Minimalis</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-sky-400 mr-2"></span>Pintu Kasa Nyamuk Besi (Security Door)</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-sky-400 mr-2"></span>Teralis Pengaman Void & Balkon</li>
          </ul>
        </div>
      </div>

      <!-- 7. Struktur Besi -->
      <div class="group p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 shadow-xl hover:shadow-2xl hover:shadow-indigo-900/20 transition-all duration-300 flex flex-col justify-between reveal-fade-up" style="transition-delay: 200ms;">
        <div>
          <div class="h-44 rounded-xl overflow-hidden mb-5 relative">
            <img 
              src="<?= base_url('assets/gambar/Struktur_besi.jpg') ?>" 
              alt="Konstruksi Baja WF Sentosa Jaya Las" 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
            <span class="absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-600/90 text-white backdrop-blur-sm">
              07. Struktur Besi
            </span>
          </div>
          <h3 class="text-lg font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">Struktur & Baja WF</h3>
          <p class="text-xs text-slate-400 leading-relaxed mb-4">
            Konstruksi baja berat IWF/H-Beam, lantai mezzanine gudang/ruko, rangka atap bentang lebar, dan tiang jembatan penyeberangan.
          </p>
          <ul class="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3">
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-indigo-400 mr-2"></span>Lantai Mezzanine Ruko & Workshop</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-indigo-400 mr-2"></span>Rangka Baja WF Bangunan & Pabrik</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-indigo-400 mr-2"></span>Konstruksi Kanopi Bentang Lebar</li>
          </ul>
        </div>
      </div>

      <!-- 8. Custom Fabrication -->
      <div class="group p-6 rounded-2xl bg-slate-950 border border-slate-800 hover:border-cyan-500/50 shadow-xl hover:shadow-2xl hover:shadow-cyan-900/20 transition-all duration-300 flex flex-col justify-between reveal-fade-up" style="transition-delay: 300ms;">
        <div>
          <div class="h-44 rounded-xl overflow-hidden mb-5 relative">
            <img 
              src="<?= base_url('assets/gambar/Custom_fabrication.jpg') ?>" 
              alt="Custom Fabrication Sentosa Jaya Las" 
              class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
            <span class="absolute top-3 left-3 px-2.5 py-1 rounded-lg text-xs font-bold bg-cyan-600/90 text-white backdrop-blur-sm">
              08. Custom Fab
            </span>
          </div>
          <h3 class="text-lg font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">Custom Fabrication</h3>
          <p class="text-xs text-slate-400 leading-relaxed mb-4">
            Pembuatan produk besi kustom sesuai spesifikasi: rak display toko, meja kerja heavy duty, booth komersial, dan partisi industrial.
          </p>
          <ul class="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3">
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-cyan-400 mr-2"></span>Meja & Kursi Cafe Industrial Steel</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-cyan-400 mr-2"></span>Rak Display & Storage Heavy Duty</li>
            <li class="flex items-center"><span class="w-1.5 h-1.5 rounded-full bg-cyan-400 mr-2"></span>Partisi Kaca Frame Besi (Crittall Style)</li>
          </ul>
        </div>
      </div>

    </div>

  </div>
</section>

