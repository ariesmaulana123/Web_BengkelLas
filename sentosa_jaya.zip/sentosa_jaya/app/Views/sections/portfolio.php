<!-- Portfolio Section -->
<section id="proyek" class="py-24 bg-slate-950 relative overflow-hidden">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Section Header -->
    <div class="text-center max-w-3xl mx-auto mb-12 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Portfolio Proyek</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        Dokumentasi Hasil Karya <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Fabrikasi Nyata</span>
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Setiap karya mencerminkan komitmen terhadap presisi sambungan las, kekuatan konstruksi, dan sentuhan akhir yang berkelas.
      </p>
    </div>

    <!-- Category Filter Tabs -->
    <div class="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-12 reveal-fade-up">
      <button 
        type="button" 
        data-filter="all" 
        class="portfolio-filter-btn px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-blue-600 text-white shadow-lg shadow-blue-500/25 transition-all duration-300"
      >
        Semua Proyek
      </button>
      <button 
        type="button" 
        data-filter="pagar-kanopi" 
        class="portfolio-filter-btn px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white transition-all duration-300"
      >
        Pagar & Kanopi
      </button>
      <button 
        type="button" 
        data-filter="railing-tangga" 
        class="portfolio-filter-btn px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white transition-all duration-300"
      >
        Railing & Tangga
      </button>
      <button 
        type="button" 
        data-filter="pintu-teralis" 
        class="portfolio-filter-btn px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white transition-all duration-300"
      >
        Pintu & Teralis
      </button>
      <button 
        type="button" 
        data-filter="struktur-custom" 
        class="portfolio-filter-btn px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white transition-all duration-300"
      >
        Struktur & Custom
      </button>
    </div>

    <!-- Portfolio Grid (6 curated items) -->
    <div id="portfolio-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      
      <!-- Proyek 1: Pagar Laser Cutting -->
      <div class="portfolio-item group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" data-category="pagar-kanopi">
        <div class="aspect-[4/3] overflow-hidden">
          <img 
          src="<?= base_url('assets/gambar/Kanopi_minimalis.jpeg') ?>" 
          alt="Kanopi Minimalis" 
          class="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out p-1"
          loading="lazy"/>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"></div>
        
        <div class="absolute inset-0 p-6 flex flex-col justify-end">
          <div class="space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <span class="portfolio-cat-badge inline-block px-3 py-1 rounded-full text-xs font-semibold bg-blue-600/90 text-white backdrop-blur-md">
              Pagar & Kanopi
            </span>
            <h3 class="portfolio-title text-xl font-bold text-white group-hover:text-blue-300 transition-colors">
              Kanopi Minimalis
            </h3>
            <p class="portfolio-desc text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
              Pemasangan kanopi minimalis di perumahan Grand Wisata Bekasi. Finishing cat Duco hitam doff anti-karat.
            </p>
          </div>
          <button 
            type="button" 
            class="portfolio-zoom-trigger mt-4 w-10 h-10 rounded-xl bg-white/10 hover:bg-blue-600 text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all self-end"
            aria-label="Lihat Foto Lebih Besar"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Proyek 2: Kanopi Alderon & Kaca Tempered -->
      <div class="portfolio-item group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" data-category="pagar-kanopi" style="transition-delay: 100ms;">
        <div class="aspect-[4/3] overflow-hidden">
          <img 
          src="<?= base_url('assets/gambar/Kanopi_atap_alderon.jpeg') ?>" 
          alt="Kanopi Atap Alderon" 
          class="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out p-1"
          loading="lazy"/>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"></div>
        
        <div class="absolute inset-0 p-6 flex flex-col justify-end">
          <div class="space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <span class="portfolio-cat-badge inline-block px-3 py-1 rounded-full text-xs font-semibold bg-sky-600/90 text-white backdrop-blur-md">
              Kanopi & Pagar
            </span>
            <h3 class="portfolio-title text-xl font-bold text-white group-hover:text-sky-300 transition-colors">
              Kanopi Atap Alderon
            </h3>
            <p class="portfolio-desc text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
              Kanopi bentang 6x5 meter tanpa tiang tengah, memperluas area parkir dua mobil di Cikarang Pusat.
            </p>
          </div>
          <button 
            type="button" 
            class="portfolio-zoom-trigger mt-4 w-10 h-10 rounded-xl bg-white/10 hover:bg-sky-600 text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all self-end"
            aria-label="Lihat Foto Lebih Besar"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/>
            </svg>
          </button>
        </div>
      </div>
      
      <div class="portfolio-item group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" data-category="pagar-kanopi" style="transition-delay: 100ms;">
        <div class="aspect-[4/3] overflow-hidden">
          <img 
          src="<?= base_url('assets/gambar/Kanopi .jpeg') ?>" 
          alt="Kanopi Minimalis" 
          class="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out p-1"
          loading="lazy"/>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"></div>
        
        <div class="absolute inset-0 p-6 flex flex-col justify-end">
          <div class="space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <span class="portfolio-cat-badge inline-block px-3 py-1 rounded-full text-xs font-semibold bg-sky-600/90 text-white backdrop-blur-md">
              Kanopi & Pagar
            </span>
            <h3 class="portfolio-title text-xl font-bold text-white group-hover:text-sky-300 transition-colors">
              Kanopi Ruko Minimalis
            </h3>
            <p class="portfolio-desc text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
              Kanopi bentang 6x5 meter tanpa tiang tengah, memperluas area parkir dua mobil di Cikarang Pusat.
            </p>
          </div>
          <button 
            type="button" 
            class="portfolio-zoom-trigger mt-4 w-10 h-10 rounded-xl bg-white/10 hover:bg-sky-600 text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all self-end"
            aria-label="Lihat Foto Lebih Besar"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/>
            </svg>
          </button>
        </div>
      </div>
      <div class="portfolio-item group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" data-category="pagar-kanopi" style="transition-delay: 100ms;">
        <div class="aspect-[4/3] overflow-hidden">
          <img 
          src="<?= base_url('assets/gambar/Kanopi_Ruko.jpeg') ?>" 
          alt="Kanopi Ruko Minimalis" 
          class="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out p-1"
          loading="lazy"/>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"></div>
        
        <div class="absolute inset-0 p-6 flex flex-col justify-end">
          <div class="space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <span class="portfolio-cat-badge inline-block px-3 py-1 rounded-full text-xs font-semibold bg-sky-600/90 text-white backdrop-blur-md">
              Kanopi & Pagar
            </span>
            <h3 class="portfolio-title text-xl font-bold text-white group-hover:text-sky-300 transition-colors">
              Kanopi Ruko Minimalis
            </h3>
            <p class="portfolio-desc text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
              Kanopi bentang 6x5 meter tanpa tiang tengah, memperluas area parkir dua mobil di Cikarang Pusat.
            </p>
          </div>
          <button 
            type="button" 
            class="portfolio-zoom-trigger mt-4 w-10 h-10 rounded-xl bg-white/10 hover:bg-sky-600 text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all self-end"
            aria-label="Lihat Foto Lebih Besar"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Proyek 3: Railing Balkon & Tangga -->
      <div class="portfolio-item group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" data-category="railing-tangga" style="transition-delay: 200ms;">
        <div class="aspect-[4/3] overflow-hidden">
          <img 
          src="<?= base_url('assets/gambar/Railing_tangga.jpeg') ?>" 
          alt="Railing Tangga" 
          class="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out p-1"
          loading="lazy"/>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"></div>
        
        <div class="absolute inset-0 p-6 flex flex-col justify-end">
          <div class="space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <span class="portfolio-cat-badge inline-block px-3 py-1 rounded-full text-xs font-semibold bg-indigo-600/90 text-white backdrop-blur-md">
              Railing & Tangga
            </span>
            <h3 class="portfolio-title text-xl font-bold text-white group-hover:text-indigo-300 transition-colors">
              Railing Tangga
            </h3>
            <p class="portfolio-desc text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
              Tingkatkan keamanan sekaligus estetika lantai atas rumah, kantor, ruko, atau bangunan Anda dengan Railing Balkon Galvanis berkualitas tinggi.
            </p>
          </div>
          <button 
            type="button" 
            class="portfolio-zoom-trigger mt-4 w-10 h-10 rounded-xl bg-white/10 hover:bg-indigo-600 text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all self-end"
            aria-label="Lihat Foto Lebih Besar"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Pintu & Tralis -->
      <div class="portfolio-item group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" data-category="pintu-teralis" style="transition-delay: 200ms;">
        <div class="aspect-[4/3] overflow-hidden">
          <img 
          src="<?= base_url('assets/gambar/Tralis_minimalis.jpeg') ?>" 
          alt="Tralis Minimalis" 
          class="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out p-1"
          loading="lazy"/>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"></div>
        
        <div class="absolute inset-0 p-6 flex flex-col justify-end">
          <div class="space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <span class="portfolio-cat-badge inline-block px-3 py-1 rounded-full text-xs font-semibold bg-emerald-600/90 text-white backdrop-blur-md">
              Pintu & Tralis
            </span>
            <h3 class="portfolio-title text-xl font-bold text-white group-hover:text-emerald-300 transition-colors">
              Bangku Wasit Bulutangkis
            </h3>
            <p class="portfolio-desc text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
              Tambahkan kenyamanan dan gaya ke lapangan bulutangkis Anda dengan Bangku Wasit Bulutangkis berkualitas tinggi.
            </p>
          </div>
          <button 
            type="button" 
            class="portfolio-zoom-trigger mt-4 w-10 h-10 rounded-xl bg-white/10 hover:bg-emerald-600 text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all self-end"
            aria-label="Lihat Foto Lebih Besar"
            >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Proyek 3: Railing Balkon & Tangga -->
      <div class="portfolio-item group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" data-category="railing-tangga" style="transition-delay: 200ms;">
        <div class="aspect-[4/3] overflow-hidden">
          <img 
          src="<?= base_url('assets/gambar/Railing_balkon.png') ?>" 
          alt="Railing Balkon" 
          class="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out p-1"
          loading="lazy"/>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"></div>
        
        <div class="absolute inset-0 p-6 flex flex-col justify-end">
          <div class="space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <span class="portfolio-cat-badge inline-block px-3 py-1 rounded-full text-xs font-semibold bg-indigo-600/90 text-white backdrop-blur-md">
              Railing & Tangga
            </span>
            <h3 class="portfolio-title text-xl font-bold text-white group-hover:text-indigo-300 transition-colors">
              Railing Balkon Galfanis
            </h3>
            <p class="portfolio-desc text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
              Tingkatkan keamanan sekaligus estetika lantai atas rumah, kantor, ruko, atau bangunan Anda dengan Railing Balkon Galvanis berkualitas tinggi.
            </p>
          </div>
          <button 
            type="button" 
            class="portfolio-zoom-trigger mt-4 w-10 h-10 rounded-xl bg-white/10 hover:bg-indigo-600 text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all self-end"
            aria-label="Lihat Foto Lebih Besar"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Proyek 6: Mezzanine Gudang & Baja WF -->
      <div class="portfolio-item group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" data-category="struktur-custom" style="transition-delay: 200ms;">
        <div class="aspect-[4/3] overflow-hidden">
          <img 
          src="<?= base_url('assets/gambar/Bangku Wasit Bulutangkis.jpeg') ?>" 
          alt="Bangku Wasit Bulutangkis" 
          class="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out p-1"
          loading="lazy"/>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"></div>
        
        <div class="absolute inset-0 p-6 flex flex-col justify-end">
          <div class="space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <span class="portfolio-cat-badge inline-block px-3 py-1 rounded-full text-xs font-semibold bg-emerald-600/90 text-white backdrop-blur-md">
              Struktur & Custom
            </span>
            <h3 class="portfolio-title text-xl font-bold text-white group-hover:text-emerald-300 transition-colors">
              Bangku Wasit Bulutangkis
            </h3>
            <p class="portfolio-desc text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
              Tambahkan kenyamanan dan gaya ke lapangan bulutangkis Anda dengan Bangku Wasit Bulutangkis berkualitas tinggi.
            </p>
          </div>
          <button 
            type="button" 
            class="portfolio-zoom-trigger mt-4 w-10 h-10 rounded-xl bg-white/10 hover:bg-emerald-600 text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all self-end"
            aria-label="Lihat Foto Lebih Besar"
            >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="portfolio-item group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" data-category="struktur-custom" style="transition-delay: 200ms;">
        <div class="aspect-[4/3] overflow-hidden">
          <img 
          src="<?= base_url('assets/gambar/Rolling_door.jpeg') ?>" 
          alt="Rolling Door" 
          class="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out p-1"
          loading="lazy"/>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"></div>
        
        <div class="absolute inset-0 p-6 flex flex-col justify-end">
          <div class="space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <span class="portfolio-cat-badge inline-block px-3 py-1 rounded-full text-xs font-semibold bg-emerald-600/90 text-white backdrop-blur-md">
              Struktur & Custom
            </span>
            <h3 class="portfolio-title text-xl font-bold text-white group-hover:text-emerald-300 transition-colors">
              Rolling Door
            </h3>
            <p class="portfolio-desc text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
              Hadirkan suasana ruang kerja atau kamar tidur yang lebih estetik, rapi, dan produktif dengan Rolling Door.
            </p>
          </div>
          <button 
            type="button" 
            class="portfolio-zoom-trigger mt-4 w-10 h-10 rounded-xl bg-white/10 hover:bg-emerald-600 text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all self-end"
            aria-label="Lihat Foto Lebih Besar"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="portfolio-item group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" data-category="struktur-custom" style="transition-delay: 200ms;">
        <div class="aspect-[4/3] overflow-hidden">
          <img 
          src="<?= base_url('assets/gambar/Rak.jpeg') ?>" 
          alt="Rak Besi" 
          class="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out p-1"
          loading="lazy"/>
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"></div>
        
        <div class="absolute inset-0 p-6 flex flex-col justify-end">
          <div class="space-y-2 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <span class="portfolio-cat-badge inline-block px-3 py-1 rounded-full text-xs font-semibold bg-emerald-600/90 text-white backdrop-blur-md">
              Struktur & Custom
            </span>
            <h3 class="portfolio-title text-xl font-bold text-white group-hover:text-emerald-300 transition-colors">
              Rak Besi
            </h3>
            <p class="portfolio-desc text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 line-clamp-2">
              Hadirkan suasana ruang kerja atau kamar tidur yang lebih estetik, rapi, dan produktif dengan Rak Besi.
            </p>
          </div>
          <button 
            type="button" 
            class="portfolio-zoom-trigger mt-4 w-10 h-10 rounded-xl bg-white/10 hover:bg-emerald-600 text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all self-end"
            aria-label="Lihat Foto Lebih Besar"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v6m3-3H7"/>
            </svg>
          </button>
        </div>
      </div>


    </div>

  </div>
</section>

