<!-- Service Highlight Section -->
<section class="relative z-20 -mt-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    
    <!-- Item 1: Pagar & Kanopi -->
    <div class="group p-6 rounded-2xl bg-slate-900/95 border border-slate-800 shadow-xl hover:border-blue-500/40 hover:shadow-2xl hover:shadow-blue-900/20 transition-all duration-300 transform hover:-translate-y-1.5 reveal-fade-up">
      <div class="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-5 group-hover:bg-blue-600 group-hover:text-white group-hover:scale-110 transition-all duration-300">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
        </svg>
      </div>
      <h3 class="text-lg font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">Pagar & Kanopi</h3>
      <p class="text-sm text-slate-400 leading-relaxed">
        Pagar minimalis, laser cutting, woodplank & kanopi Alderon, solarflat, atau tempered glass berstruktur kokoh.
      </p>
      <div class="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-blue-400">
        <span>Kualitas Anti-Karat</span>
        <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
        </svg>
      </div>
    </div>

    <!-- Item 2: Railing & Tangga -->
    <div class="group p-6 rounded-2xl bg-slate-900/95 border border-slate-800 shadow-xl hover:border-sky-500/40 hover:shadow-2xl hover:shadow-sky-900/20 transition-all duration-300 transform hover:-translate-y-1.5 reveal-fade-up" style="transition-delay: 100ms;">
      <div class="w-12 h-12 rounded-xl bg-sky-600/10 border border-sky-500/20 text-sky-400 flex items-center justify-center mb-5 group-hover:bg-sky-600 group-hover:text-white group-hover:scale-110 transition-all duration-300">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"/>
        </svg>
      </div>
      <h3 class="text-lg font-bold text-white mb-2 group-hover:text-sky-400 transition-colors">Railing & Tangga</h3>
      <p class="text-sm text-slate-400 leading-relaxed">
        Railing balkon, tangga rebah, putar, mezzanine hingga tangga trap kayu kombinasi besi kokoh & ergonomis.
      </p>
      <div class="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-sky-400">
        <span>Presisi & Aman</span>
        <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
        </svg>
      </div>
    </div>

    <!-- Item 3: Steel Fabrication -->
    <div class="group p-6 rounded-2xl bg-slate-900/95 border border-slate-800 shadow-xl hover:border-indigo-500/40 hover:shadow-2xl hover:shadow-indigo-900/20 transition-all duration-300 transform hover:-translate-y-1.5 reveal-fade-up" style="transition-delay: 200ms;">
      <div class="w-12 h-12 rounded-xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mb-5 group-hover:bg-indigo-600 group-hover:text-white group-hover:scale-110 transition-all duration-300">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
        </svg>
      </div>
      <h3 class="text-lg font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">Steel Fabrication</h3>
      <p class="text-sm text-slate-400 leading-relaxed">
        Konstruksi baja WF, rangka atap industri, mezzanine gudang, pintu henderson, dan struktur bangunan besi.
      </p>
      <div class="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-indigo-400">
        <span>Kekuatan Struktural SNI</span>
        <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
        </svg>
      </div>
    </div>

    <!-- Item 4: Custom Project -->
    <div class="group p-6 rounded-2xl bg-slate-900/95 border border-slate-800 shadow-xl hover:border-cyan-500/40 hover:shadow-2xl hover:shadow-cyan-900/20 transition-all duration-300 transform hover:-translate-y-1.5 reveal-fade-up" style="transition-delay: 300ms;">
      <div class="w-12 h-12 rounded-xl bg-cyan-600/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-5 group-hover:bg-cyan-600 group-hover:text-white group-hover:scale-110 transition-all duration-300">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"/>
        </svg>
      </div>
      <h3 class="text-lg font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">Custom Project</h3>
      <p class="text-sm text-slate-400 leading-relaxed">
        Furniture industrial, rak display komersial, ornamen artistik, dan pengerjaan kustom sesuai sketsa arsitek.
      </p>
      <div class="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-cyan-400">
        <span>Desain Fleksibel</span>
        <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
        </svg>
      </div>
    </div>

  </div>
</section>

