<!-- Workshop Gallery Section -->
<section class="py-24 bg-slate-950 relative overflow-hidden">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Header -->
    <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Fasilitas & Workshop</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        Peralatan Modern & <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Workshop Terstandarisasi</span>
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Didukung area fabrikasi yang luas, mesin potong bending presisi, serta perkakas safety lengkap untuk menjamin mutu pengerjaan.
      </p>
    </div>

    <!-- Gallery Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      
      <!-- Facility 1 -->
      <div class="group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up">
        <div class="h-64 overflow-hidden">
          <img 
            src="<?= base_url('assets/gambar/Workshop.jpeg') ?>"  
            alt="Area Perakitan & Pengelasan Workshop" 
            class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
            loading="lazy"
          />
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
        <div class="absolute bottom-4 left-4 right-4 p-3 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800/80">
          <h4 class="text-sm font-bold text-white">Area Fabrikasi & Pengelasan</h4>
          <p class="text-[11px] text-slate-400">Penyambungan logam kuat, matang, dan minim deformasi.</p>
        </div>
      </div>

      <!-- Facility 2 -->
      <div class="group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" style="transition-delay: 100ms;">
        <div class="h-64 overflow-hidden">
          <img 
            src="<?= base_url('assets/gambar/Alat_area.jpeg') ?>"
            alt="Mesin Cutting & Bending Presisi" 
            class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
            loading="lazy"
          />
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
        <div class="absolute bottom-4 left-4 right-4 p-3 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800/80">
          <h4 class="text-sm font-bold text-white">Mesin Potong & Alat Pengelasan</h4>
          <p class="text-[11px] text-slate-400">Pemotongan sudut 45° & penekukan plat bebas cacat.</p>
        </div>
      </div>

      <!-- Facility 3 -->
      <div class="group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-xl reveal-fade-up" style="transition-delay: 200ms;">
        <div class="h-64 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80" 
            alt="Ruang Pengecatan & Finishing Spray Booth" 
            class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
            loading="lazy"
          />
        </div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
        <div class="absolute bottom-4 left-4 right-4 p-3 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800/80">
          <h4 class="text-sm font-bold text-white">Finishing Spray & Quality Inspection</h4>
          <p class="text-[11px] text-slate-400">Pengecatan bebas debu dengan kontrol ketebalan micron.</p>
        </div>
      </div>

    </div>

  </div>
</section>

