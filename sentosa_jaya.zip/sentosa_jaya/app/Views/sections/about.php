<!-- Tentang Kami Section -->
<section id="tentang-kami" class="py-24 bg-slate-950 relative overflow-hidden">
  <!-- Subtle Background Glow -->
  <div class="absolute -top-40 -left-40 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>
  <div class="absolute -bottom-40 -right-40 w-96 h-96 bg-sky-600/10 rounded-full blur-3xl pointer-events-none"></div>

  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
      
      <!-- Left: Visual & Experience Badge -->
      <div class="lg:col-span-6 relative reveal-fade-right">
        <div class="relative rounded-3xl overflow-hidden border border-slate-800 shadow-2xl">
          <img src="<?= base_url('assets/gambar/Workshop.jpeg') ?>" alt="Sentosa Jaya Las" class="w-full h-full object-contain p-1"
            class="w-full h-[450px] sm:h-[520px] object-cover object-center transform hover:scale-105 transition-transform duration-700"
            loading="lazy"
          />
          <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent"></div>
          
          <!-- Bottom Floating Detail Overlay -->
          <div class="absolute bottom-6 left-6 right-6 p-5 rounded-2xl bg-slate-900/90 backdrop-blur-md border border-slate-700/60 flex items-center justify-between">
            <div class="flex items-center space-x-4">
              <div class="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-gray-800 shadow-lg shadow-200/50 group-hover:scale-105 transition-all overflow-hidden">
                <img src="<?= base_url('assets/gambar/logo_sentosa.png') ?>" alt="Sentosa Jaya Las" class="w-full h-full object-contain p-1">
              </div>
              <div>
                <h4 class="text-white font-bold text-base">Bengkel Las Berbadan Usaha</h4>
                <p class="text-xs text-slate-400">Workshop Resmi di Setu, Bekasi</p>
              </div>
            </div>
            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">
              Verified
            </span>
          </div>
        </div>

        <!-- Floating Experience Card -->
        <div class="absolute -top-6 -right-4 sm:-right-6 bg-blue-600 text-white p-5 rounded-2xl shadow-xl shadow-blue-600/30 border border-blue-400/30 hidden sm:block">
          <p class="text-3xl font-extrabold font-display">10+</p>
          <p class="text-xs font-semibold uppercase tracking-wider text-blue-100 mt-0.5">Tahun Pengalaman</p>
        </div>
      </div>

      <!-- Right: Content & Counter Stats -->
      <div class="lg:col-span-6 space-y-8 reveal-fade-left">
        <div class="space-y-4">
          <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <span>Tentang Sentosa Jaya Las</span>
          </div>
          <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight leading-tight">
            Dedikasi Menghadirkan Fabrikasi Besi <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Bermutu Tinggi & Presisi</span>
          </h2>
          <p class="text-slate-300 text-base leading-relaxed">
            <strong class="text-white font-semibold">Sentosa Jaya Las</strong> adalah spesialis fabrikasi logam dan konstruksi besi terpercaya yang berbasis di Setu, Bekasi. Kami melayani kebutuhan pembuatan pagar, kanopi, railing, tangga, pintu besi, konstruksi gudang, hingga custom furniture industrial.
          </p>
          <p class="text-slate-400 text-sm leading-relaxed">
            Berbekal pengalaman lebih dari satu dekade serta didukung tukang las bersertifikat, kami memadukan ketahanan struktural dengan estetika modern untuk hunian pribadi, ruko, perkantoran, perumahan, dan kawasan industri.
          </p>
        </div>

        <!-- Core Values Pills -->
        <div class="grid grid-cols-2 gap-3 text-sm">
          <div class="flex items-center space-x-2.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <div class="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
            </div>
            <span class="text-slate-200 font-medium text-xs sm:text-sm">Material SNI Berkualitas</span>
          </div>

          <div class="flex items-center space-x-2.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <div class="w-6 h-6 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
            </div>
            <span class="text-slate-200 font-medium text-xs sm:text-sm">Finishing Halus Rapi</span>
          </div>

          <div class="flex items-center space-x-2.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <div class="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
            </div>
            <span class="text-slate-200 font-medium text-xs sm:text-sm">Harga Transparan</span>
          </div>

          <div class="flex items-center space-x-2.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <div class="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
            </div>
            <span class="text-slate-200 font-medium text-xs sm:text-sm">Garansi Struktur Penuh</span>
          </div>
        </div>

        <!-- Animated Stats Counter Grid -->
        <div id="stats-wrapper" class="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-slate-800">
          
          <div class="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
            <p class="text-2xl sm:text-3xl font-black text-white font-display flex items-center justify-center">
              <span class="stat-counter" data-target="10">0</span>
              <span class="text-blue-400 ml-0.5">+</span>
            </p>
            <p class="text-xs text-slate-400 mt-1 font-medium">Tahun Pengalaman</p>
          </div>

          <div class="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
            <p class="text-2xl sm:text-3xl font-black text-white font-display flex items-center justify-center">
              <span class="stat-counter" data-target="1250">0</span>
              <span class="text-sky-400 ml-0.5">+</span>
            </p>
            <p class="text-xs text-slate-400 mt-1 font-medium">Proyek Selesai</p>
          </div>

          <div class="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
            <p class="text-2xl sm:text-3xl font-black text-white font-display flex items-center justify-center">
              <span class="stat-counter" data-target="99">0</span>
              <span class="text-indigo-400 ml-0.5">%</span>
            </p>
            <p class="text-xs text-slate-400 mt-1 font-medium">Klien Puas</p>
          </div>

          <div class="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
            <p class="text-2xl sm:text-3xl font-black text-white font-display flex items-center justify-center">
              <span class="stat-counter" data-target="100">0</span>
              <span class="text-cyan-400 ml-0.5">%</span>
            </p>
            <p class="text-xs text-slate-400 mt-1 font-medium">Material SNI</p>
          </div>

        </div>

      </div>

    </div>
  </div>
</section>

