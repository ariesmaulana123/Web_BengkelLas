<!-- Hero Section -->
<section id="beranda" class="relative min-h-[92vh] flex items-center justify-center pt-28 pb-20 overflow-hidden bg-slate-950">
  <!-- Background Image with Overlay -->
  <div class="absolute inset-0 z-0">
    <img 
      src="https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=2000&q=80" 
      alt="Fabrikasi Besi Sentosa Jaya Las" 
      class="w-full h-full object-cover object-center opacity-30 transform scale-105 transition-transform duration-1000 ease-out"
      loading="eager"
    />
    <div class="absolute inset-0 hero-gradient-overlay"></div>
    <div class="absolute inset-0 bg-industrial-grid"></div>
    <div class="absolute inset-0 hero-mesh pointer-events-none"></div>
  </div>

  <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
      
      <!-- Left Column: Main Headline -->
      <div class="lg:col-span-8 text-left space-y-7">
        
        <!-- Industrial Tag -->
        <div class="inline-flex items-center space-x-3 px-4 py-2 rounded-full bg-slate-900/90 border border-blue-500/30 text-blue-400 text-xs sm:text-sm font-semibold tracking-wide badge-pulse reveal-fade-up">
          <span class="ml-2">BENGKEL LAS & STEEL FABRICATION PROFESIONAL</span>
        </div>

        <!-- Headline -->
        <h1 class="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.15] font-display reveal-fade-up">
          Solusi Fabrikasi Besi untuk <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-blue-500">Hunian, Bisnis & Proyek</span>
        </h1>

        <!-- Short Description -->
        <p class="text-base sm:text-lg lg:text-xl text-slate-300 font-normal leading-relaxed max-w-2xl reveal-fade-up">
          Menghadirkan pengerjaan konstruksi besi presisi tinggi, kokoh, dan berestetika modern. Didukung material berstandar SNI, tenaga ahli berpengalaman, serta jaminan hasil rapi tepat waktu.
        </p>

        <!-- CTA Buttons -->
        <div class="flex flex-wrap gap-4 pt-2 reveal-fade-up">
          <a 
            href="#proyek" 
            class="inline-flex items-center justify-center px-7 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-base shadow-lg shadow-blue-600/30 hover:shadow-blue-500/50 hover:-translate-y-0.5 transition-all duration-300 group"
          >
            <span>Lihat Proyek</span>
            <svg class="w-5 h-5 ml-2 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
            </svg>
          </a>

          <a 
            href="#layanan" 
            class="inline-flex items-center justify-center px-7 py-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/90 text-slate-200 hover:text-white font-semibold text-base border border-slate-700/80 hover:border-slate-600 backdrop-blur-md hover:-translate-y-0.5 transition-all duration-300"
          >
            <span>Lihat Layanan</span>
            <svg class="w-5 h-5 ml-2 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
            </svg>
          </a>
        </div>

        <!-- Trust Badges -->
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-6 border-t border-slate-800/80 reveal-fade-up">
          <div class="flex items-center space-x-3">
            <div class="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shrink-0">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
              </svg>
            </div>
            <div>
              <p class="text-sm font-semibold text-white">Besi SNI Asli</p>
              <p class="text-xs text-slate-400">Tebal & Kokoh</p>
            </div>
          </div>

          <div class="flex items-center space-x-3">
            <div class="w-10 h-10 rounded-lg bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400 shrink-0">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
            </div>
            <div>
              <p class="text-sm font-semibold text-white">Tepat Waktu</p>
              <p class="text-xs text-slate-400">Jadwal Terencana</p>
            </div>
          </div>

          <div class="flex items-center space-x-3 col-span-2 sm:col-span-1">
            <div class="w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
              </svg>
            </div>
            <div>
              <p class="text-sm font-semibold text-white">Garansi Pemasangan</p>
              <p class="text-xs text-slate-400">100% Tanggung Jawab</p>
            </div>
          </div>
        </div>

      </div>

      <!-- Right Column: Industrial Visual Card -->
      <div class="lg:col-span-4 hidden lg:block reveal-fade-left">
        <div class="relative p-6 rounded-2xl glass-card bg-slate-900/60 border border-slate-800 shadow-2xl space-y-6">
          
          <div class="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <p class="text-xs text-slate-400 font-medium">STATUS WORKSHOP</p>
              <h3 class="text-base font-bold text-white">Sentosa Jaya Las</h3>
            </div>
            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <span class="w-2 h-2 rounded-full bg-emerald-400 mr-1.5 animate-pulse"></span>
              Operasional Aktif
            </span>
          </div>

          <!-- Feature items list -->
          <div class="space-y-4">
            <div class="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-start space-x-3.5">
              <div class="w-9 h-9 rounded-lg bg-blue-600/20 flex items-center justify-center text-blue-400 shrink-0 mt-0.5">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"/>
                </svg>
              </div>
              <div>
                <h4 class="text-sm font-semibold text-white">Fabrikasi Presisi & Kuat</h4>
                <p class="text-xs text-slate-400 mt-0.5">Pengelasan full-weld matang tanpa pori dan finishing anti karat bertingkat.</p>
              </div>
            </div>

            <div class="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-start space-x-3.5">
              <div class="w-9 h-9 rounded-lg bg-sky-600/20 flex items-center justify-center text-sky-400 shrink-0 mt-0.5">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                </svg>
              </div>
              <div>
                <h4 class="text-sm font-semibold text-white">Transparansi Estimasi & Spesifikasi</h4>
                <p class="text-xs text-slate-400 mt-0.5">Ukuran besi dan ketebalan material sesuai kesepakatan tertulis.</p>
              </div>
            </div>

            <div class="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-start space-x-3.5">
              <div class="w-9 h-9 rounded-lg bg-indigo-600/20 flex items-center justify-center text-indigo-400 shrink-0 mt-0.5">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
              </div>
              <div>
                <h4 class="text-sm font-semibold text-white">Jangkauan Area Luas</h4>
                <p class="text-xs text-slate-400 mt-0.5">Melayani Setu, Bekasi, Cikarang, Tambun, Cibitung, dan Jabodetabek.</p>
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>
  </div>
</section>

