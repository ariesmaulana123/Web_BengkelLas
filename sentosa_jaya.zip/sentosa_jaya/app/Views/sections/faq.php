<!-- FAQ Section -->
<section id="faq" class="py-24 bg-slate-900 relative overflow-hidden border-t border-slate-800">
  <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Header -->
    <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Tanya Jawab</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        Pertanyaan yang <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Sering Diajukan</span>
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Informasi seputar durasi, sistem pembayaran, material, hingga garansi pengerjaan di Sentosa Jaya Las.
      </p>
    </div>

    <!-- Accordion List -->
    <div class="space-y-4">
      
      <!-- FAQ 1 -->
      <div class="faq-item rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all duration-300 reveal-fade-up">
        <button 
          type="button" 
          class="faq-button w-full px-6 py-5 text-left flex items-center justify-between text-white font-semibold text-base sm:text-lg focus:outline-none"
          aria-expanded="false"
        >
          <span>Berapa lama estimasi proses pembuatan pagar, kanopi, atau railing?</span>
          <span class="faq-icon w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 shrink-0 ml-4 transition-all duration-300">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
          </span>
        </button>
        <div class="faq-content px-6 text-slate-400 text-sm leading-relaxed">
          <div class="pb-5 pt-1 border-t border-slate-900">
            Untuk proyek standar seperti kanopi hunian atau pagar minimalis, proses fabrikasi di workshop biasanya membutuhkan waktu 4 - 7 hari kerja. Proses instalasi di lokasi dilakukan dalam 1 - 2 hari agar tidak mengganggu aktivitas Anda. Untuk konstruksi baja berat atau mezzanine, jadwal disesuaikan dengan volume tonase material yang disepakati.
          </div>
        </div>
      </div>

      <!-- FAQ 2 -->
      <div class="faq-item rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all duration-300 reveal-fade-up" style="transition-delay: 50ms;">
        <button 
          type="button" 
          class="faq-button w-full px-6 py-5 text-left flex items-center justify-between text-white font-semibold text-base sm:text-lg focus:outline-none"
          aria-expanded="false"
        >
          <span>Bagaimana skema pembayaran dan tahapan uang muka (DP)?</span>
          <span class="faq-icon w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 shrink-0 ml-4 transition-all duration-300">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
          </span>
        </button>
        <div class="faq-content px-6 text-slate-400 text-sm leading-relaxed">
          <div class="pb-5 pt-1 border-t border-slate-900">
            Skema pembayaran kami sangat transparan: Uang Muka (DP) sebesar 30% - 50% setelah penandatanganan SPK/Estimasi untuk pengadaan bahan baku, termin kedua saat barang siap pasang di lokasi, dan pelunasan akhir setelah pekerjaan selesai dan disetujui bersama pada sesi serah terima.
          </div>
        </div>
      </div>

      <!-- FAQ 3 -->
      <div class="faq-item rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all duration-300 reveal-fade-up" style="transition-delay: 100ms;">
        <button 
          type="button" 
          class="faq-button w-full px-6 py-5 text-left flex items-center justify-between text-white font-semibold text-base sm:text-lg focus:outline-none"
          aria-expanded="false"
        >
          <span>Apakah ada biaya untuk survey lokasi dan pengukuran?</span>
          <span class="faq-icon w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 shrink-0 ml-4 transition-all duration-300">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
          </span>
        </button>
        <div class="faq-content px-6 text-slate-400 text-sm leading-relaxed">
          <div class="pb-5 pt-1 border-t border-slate-900">
            Layanan survey pengukuran lokasi di wilayah Setu, Bekasi, Cikarang, Tambun, dan Cibitung dilakukan dengan jadwal yang fleksibel. Tim kami membawa contoh sampel material dan alat ukur laser digital agar estimasi biaya dapat dihitung presisi.
          </div>
        </div>
      </div>

      <!-- FAQ 4 -->
      <div class="faq-item rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all duration-300 reveal-fade-up" style="transition-delay: 150ms;">
        <button 
          type="button" 
          class="faq-button w-full px-6 py-5 text-left flex items-center justify-between text-white font-semibold text-base sm:text-lg focus:outline-none"
          aria-expanded="false"
        >
          <span>Material apa yang digunakan dan apakah ada proteksi anti-karat?</span>
          <span class="faq-icon w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 shrink-0 ml-4 transition-all duration-300">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
          </span>
        </button>
        <div class="faq-content px-6 text-slate-400 text-sm leading-relaxed">
          <div class="pb-5 pt-1 border-t border-slate-900">
            Kami hanya menggunakan besi galvanis SNI berprofil tebal, plat baja standar industri, dan stainless steel 304. Setiap sambungan las dibersihkan dengan teliti, dilapisi Zinc-Chromate Epoxy Primer 2 lapis, lalu disemprot Polyurethane / Duco kualitas tinggi untuk memastikan ketahanan karat jangka panjang.
          </div>
        </div>
      </div>

      <!-- FAQ 5 -->
      <div class="faq-item rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all duration-300 reveal-fade-up" style="transition-delay: 200ms;">
        <button 
          type="button" 
          class="faq-button w-full px-6 py-5 text-left flex items-center justify-between text-white font-semibold text-base sm:text-lg focus:outline-none"
          aria-expanded="false"
        >
          <span>Apakah bisa membuat produk custom sesuai gambar arsitek atau foto referensi?</span>
          <span class="faq-icon w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 shrink-0 ml-4 transition-all duration-300">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
          </span>
        </button>
        <div class="faq-content px-6 text-slate-400 text-sm leading-relaxed">
          <div class="pb-5 pt-1 border-t border-slate-900">
            Tentu saja. Kami berpengalaman menerjemahkan gambar kerja arsitek (CAD/3D), motif laser cutting kustom, maupun foto referensi dari Pinterest/Instagram ke dalam produk nyata dengan perhitungan dimensi dan kekuatan struktural yang aman.
          </div>
        </div>
      </div>

      <!-- FAQ 6 -->
      <div class="faq-item rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all duration-300 reveal-fade-up" style="transition-delay: 250ms;">
        <button 
          type="button" 
          class="faq-button w-full px-6 py-5 text-left flex items-center justify-between text-white font-semibold text-base sm:text-lg focus:outline-none"
          aria-expanded="false"
        >
          <span>Berapa lama masa garansi pekerjaan yang diberikan?</span>
          <span class="faq-icon w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 shrink-0 ml-4 transition-all duration-300">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
          </span>
        </button>
        <div class="faq-content px-6 text-slate-400 text-sm leading-relaxed">
          <div class="pb-5 pt-1 border-t border-slate-900">
            Semua pekerjaan fabrikasi Sentosa Jaya Las dilindungi garansi konstruksi struktural dan garansi pemasangan. Jika dalam masa garansi ditemukan kebocoran atap kanopi, engsel pintu bermasalah, atau sambungan las goyang, tim kami akan datang memperbaiki tanpa biaya tambahan.
          </div>
        </div>
      </div>

    </div>

  </div>
</section>

