<!-- Before -> Process -> After Section -->
<section class="py-24 bg-slate-900 relative overflow-hidden border-t border-slate-800">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Header -->
    <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Studi Transformasi</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        Dari Konsep & Lokasi Mentah Menjadi <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Karya Sempurna</span>
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Lihat bagaimana standar pengerjaan terencana kami mewujudkan struktur besi yang kokoh, rapi, dan presisi.
      </p>
    </div>

    <!-- 3-Phase Transformation Cards -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 relative">
      
      <!-- Phase 1: BEFORE -->
      <div class="p-6 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl flex flex-col justify-between reveal-fade-up">
        <div>
          <div class="flex items-center justify-between mb-4">
            <span class="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 uppercase tracking-wider">
              BANGUNAN IMPIAN ANDA
            </span>
            <span class="text-xs text-slate-500 font-mono">Survey & Analisis</span>
          </div>

          <div class="h-48 rounded-xl overflow-hidden mb-5 relative">
            <img 
              src="<?= base_url('assets/gambar/Rumah1.jpg') ?>" 
              alt="Kondisi Awal Lokasi Proyek" 
              class="w-full h-full object-cover filter grayscale contrast-125 hover:grayscale-0 transition-all duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-slate-950/40"></div>
            <span class="absolute bottom-3 left-3 text-xs font-semibold text-slate-200 bg-slate-900/80 px-2.5 py-1 rounded-md backdrop-blur-sm">
              Area Belum Beratap / Terbuka
            </span>
          </div>

          <h3 class="text-lg font-bold text-white mb-2">Tantangan & Kebutuhan Klien</h3>
          <p class="text-xs text-slate-400 leading-relaxed space-y-2">
            Area carport sering terkena tempias hujan dan panas terik ekstrim. Dinding samping miring tidak siku 90 derajat membutuhkan pengukuran laser meter digital secara teliti.
          </p>
        </div>

        <div class="mt-6 pt-4 border-t border-slate-800/80">
          <p class="text-xs font-semibold text-slate-300 flex items-center">
            <svg class="w-4 h-4 text-amber-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
            Tingkat Kesulitan: Akurasi Sudut Miring
          </p>
        </div>
      </div>

      <!-- Phase 2: PROCESS -->
      <div class="p-6 rounded-2xl bg-slate-950 border border-blue-500/40 shadow-xl shadow-blue-900/20 flex flex-col justify-between relative reveal-fade-up" style="transition-delay: 150ms;">
        <div class="absolute -top-3 left-1/2 transform -translate-x-1/2 px-4 py-0.5 rounded-full bg-blue-600 text-white text-[11px] font-bold uppercase tracking-wider shadow-md">
          Workshop Precision
        </div>

        <div>
          <div class="flex items-center justify-between mb-4">
            <span class="px-3 py-1 rounded-full text-xs font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20 uppercase tracking-wider">
              BANGUNAN IMPIAN ANDA
            </span>
            <span class="text-xs text-blue-400 font-mono">Fabrikasi & Las</span>
          </div>

          <div class="h-48 rounded-xl overflow-hidden mb-5 relative">
            <img 
              src="<?= base_url('assets/gambar/Rumah2.jpg') ?>"  
              alt="Proses Fabrikasi di Workshop Sentosa Jaya Las" 
              class="w-full h-full object-cover hover:scale-105 transition-all duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-blue-950/20"></div>
            <span class="absolute bottom-3 left-3 text-xs font-semibold text-blue-200 bg-slate-900/80 px-2.5 py-1 rounded-md backdrop-blur-sm">
              Full-Welding & Epoxy Anti-Karat
            </span>
          </div>

          <h3 class="text-lg font-bold text-white mb-2">Fabrikasi Terstandarisasi</h3>
          <p class="text-xs text-slate-400 leading-relaxed">
            Pemotongan sudut 45 derajat menggunakan mesin cutting presisi. Pengelasan sambungan full matang tanpa rongga, digerinda rata halus, lalu dilapisi primer epoxy zinc-chromate 2 lapis.
          </p>
        </div>

        <div class="mt-6 pt-4 border-t border-slate-800/80">
          <p class="text-xs font-semibold text-blue-400 flex items-center">
            <svg class="w-4 h-4 text-blue-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            QC: Kelulusan Uji Tekuk & Anti-Karat
          </p>
        </div>
      </div>

      <!-- Phase 3: AFTER -->
      <div class="p-6 rounded-2xl bg-slate-950 border border-emerald-500/40 shadow-xl shadow-emerald-900/10 flex flex-col justify-between reveal-fade-up" style="transition-delay: 300ms;">
        <div>
          <div class="flex items-center justify-between mb-4">
            <span class="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase tracking-wider">
              BANGUNAN IMPIAN ANDA
            </span>
            <span class="text-xs text-emerald-400 font-mono">Hasil Terpasang</span>
          </div>

          <div class="h-48 rounded-xl overflow-hidden mb-5 relative">
            <img 
              src="<?= base_url('assets/gambar/Rumah3.jpg') ?>"  
              alt="Hasil Akhir Kanopi Terpasang Rapi" 
              class="w-full h-full object-cover hover:scale-105 transition-all duration-500"
              loading="lazy"
            />
            <div class="absolute inset-0 bg-emerald-950/10"></div>
            <span class="absolute bottom-3 left-3 text-xs font-semibold text-emerald-200 bg-slate-900/80 px-2.5 py-1 rounded-md backdrop-blur-sm">
              Kokoh, Mewah & Bergaransi
            </span>
          </div>

          <h3 class="text-lg font-bold text-white mb-2">Hasil Presisi & Memuaskan</h3>
          <p class="text-xs text-slate-400 leading-relaxed">
            Instalasi bersih di lokasi dalam 1 hari kerja. Kanopi terpasang kuat menahan beban angin kencang, tidak ada kebocoran sambungan atap, dan mempercantik fasad rumah klien.
          </p>
        </div>

        <div class="mt-6 pt-4 border-t border-slate-800/80">
          <p class="text-xs font-semibold text-emerald-400 flex items-center">
            <svg class="w-4 h-4 text-emerald-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            Kepuasan Klien 100% Bergaransi
          </p>
        </div>
      </div>

    </div>

  </div>
</section>

