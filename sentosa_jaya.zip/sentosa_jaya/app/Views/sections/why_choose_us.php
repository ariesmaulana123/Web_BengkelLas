<!-- Why Choose Us Section -->
<section class="py-24 bg-slate-900/50 relative overflow-hidden border-y border-slate-800/80">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Section Header -->
    <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Keunggulan Kami</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        Mengapa Memilih <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Sentosa Jaya Las</span>?
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Komitmen kami bukan sekadar menyambung besi, melainkan menghadirkan hasil karya fabrikasi yang presisi, estetis, dan tahan puluhan tahun.
      </p>
    </div>

    <!-- 4 Pillars Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      
      <!-- Pillar 1: Custom -->
      <div class="p-7 rounded-2xl bg-slate-950/80 border border-slate-800/90 hover:border-blue-500/50 transition-all duration-300 relative group reveal-fade-up">
        <div class="w-14 h-14 rounded-2xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
          <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"/>
          </svg>
        </div>
        <div class="absolute top-6 right-6 text-3xl font-black text-slate-800 group-hover:text-blue-500/20 transition-colors font-display">01</div>
        <h3 class="text-xl font-bold text-white mb-3 group-hover:text-blue-400 transition-colors">Custom Desain</h3>
        <p class="text-sm text-slate-400 leading-relaxed">
          Setiap proyek disesuaikan 100% dengan kebutuhan ruang, selera arsitektur, dan anggaran Anda. Dari konsep minimalis hingga ornamen laser cutting rumit.
        </p>
        <ul class="mt-5 space-y-2 text-xs text-slate-300 border-t border-slate-800/80 pt-4">
          <li class="flex items-center">
            <svg class="w-4 h-4 text-blue-400 mr-2 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            Bebas modifikasi dimensi
          </li>
          <li class="flex items-center">
            <svg class="w-4 h-4 text-blue-400 mr-2 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            Sesuai gambar arsitek/sketsa
          </li>
        </ul>
      </div>

      <!-- Pillar 2: Kokoh & Presisi -->
      <div class="p-7 rounded-2xl bg-slate-950/80 border border-slate-800/90 hover:border-sky-500/50 transition-all duration-300 relative group reveal-fade-up" style="transition-delay: 100ms;">
        <div class="w-14 h-14 rounded-2xl bg-sky-600/10 border border-sky-500/20 text-sky-400 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-sky-600 group-hover:text-white transition-all duration-300">
          <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
          </svg>
        </div>
        <div class="absolute top-6 right-6 text-3xl font-black text-slate-800 group-hover:text-sky-500/20 transition-colors font-display">02</div>
        <h3 class="text-xl font-bold text-white mb-3 group-hover:text-sky-400 transition-colors">Kokoh & Presisi</h3>
        <p class="text-sm text-slate-400 leading-relaxed">
          Menggunakan material besi SNI berdimensi tebal dengan pengelasan matang full-penetration yang menjamin kekuatan beban maksimal dan ketepatan siku.
        </p>
        <ul class="mt-5 space-y-2 text-xs text-slate-300 border-t border-slate-800/80 pt-4">
          <li class="flex items-center">
            <svg class="w-4 h-4 text-sky-400 mr-2 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            Besi galvanis anti karat asli
          </li>
          <li class="flex items-center">
            <svg class="w-4 h-4 text-sky-400 mr-2 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            Sudut 90° presisi waterpass
          </li>
        </ul>
      </div>

      <!-- Pillar 3: Pengerjaan Rapi -->
      <div class="p-7 rounded-2xl bg-slate-950/80 border border-slate-800/90 hover:border-indigo-500/50 transition-all duration-300 relative group reveal-fade-up" style="transition-delay: 200ms;">
        <div class="w-14 h-14 rounded-2xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300">
          <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/>
          </svg>
        </div>
        <div class="absolute top-6 right-6 text-3xl font-black text-slate-800 group-hover:text-indigo-500/20 transition-colors font-display">03</div>
        <h3 class="text-xl font-bold text-white mb-3 group-hover:text-indigo-400 transition-colors">Pengerjaan Rapi</h3>
        <p class="text-sm text-slate-400 leading-relaxed">
          Proses gerinda halus, pendempulan celah sambungan, primer anti-karat epoxy, dan pengecatan berlapis menghasilkan permukaan halus bebas bekas las kasar.
        </p>
        <ul class="mt-5 space-y-2 text-xs text-slate-300 border-t border-slate-800/80 pt-4">
          <li class="flex items-center">
            <svg class="w-4 h-4 text-indigo-400 mr-2 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            Cat epoxy primer + polyurethane
          </li>
          <li class="flex items-center">
            <svg class="w-4 h-4 text-indigo-400 mr-2 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            Sambungan halus tanpa celah
          </li>
        </ul>
      </div>

      <!-- Pillar 4: Proses Terstruktur -->
      <div class="p-7 rounded-2xl bg-slate-950/80 border border-slate-800/90 hover:border-cyan-500/50 transition-all duration-300 relative group reveal-fade-up" style="transition-delay: 300ms;">
        <div class="w-14 h-14 rounded-2xl bg-cyan-600/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-cyan-600 group-hover:text-white transition-all duration-300">
          <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/>
          </svg>
        </div>
        <div class="absolute top-6 right-6 text-3xl font-black text-slate-800 group-hover:text-cyan-500/20 transition-colors font-display">04</div>
        <h3 class="text-xl font-bold text-white mb-3 group-hover:text-cyan-400 transition-colors">Proses Terstruktur</h3>
        <p class="text-sm text-slate-400 leading-relaxed">
          Tahapan kerja transparan mulai dari survey pengukuran, rincian biaya detail tanpa biaya tersembunyi, pengerjaan terjadwal, hingga serah terima bergaransi.
        </p>
        <ul class="mt-5 space-y-2 text-xs text-slate-300 border-t border-slate-800/80 pt-4">
          <li class="flex items-center">
            <svg class="w-4 h-4 text-cyan-400 mr-2 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            Estimasi detail & transparan
          </li>
          <li class="flex items-center">
            <svg class="w-4 h-4 text-cyan-400 mr-2 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            Jaminan garansi pemeliharaan
          </li>
        </ul>
      </div>

    </div>

  </div>
</section>

