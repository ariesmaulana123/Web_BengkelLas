<!-- Kontak Section -->
<section id="kontak" class="py-24 bg-slate-950 relative overflow-hidden">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Header -->
    <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Informasi & Pengajuan Proyek</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        Hubungi <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Sentosa Jaya Las</span>
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Sampaikan rincian proyek Anda melalui formulir di bawah ini atau kunjungi langsung workshop fabrikasi kami di Setu, Bekasi.
      </p>
    </div>

    <!-- Contact Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-12">
      
      <!-- Left: Workshop Details Card -->
      <div class="lg:col-span-5 space-y-6 reveal-fade-right">
        <div class="p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-7">
          
          <div>
            <h3 class="text-xl font-bold text-white mb-2">Kantor & Workshop Fabrikasi</h3>
            <p class="text-xs text-slate-400 leading-relaxed">
              Pusat perakitan dan konsultasi teknis fabrikasi besi, baja WF, dan produk logam terpadu.
            </p>
          </div>

          <div class="space-y-5 border-t border-slate-800 pt-6 text-sm">
            
            <!-- Address -->
            <div class="flex items-start space-x-4">
              <div class="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 mt-0.5">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
              </div>
              <div>
                <p class="text-xs text-slate-400 font-semibold uppercase tracking-wider">Alamat Workshop</p>
                <p class="text-slate-200 font-medium mt-0.5">Jl.Kubang, Kp.Cijengkol, Rt03/Rw09, Kec. Setu, Kabupaten Bekasi, Jawa Barat 17320</p>
              </div>
            </div>

            <!-- Operating Hours -->
            <div class="flex items-start space-x-4">
              <div class="w-10 h-10 rounded-xl bg-sky-600/10 border border-sky-500/20 text-sky-400 flex items-center justify-center shrink-0 mt-0.5">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              </div>
              <div>
                <p class="text-xs text-slate-400 font-semibold uppercase tracking-wider">Jam Operasional</p>
                <p class="text-slate-200 font-medium mt-0.5">Senin - Sabtu: 08.00 - 21.00 WIB</p>
                <p class="text-xs text-slate-400">Minggu / Hari Libur: Sesuai Perjanjian Survey</p>
              </div>
            </div>

            <!-- Phone & Email -->
            <div class="flex items-start space-x-4">
              <div class="w-10 h-10 rounded-xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
              </div>
              <div>
                <p class="text-xs text-slate-400 font-semibold uppercase tracking-wider">Telepon & Email</p>
                <p class="text-slate-200 font-medium mt-0.5">+62 877-6636-4557</p>
                <p class="text-xs text-slate-400">sentosajayalas.1@gmail.com</p>
              </div>
            </div>

          </div>

          <!-- Trust Badge -->
          <div class="p-4 rounded-2xl bg-blue-600/10 border border-blue-500/20 flex items-center space-x-3 text-xs text-blue-300">
            <svg class="w-5 h-5 text-blue-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
            <span>Estimasi biaya jelas dengan spesifikasi tertulis tanpa biaya tersembunyi.</span>
          </div>

        </div>
      </div>
      <!-- Right: Google Maps -->
      <div class="lg:col-span-7 reveal-fade-left">
        <div class="p-8 sm:p-10 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl relative">
          
          <h3 class="text-2xl font-bold text-white mb-2">Lokasi Maps Peta Sentosa Jaya Las</h3>
          <p class="text-xs text-slate-400 mb-8">
            lokasi bengkel Sentosa Jaya Las.
          </p>

          <!-- Success Alert Placeholder -->
          <div id="form-success-alert" class="hidden mb-6 p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-sm space-y-3">
            <div class="flex items-start space-x-3">
              <svg class="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
              <div>
                <p class="font-bold text-base text-emerald-300">Permintaan Berhasil Dikirim!</p>
                <p class="text-xs text-emerald-200/90 mt-0.5">Detail kebutuhan fabrikasi Anda telah tercatat. Tim teknis Sentosa Jaya Las akan segera meninjau spesifikasi dan menghubungi Anda.</p>
              </div>
            </div>
            <div id="form-wa-action-box" class="pt-2 border-t border-emerald-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <span class="text-xs text-slate-300">Ingin respon lebih cepat dalam hitungan menit?</span>
              <a 
                href="#" 
                id="form-wa-direct-link"
                target="_blank"
                rel="noopener noreferrer"
                class="inline-flex items-center justify-center px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition-all self-start sm:self-auto"
              >
                <span>Teruskan ke WhatsApp</span>
                <svg class="w-4 h-4 ml-1.5 fill-current" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
              </a>
            </div>
          </div>

          <form id="contact-form" class="space-y-5">
  
          </form>

        <div class="h-full min-h-[450px] w-full rounded-3xl overflow-hidden bg-slate-900/90 border border-slate-800 shadow-2xl relative">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.5539908429646!2d107.03971127402663!3d-6.322161161862292!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6991b9cf169215%3A0x34d1236b74bd3831!2sSentosa%20Jaya%20Las!5e0!3m2!1sid!2sid!4v1789918848048!5m2!1sid!2sid" 
            width="100%" 
            height="100%" 
            class="w-full h-full min-h-[450px]" 
            style="border:0;" 
            allowfullscreen="" 
            loading="lazy" 
            referrerpolicy="strict-origin-when-cross-origin">
          </iframe>
        </div>
      </div>

    </div>

  </div>
</section>

