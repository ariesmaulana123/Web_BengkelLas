<!-- Kalkulator Estimasi Section -->
<section id="kalkulator" class="relative py-24 bg-slate-950 border-t border-b border-slate-800/80 overflow-hidden">
  
  <!-- Background Ambient Glow & Grid -->
  <div class="absolute inset-0 bg-industrial-grid opacity-25 pointer-events-none"></div>
  <div class="absolute w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none top-1/4 -left-48"></div>
  <div class="absolute w-[500px] h-[500px] bg-sky-500/10 rounded-full blur-[120px] pointer-events-none bottom-10 -right-48"></div>

  <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    
    <!-- Section Header -->
    <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/25 text-blue-400 text-xs font-bold uppercase tracking-wider">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
        </svg>
        <span>KALKULATOR ESTIMASI BIAYA</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display">
        Hitung Estimasi Proyek <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-blue-500">Secara Real-Time</span>
      </h2>
      <p class="text-slate-400 text-sm sm:text-base leading-relaxed">
        Dapatkan perkiraan biaya transparan berdasarkan ukuran dan spesifikasi material pilihan Anda. Perhitungan akurat ditenagai engine khusus dengan harga langsung dari database master material.
      </p>
    </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        <!-- Left Column: Dynamic Calculator Input Form -->
        <div class="lg:col-span-6 bg-slate-900/80 p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl backdrop-blur-xl">
          
          <div class="flex items-center justify-between pb-5 border-b border-slate-800 mb-6">
            <div class="flex items-center space-x-3">
              <div class="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center font-bold">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                </svg>
              </div>
              <div>
                <h3 class="text-base sm:text-lg font-bold text-white">Form Spesifikasi Proyek</h3>
                <p class="text-xs text-slate-400">Pilih jenis dan masukkan dimensi pengerjaan</p>
              </div>
            </div>
            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse"></span>
              <?= !empty($isLoggedIn) ? 'Aktif: ' . esc($currentUser['nama'] ?? 'Pelanggan') : 'Siap menghitung' ?>
            </span>
          </div>

          <!-- Alert Box for Client Validation Errors -->
          <div id="calc-error-alert" class="hidden mb-5 p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center space-x-2.5">
            <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <span id="calc-error-text">Terjadi kesalahan validasi.</span>
          </div>

          <form id="calculator-form" method="POST" action="" class="space-y-4">
            
            <!-- 1. Jenis Pengerjaan Dropdown -->
            <div>
              <label for="calc-jp" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Jenis Pengerjaan <span class="text-blue-400">*</span>
              </label>
              <div class="relative">
                <select 
                  id="calc-jp" 
                  name="id_jp" 
                  required
                  class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all cursor-pointer"
                >
                  <?php if (!empty($jenisPekerjaan)): ?>
                    <?php foreach ($jenisPekerjaan as $index => $jp): ?>
                      <option value="<?= esc($jp['id_jp']) ?>" data-nama="<?= esc(strtolower($jp['nama'])) ?>" <?= $index === 0 ? 'selected' : '' ?>>
                        <?= esc($jp['nama']) ?>
                      </option>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <option value="" disabled selected>-- Pilih Jenis Pengerjaan --</option>
                  <?php endif; ?>
                </select>
              </div>
            </div>

            <!-- 2. Dimensi Input: Panjang & Lebar -->
            <div id="general-dimension-fields" class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label for="calc-panjang" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Panjang (Meter) <span class="text-blue-400">*</span>
                </label>
                <div class="relative">
                  <input 
                    type="number" 
                    id="calc-panjang" 
                    name="panjang" 
                    step="0.01" 
                    min="0.1" 
                    placeholder="Contoh: 5.0"
                    class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                  />
                  <span class="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-500">m</span>
                </div>
              </div>

              <div>
                <label for="calc-lebar" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Lebar (Meter) <span class="text-blue-400">*</span>
                </label>
                <div class="relative">
                  <input 
                    type="number" 
                    id="calc-lebar" 
                    name="lebar" 
                    step="0.01" 
                    min="0.1" 
                    placeholder="Contoh: 3.0"
                    class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                  />
                  <span class="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-500">m</span>
                </div>
              </div>
            </div>

            <!-- 3. Dynamic Section for Kanopi Specifics -->
            <div id="kanopi-specific-fields" class="space-y-4 pt-1">
              
              <!-- Tinggi Tiang -->
              <div>
                <label for="calc-tinggi" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Tinggi Tiang (Meter) <span class="text-slate-500 text-[10px] normal-case font-normal">(Opsional)</span>
                </label>
                <div class="relative">
                  <input 
                    type="number" 
                    id="calc-tinggi" 
                    name="tinggi" 
                    step="0.01" 
                    min="0" 
                    placeholder="Contoh: 3.0"
                    class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
                  />
                  <span class="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-500">m</span>
                </div>
              </div>

              <!-- Jenis Rangka Kanopi -->
              <div>
                <label for="calc-mat-rangka" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Jenis Rangka <span class="text-blue-400">*</span>
                </label>
                <select 
                  id="calc-mat-rangka" 
                  name="id_material_rangka" 
                  class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all cursor-pointer"
                >
                  <option value="" disabled selected>-- Pilih Jenis Rangka --</option>
                </select>
              </div>

              <!-- Jenis Atap Kanopi -->
              <div>
                <label for="calc-mat-atap" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Jenis Atap <span class="text-blue-400">*</span>
                </label>
                <select 
                  id="calc-mat-atap" 
                  name="id_material_atap" 
                  class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all cursor-pointer"
                >
                  <option value="" disabled selected>-- Pilih Jenis Atap --</option>
                </select>
              </div>

            </div>

            <!-- 4. Dynamic Section for Non-Kanopi (Pagar, Railing, Teralis) -->
            <div id="general-material-field" class="hidden space-y-4 pt-1">
              <div>
                <label for="calc-mat-utama" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Pilihan Model & Material <span class="text-blue-400">*</span>
                </label>
                <select 
                  id="calc-mat-utama" 
                  name="id_material_utama" 
                  class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all cursor-pointer"
                >
                  <option value="" disabled selected>-- Pilih Material / Model --</option>
                </select>
              </div>
            </div>

            <!-- 5. Detail Teralis: setiap ukuran dihitung sebagai item terpisah -->
            <div id="teralis-specific-fields" class="hidden space-y-4 pt-1">
              <div class="flex items-center justify-between">
                <div>
                  <p class="text-xs font-semibold text-slate-300 uppercase tracking-wider">Detail Ukuran Teralis</p>
                  <p class="text-[11px] text-slate-500">Harga dihitung dari kebutuhan frame, jeruji, batang, dan jasa aktif.</p>
                </div>
                <button type="button" id="add-teralis-item" class="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700">+ Tambah ukuran</button>
              </div>
              <div id="teralis-items" class="space-y-3"></div>
            </div>

            <!-- 6. Catatan / Printilan -->
            <div>
              <div class="flex items-center justify-between mb-1.5">
                <label for="calc-catatan" class="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Catatan / Printilan Tambahan
                </label>
                <span class="text-[10px] text-amber-400/90 font-medium">*Tidak dihitung otomatis</span>
              </div>
              <textarea 
                id="calc-catatan" 
                name="catatan" 
                rows="2" 
                placeholder="Contoh: Termasuk talang seng 4m, lampu LED strip kanopi, atau motif ornamen khusus..."
                class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all placeholder:text-slate-600 resize-none"
              ></textarea>
              <p class="text-[11px] text-slate-500 mt-1">
                Catatan printilan akan disimpan dan dikonfirmasikan saat survey lapangan teknis.
              </p>
            </div>

            <!-- Submit Button -->
            <button 
              type="submit" 
              id="calc-submit-btn"
              class="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm uppercase tracking-wider shadow-lg shadow-blue-600/30 hover:shadow-blue-500/50 hover:-translate-y-0.5 transition-all flex items-center justify-center space-x-2"
            >
              <svg id="calc-icon-normal" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
              </svg>
              <svg id="calc-icon-loading" class="animate-spin -ml-1 mr-2 h-5 w-5 text-white hidden" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <span id="calc-btn-text">Hitung Estimasi</span>
            </button>

          </form>

        </div>

        <!-- Right Column: Results Display & Survey Booking -->
        <div class="lg:col-span-6 space-y-6">
          
          <!-- Placeholder State (Before calculation) -->
          <div id="calc-result-placeholder" class="p-8 sm:p-10 rounded-3xl bg-slate-900/50 border border-slate-800 border-dashed text-center flex flex-col items-center justify-center min-h-[460px]">
            <div class="w-16 h-16 rounded-2xl bg-slate-800/80 text-slate-500 flex items-center justify-center mb-4">
              <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
            </div>
            <h4 class="text-base font-bold text-slate-300 mb-1">Hasil Perhitungan Belum Tersedia</h4>
            <p class="text-xs text-slate-500 max-w-sm">
              Lengkapi spesifikasi ukuran dan material pada formulir di sebelah kiri, lalu klik <strong>"Hitung Estimasi"</strong> untuk melihat rincian biaya.
            </p>
          </div>

          <!-- Active Calculation Result Card (Populated by JavaScript) -->
          <div id="calc-result-card" class="hidden p-6 sm:p-8 rounded-3xl bg-slate-900/95 border border-blue-500/30 shadow-2xl backdrop-blur-xl space-y-6">
            
            <!-- Result Header -->
            <div class="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <span class="text-[10px] font-mono uppercase tracking-widest text-blue-400 font-semibold">HASIL ESTIMASI</span>
                <h3 id="res-nama-pekerjaan" class="text-xl font-bold text-white">Kanopi Carport</h3>
              </div>
              <div class="text-right">
                <p class="text-xs text-slate-400">Total Luas</p>
                <p id="res-luas" class="text-lg font-extrabold text-sky-400 font-mono">15.00 m²</p>
              </div>
            </div>

            <!-- Breakdown Table -->
            <div class="space-y-3">
              <p class="text-xs font-semibold text-slate-300 uppercase tracking-wider">Rincian Material & Jasa</p>
              <div class="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
                <table class="w-full text-left text-xs text-slate-300">
                  <thead class="bg-slate-900/90 text-slate-400 border-b border-slate-800 uppercase font-mono text-[10px]">
                    <tr>
                      <th class="py-2.5 px-3">Item / Uraian</th>
                      <th class="py-2.5 px-2 text-center">Volume</th>
                      <th class="py-2.5 px-3 text-right">Harga Satuan</th>
                      <th class="py-2.5 px-3 text-right">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody id="res-breakdown-body" class="divide-y divide-slate-800/60 font-sans">
                    <!-- Populated by JS -->
                  </tbody>
                </table>
              </div>
            </div>

            <!-- Estimation Range Summary Box -->
            <div class="p-4 rounded-2xl bg-blue-950/40 border border-blue-500/30 space-y-3">
              <div class="flex items-center justify-between">
                <span class="text-xs text-slate-300 font-medium">Subtotal Kalkulasi:</span>
                <span id="res-subtotal" class="text-sm font-bold text-white font-mono">Rp 0</span>
              </div>
              <div class="pt-2 border-t border-blue-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <span class="text-xs font-semibold text-blue-300 uppercase tracking-wider">Range Estimasi (±10%):</span>
                <div class="text-base sm:text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-300 via-sky-200 to-white font-mono">
                  <span id="res-range">Rp 0 - Rp 0</span>
                </div>
              </div>
            </div>

            <!-- Notes Display (If Any) -->
            <div id="res-catatan-wrapper" class="hidden p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300 space-y-1">
              <span class="font-bold text-slate-400 uppercase tracking-wider text-[10px] block">Catatan Tambahan:</span>
              <p id="res-catatan-text" class="italic text-slate-300"></p>
            </div>

            <!-- Disclaimer Banner -->
            <div class="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300/90 text-xs flex items-start space-x-2.5">
              <svg class="w-4 h-4 text-amber-400 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
              <p id="res-disclaimer" class="leading-relaxed text-[11px]">
                Perhitungan di atas merupakan estimasi awal dan bukan harga final. Kebutuhan material aktual dan penawaran pasti akan ditetapkan setelah survey pengukuran langsung di lokasi oleh teknisi kami.
              </p>
            </div>

            <!-- Action Button: Save Estimate -->
            <button 
              type="button" 
              id="calc-save-survey-btn"
              class="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm uppercase tracking-wider shadow-lg shadow-emerald-600/30 hover:shadow-emerald-500/50 hover:-translate-y-0.5 transition-all flex items-center justify-center space-x-2"
            >
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
              </svg>
              <span>Simpan Estimasi</span>
            </button>

          </div>

        </div>

      </div>

  </div>
</section>
