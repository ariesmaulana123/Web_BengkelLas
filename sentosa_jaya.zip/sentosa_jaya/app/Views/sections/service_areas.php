<!-- Area Layanan Section -->
<section class="py-24 bg-slate-950 relative overflow-hidden">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    
    <!-- Header -->
    <div class="text-center max-w-3xl mx-auto mb-16 space-y-4">
      <div class="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-wider reveal-fade-up">
        <span>Jangkauan Operasional</span>
      </div>
      <h2 class="text-3xl sm:text-4xl font-extrabold text-white font-display tracking-tight reveal-fade-up">
        Melayani Wilayah <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-sky-400">Bekasi & Sekitarnya</span>
      </h2>
      <p class="text-slate-400 text-base sm:text-lg reveal-fade-up">
        Dengan basis workshop di Setu, Bekasi, tim kami siap meluncur untuk survey, pengiriman, dan instalasi di seluruh kawasan penyangga.
      </p>
    </div>

    <!-- Area Cards Grid -->
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-12">
      
      <!-- Area 1: Setu -->
      <div class="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 text-center group transition-all duration-300 reveal-fade-up">
        <div class="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
        </div>
        <h3 class="text-base font-bold text-white group-hover:text-blue-400 transition-colors">Setu</h3>
        <p class="text-[11px] text-slate-400 mt-1">Workshop Base</p>
      </div>

      <!-- Area 2: Bekasi -->
      <div class="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-sky-500/50 text-center group transition-all duration-300 reveal-fade-up" style="transition-delay: 50ms;">
        <div class="w-10 h-10 rounded-xl bg-sky-600/10 border border-sky-500/20 text-sky-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 group-hover:bg-sky-600 group-hover:text-white transition-all">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
        </div>
        <h3 class="text-base font-bold text-white group-hover:text-sky-400 transition-colors">Bekasi Kota</h3>
        <p class="text-[11px] text-slate-400 mt-1">Barat, Timur, Utara, Selatan</p>
      </div>

      <!-- Area 3: Cikarang -->
      <div class="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 text-center group transition-all duration-300 reveal-fade-up" style="transition-delay: 100ms;">
        <div class="w-10 h-10 rounded-xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
        </div>
        <h3 class="text-base font-bold text-white group-hover:text-indigo-400 transition-colors">Cikarang</h3>
        <p class="text-[11px] text-slate-400 mt-1">Pusat, Barat, MM2100, Jababeka</p>
      </div>

      <!-- Area 4: Tambun -->
      <div class="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 text-center group transition-all duration-300 reveal-fade-up" style="transition-delay: 150ms;">
        <div class="w-10 h-10 rounded-xl bg-cyan-600/10 border border-cyan-500/20 text-cyan-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 group-hover:bg-cyan-600 group-hover:text-white transition-all">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
        </div>
        <h3 class="text-base font-bold text-white group-hover:text-cyan-400 transition-colors">Tambun</h3>
        <p class="text-[11px] text-slate-400 mt-1">Selatan & Utara</p>
      </div>

      <!-- Area 5: Cibitung -->
      <div class="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500/50 text-center group transition-all duration-300 reveal-fade-up" style="transition-delay: 200ms;">
        <div class="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
        </div>
        <h3 class="text-base font-bold text-white group-hover:text-blue-400 transition-colors">Cibitung</h3>
        <p class="text-[11px] text-slate-400 mt-1">Kawasan Industri & Residensial</p>
      </div>

      <!-- Area 6: Sekitarnya -->
      <div class="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500/50 text-center group transition-all duration-300 reveal-fade-up" style="transition-delay: 250ms;">
        <div class="w-10 h-10 rounded-xl bg-emerald-600/10 border border-emerald-500/20 text-emerald-400 mx-auto mb-3 flex items-center justify-center group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white transition-all">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <h3 class="text-base font-bold text-white group-hover:text-emerald-400 transition-colors">Jabodetabek</h3>
        <p class="text-[11px] text-slate-400 mt-1">Jakarta, Bogor, Depok, Karawang</p>
      </div>

    </div>

    <!-- Operational Perks Bar -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 p-6 rounded-2xl bg-slate-900/60 border border-slate-800 reveal-fade-up">
      <div class="flex items-center space-x-3.5">
        <div class="w-10 h-10 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center shrink-0">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
        </div>
        <div>
          <h4 class="text-sm font-semibold text-white">Respon Cepat Survey</h4>
          <p class="text-xs text-slate-400">Jadwal survey fleksibel menyesuaikan waktu luang Anda.</p>
        </div>
      </div>

      <div class="flex items-center space-x-3.5">
        <div class="w-10 h-10 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center shrink-0">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"/></svg>
        </div>
        <div>
          <h4 class="text-sm font-semibold text-white">Armada Pengiriman Mandiri</h4>
          <p class="text-xs text-slate-400">Material diantar aman langsung dari workshop ke lokasi.</p>
        </div>
      </div>

      <div class="flex items-center space-x-3.5">
        <div class="w-10 h-10 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
        </div>
        <div>
          <h4 class="text-sm font-semibold text-white">Garansi Pemasangan Wilayah</h4>
          <p class="text-xs text-slate-400">Layanan purna jual dan perbaikan jika terjadi kendala.</p>
        </div>
      </div>
    </div>

  </div>
</section>

