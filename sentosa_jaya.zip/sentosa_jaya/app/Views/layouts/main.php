<?php
$rawWhatsApp = (string) ($companySettings['no_wa'] ?? $company['whatsapp'] ?? '087766364557');
$whatsappPhone = preg_replace('/[^0-9]/', '', $rawWhatsApp);
if (str_starts_with($whatsappPhone, '0')) {
  $whatsappPhone = '62' . substr($whatsappPhone, 1);
} elseif ($whatsappPhone !== '' && !str_starts_with($whatsappPhone, '62')) {
  $whatsappPhone = '62' . ltrim($whatsappPhone, '0');
}
if ($whatsappPhone === '') {
  $whatsappPhone = '6287766364557';
}
$whatsappMessage = 'Halo Sentosa Jaya Las, saya ingin konsultasi mengenai kebutuhan fabrikasi besi / konstruksi.';
?>
<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  
  <!-- SEO Meta Tags -->
  <title><?= esc($title ?? 'Sentosa Jaya Las - Bengkel Las & Fabrikasi Besi Profesional Bekasi') ?></title>
  <meta name="description" content="Sentosa Jaya Las - Solusi Fabrikasi Besi & Baja WF untuk Hunian, Bisnis & Proyek di Setu, Bekasi, Cikarang, Tambun, Cibitung. Pagar, Kanopi, Railing, Tangga & Custom.">
  <meta name="keywords" content="bengkel las setu, bengkel las bekasi, kanopi alderon cikarang, pagar laser cutting, railing tangga minimalis, konstruksi baja wf, sentosa jaya las">
  <meta name="author" content="Sentosa Jaya Las">
  <meta name="robots" content="index, follow">
  
  <!-- Open Graph Meta -->
  <meta property="og:title" content="Sentosa Jaya Las - Bengkel Las & Steel Fabrication Profesional">
  <meta property="og:description" content="Solusi fabrikasi presisi tinggi untuk hunian, bisnis, dan proyek di Bekasi & sekitarnya. Material SNI & Bergaransi.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="<?= base_url() ?>">
  <meta property="og:image" content="https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80">

  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="<?= base_url('favicon.ico') ?>">

  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            brand: {
              navy: '#0B132B',
              dark: '#0F172A',
              card: '#1E293B',
              blue: '#2563EB',
              blueHover: '#1D4ED8',
              sky: '#38BDF8',
              lightBlue: '#E0F2FE'
            }
          }
        }
      }
    }
  </script>

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">

  <!-- Schema.org JSON-LD Structured Data for Local Business SEO -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "HomeAndConstructionBusiness",
    "name": "Sentosa Jaya Las",
    "image": "https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80",
    "telephone": "+<?= esc($whatsappPhone) ?>",
    "email": "kontak@sentosajayalas.com",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Jl. Raya Setu",
      "addressLocality": "Setu, Bekasi",
      "addressRegion": "Jawa Barat",
      "postalCode": "17320",
      "addressCountry": "ID"
    },
    "url": "<?= base_url() ?>",
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
      ],
      "opens": "08:00",
      "closes": "21:00"
    },
    "priceRange": "$$",
    "areaServed": [
      "Setu",
      "Bekasi",
      "Cikarang",
      "Tambun",
      "Cibitung",
      "Jabodetabek"
    ]
  }
  </script>

  <!-- Custom Stylesheet -->
  <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body class="bg-slate-950 text-slate-100 antialiased selection:bg-blue-600 selection:text-white overflow-x-hidden">

  <!-- 1. Scroll Progress Bar -->
  <div id="scroll-progress"></div>

  <!-- 2. Main Navbar -->
  <?php 
    $currentUri = service('uri')->getPath();
    $isAuthPage = str_contains($currentUri, 'login') || str_contains($currentUri, 'register');
  ?>
  <header id="main-navbar" class="fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto flex items-center justify-between">
      
      <!-- Brand Logo -->
      <a href="<?= base_url() ?>" class="flex items-center space-x-3 group">
        <div class="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-gray-800 shadow-lg shadow-200/50 group-hover:scale-105 transition-all overflow-hidden">
          <img src="<?= base_url('assets/gambar/logo_sentosa.png') ?>" alt="Sentosa Jaya Las" class="w-full h-full object-contain p-1">
        </div>
        <div class="flex flex-col">
          <span class="text-lg font-black tracking-tight text-white font-display uppercase leading-tight group-hover:text-blue-400 transition-colors">
            Sentosa Jaya <span class="text-blue-500">Las</span>
          </span>
          <span class="text-[10px] tracking-widest uppercase text-slate-400 font-semibold font-mono">
            Bengkel Las
          </span>
        </div>
      </a>

      <?php if ($isAuthPage): ?>
        <!-- Auth Pages Navigation (Login / Register) -->
        <div class="flex items-center space-x-3">
          <a 
            href="<?= base_url() ?>" 
            class="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold border border-slate-800 transition-all flex items-center space-x-1.5"
          >
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
            </svg>
            <span>Kembali ke Beranda</span>
          </a>
          <?php if (str_contains($currentUri, 'login')): ?>
          <?php endif; ?>
        </div>
      <?php else: ?>
        <!-- Desktop Navigation Menu -->
        <nav class="hidden lg:flex items-center space-x-5 xl:space-x-7 text-sm font-medium text-slate-300">
          <a href="<?= base_url('/#beranda') ?>" class="nav-link hover:text-white transition-colors">Beranda</a>
          <a href="<?= base_url('/#tentang-kami') ?>" class="nav-link hover:text-white transition-colors">Tentang Kami</a>
          <a href="<?= base_url('/#layanan') ?>" class="nav-link hover:text-white transition-colors">Layanan</a>
          <a href="<?= base_url('/#proyek') ?>" class="nav-link hover:text-white transition-colors">Proyek</a>
          <a href="<?= base_url('/#proses-kerja') ?>" class="nav-link hover:text-white transition-colors">Proses Kerja</a>
          <a href="<?= base_url('/#kontak') ?>" class="nav-link hover:text-white transition-colors">Kontak</a>
          <a href="<?= base_url('/#kalkulator') ?>" class="nav-link hover:text-white transition-colors">Kalkulator</a>
        </nav>

        <!-- Main Desktop CTA / Auth Action -->
        <div class="hidden lg:flex items-center space-x-2.5">
          <?php if (session()->get('isLoggedIn')): ?>
            <?php $userRole = session()->get('role') ?? 'customer'; ?>
            <?php if ($userRole === 'admin' || $userRole === 'tukang'): ?>
              <a 
                href="<?= base_url('admin/dashboard') ?>" 
                class="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold uppercase tracking-wider shadow-md shadow-indigo-600/30 hover:shadow-indigo-500/50 hover:-translate-y-0.5 transition-all flex items-center space-x-1.5"
              >
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
                <span>Panel <?= $userRole === 'admin' ? 'Admin' : 'Bengkel' ?></span>
              </a>
            <?php endif; ?>

            <a
              href="<?= base_url('riwayat') ?>"
              aria-label="Riwayat Estimasi"
              title="Riwayat Estimasi"
              class="w-10 h-10 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 hover:text-white border border-blue-500/30 hover:border-blue-400 transition-all flex items-center justify-center"
            >
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
            </a>
            <a 
              href="<?= base_url('logout') ?>" 
              class="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-all"
            >
              Keluar
            </a>
          <?php else: ?>
            <a 
              href="<?= base_url('riwayat') ?>" 
              class="group inline-flex items-center gap-2 px-2 py-1.5 text-slate-400 hover:text-white transition-all duration-200"
            >
              <svg class="w-5 h-5 text-blue-400 group-hover:scale-110 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
              <span class="text-sm font-medium tracking-wide">Riwayat Estimasi</span>
            </a>
            <a
              href="<?= base_url('login') ?>" 
              class="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider shadow-md shadow-blue-600/20 hover:shadow-blue-500/40 hover:-translate-y-0.5 transition-all flex items-center space-x-1.5"
            >
              <!-- Contoh menyamarkan tombol menjadi tautan status sistem yang tersembunyi di footer -->
              <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
              <span>Status Aktif</span>
          </a>
          <?php endif; ?>
        </div>

        <!-- Mobile Hamburger Button -->
        <button 
          id="mobile-menu-btn" 
          type="button" 
          class="lg:hidden w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white flex items-center justify-center focus:outline-none"
          aria-label="Toggle Menu"
        >
          <svg id="menu-icon-bars" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
          </svg>
          <svg id="menu-icon-close" class="w-6 h-6 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </button>
      <?php endif; ?>

    </div>

    <?php if (!$isAuthPage): ?>
      <!-- Mobile Menu Dropdown -->
      <div id="mobile-menu" class="hidden lg:hidden max-w-7xl mx-auto mt-3 p-5 rounded-2xl bg-slate-900/95 backdrop-blur-xl border border-slate-800 shadow-2xl space-y-2">
        <a href="<?= base_url('/#beranda') ?>" class="block py-2 px-3 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-800 hover:text-blue-400">Beranda</a>
        <a href="<?= base_url('/#tentang-kami') ?>" class="block py-2 px-3 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-800 hover:text-blue-400">Tentang Kami</a>
        <a href="<?= base_url('/#layanan') ?>" class="block py-2 px-3 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-800 hover:text-blue-400">Layanan</a>
        <a 
          href="<?= base_url('/#kalkulator') ?>" 
          class="block py-2 px-3 rounded-lg text-sm font-bold text-blue-400 hover:bg-slate-800 flex items-center space-x-2"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
          </svg>
          <span>Kalkulator Estimasi</span>
        </a>
        <a href="<?= base_url('/#proyek') ?>" class="block py-2 px-3 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-800 hover:text-blue-400">Proyek</a>
        <a href="<?= base_url('/#proses-kerja') ?>" class="block py-2 px-3 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-800 hover:text-blue-400">Proses Kerja</a>
        <a href="<?= base_url('/#kontak') ?>" class="block py-2 px-3 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-800 hover:text-blue-400">Kontak</a>
        
        <div class="pt-3 border-t border-slate-800 space-y-2">
          <a href="<?= base_url('riwayat') ?>" class="block w-full py-2.5 px-3 text-center rounded-xl bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600 hover:text-white text-xs font-bold uppercase tracking-wider transition-all">
            <span class="inline-flex items-center justify-center space-x-2">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
              <span>Riwayat Estimasi</span>
            </span>
          </a>
          <?php if (session()->get('isLoggedIn')): ?>
            <?php $userRole = session()->get('role') ?? 'customer'; ?>
            <div class="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
              <div class="flex items-center space-x-2">
                <div class="w-6 h-6 rounded-lg bg-blue-600/30 text-blue-400 flex items-center justify-center font-bold text-[10px]">
                  <?= esc(strtoupper(substr(session()->get('nama') ?? 'U', 0, 1))) ?>
                </div>
                <span><strong><?= esc(session()->get('nama')) ?></strong></span>
              </div>
              <a href="<?= base_url('logout') ?>" class="text-red-400 font-bold hover:underline">Keluar</a>
            </div>

            <?php if ($userRole === 'admin' || $userRole === 'tukang'): ?>
              <a href="<?= base_url('admin/dashboard') ?>" class="block w-full py-2.5 text-center rounded-xl bg-indigo-600 text-white text-xs font-bold uppercase tracking-wider shadow-md shadow-indigo-600/30">
                Buka Panel <?= $userRole === 'admin' ? 'Admin' : 'Bengkel' ?>
              </a>
            <?php endif; ?>

          <?php else: ?>
            <a href="<?= base_url('login') ?>" class="block w-full py-2.5 text-center rounded-xl bg-slate-800 text-slate-200 hover:text-white text-xs font-bold uppercase tracking-wider">
              Masuk ke Akun
            </a>
            <a href="<?= base_url('register') ?>" class="block w-full py-2.5 text-center rounded-xl bg-blue-600 text-white text-xs font-bold uppercase tracking-wider">
              Daftar Akun Baru
            </a>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </header>

  <!-- 3. Dynamic Page Content -->
  <main>
    <?= $this->renderSection('content') ?>
  </main>

  <!-- 4. Footer -->
  <footer class="bg-slate-950 border-t border-slate-800/80 pt-16 pb-12 relative overflow-hidden text-slate-400 text-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800/80">
        
        <!-- Col 1: Brand Info -->
        <div class="lg:col-span-4 space-y-4">
          <div class="flex items-center space-x-3">
            <div class="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            </div>
            <span class="text-lg font-black text-white font-display uppercase">Sentosa Jaya <span class="text-blue-500">Las</span></span>
          </div>
          <p class="text-xs text-slate-400 leading-relaxed max-w-sm">
            Bengkel las & spesialis fabrikasi logam presisi di Bekasi. Melayani pembuatan pagar, kanopi, railing, tangga, pintu besi, konstruksi WF & custom project bergaransi.
          </p>
          <div class="pt-2 text-xs text-slate-500 space-y-1">
            <p>Workshop: Jl.Kubang, Kp.Lubang buaya,Ds.Cijengkol,Rt03/Rw09,Kec.Setu,Kab.Bekasi 17320</p>
            <p>Operasional: Senin - Sabtu (08.00 - 21.00 WIB)</p>
          </div>
        </div>

        <!-- Col 2: Navigasi Cepat -->
        <div class="lg:col-span-2 space-y-3">
          <h4 class="text-xs font-bold text-white uppercase tracking-wider">Navigasi</h4>
          <ul class="space-y-2 text-xs">
            <li><a href="#beranda" class="hover:text-blue-400 transition-colors">Beranda</a></li>
            <li><a href="#tentang-kami" class="hover:text-blue-400 transition-colors">Tentang Kami</a></li>
            <li><a href="#layanan" class="hover:text-blue-400 transition-colors">Layanan Fabrikasi</a></li>
            <li><a href="#proyek" class="hover:text-blue-400 transition-colors">Portfolio Proyek</a></li>
            <li><a href="#proses-kerja" class="hover:text-blue-400 transition-colors">Proses Kerja</a></li>
            <li><a href="#faq" class="hover:text-blue-400 transition-colors">FAQ</a></li>
          </ul>
        </div>

        <!-- Col 3: Layanan Utama -->
        <div class="lg:col-span-3 space-y-3">
          <h4 class="text-xs font-bold text-white uppercase tracking-wider">Layanan Utama</h4>
          <ul class="space-y-2 text-xs">
            <li><a href="#layanan" class="hover:text-blue-400 transition-colors">Pagar Besi & Laser Cutting</a></li>
            <li><a href="#layanan" class="hover:text-blue-400 transition-colors">Kanopi Alderon & Kaca Tempered</a></li>
            <li><a href="#layanan" class="hover:text-blue-400 transition-colors">Railing Tangga & Balkon</a></li>
            <li><a href="#layanan" class="hover:text-blue-400 transition-colors">Tangga Putar & Rebah Besi</a></li>
            <li><a href="#layanan" class="hover:text-blue-400 transition-colors">Pintu Besi & Garasi Henderson</a></li>
            <li><a href="#layanan" class="hover:text-blue-400 transition-colors">Konstruksi Baja WF & Mezzanine</a></li>
          </ul>
        </div>

        <!-- Col 4: Area Layanan -->
        <div class="lg:col-span-3 space-y-3">
          <h4 class="text-xs font-bold text-white uppercase tracking-wider">Wilayah Jangkauan</h4>
          <p class="text-xs text-slate-400 leading-relaxed">
            Melayani survey dan pemasangan di Setu, Tambun, Cibitung, Cikarang, Bekasi Kota, dan seluruh area Jabodetabek.
          </p>
          <div class="pt-2">
            <span class="inline-block px-3 py-1 rounded-full text-[11px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
              100% Material SNI Bergaransi
            </span>
          </div>
        </div>

      </div>

      <!-- Copyright Bottom Bar -->
      <div class="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 space-y-3 sm:space-y-0">
        <p>&copy; <?= date('Y') ?> Sentosa Jaya Las. All rights reserved.</p>
        <p class="flex items-center space-x-1">
          <span>Precision Steel Fabrication & Metal Works</span>
        </p>
      </div>
    </div>
  </footer>

  <!-- 5. Floating WhatsApp Button (Only WA button on page per requirements) -->
  <a 
  href="https://wa.me/<?= esc($whatsappPhone) ?>?text=<?= rawurlencode($whatsappMessage) ?>" 
  id="floating-wa-btn" 
  class="wa-float-btn"
  aria-label="Hubungi Kami via WhatsApp"
  target="_blank"
  rel="noopener noreferrer"
>
  <span class="wa-pulse-ring"></span>
  <span class="wa-tooltip">Hubungi Kami</span>
  <svg class="w-7 h-7 fill-current" viewBox="0 0 24 24">
    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
  </svg>
</a>

  <!-- 6. Back To Top Button -->
  <button 
    id="back-to-top" 
    type="button" 
    class="w-11 h-11 rounded-xl bg-slate-900/90 border border-slate-700 hover:border-blue-500 text-slate-300 hover:text-white flex items-center justify-center backdrop-blur-md shadow-xl transition-all"
    aria-label="Kembali Ke Atas"
  >
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 10l7-7m0 0l7 7m-7-7v18"/></svg>
  </button>

  <!-- 7. Lightbox Modal -->
  <div 
    id="lightbox-modal" 
    class="fixed inset-0 z-50 opacity-0 invisible pointer-events-none flex items-center justify-center p-4 sm:p-6"
    role="dialog"
    aria-modal="true"
  >
    <div class="lightbox-backdrop absolute inset-0 bg-slate-950/90 backdrop-blur-md"></div>
    
    <div class="lightbox-content relative z-10 max-w-4xl w-full bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
      <!-- Close Button -->
      <button 
        id="lightbox-close" 
        type="button" 
        class="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-slate-950/80 hover:bg-slate-800 text-white flex items-center justify-center backdrop-blur-md border border-slate-700 transition-colors"
        aria-label="Tutup Pratinjau"
      >
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </button>

      <!-- Nav Arrows -->
      <button 
        id="lightbox-prev" 
        type="button" 
        class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-slate-950/80 hover:bg-blue-600 text-white flex items-center justify-center backdrop-blur-md border border-slate-700 transition-colors"
        aria-label="Foto Sebelumnya"
      >
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
      </button>

      <button 
        id="lightbox-next" 
        type="button" 
        class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-slate-950/80 hover:bg-blue-600 text-white flex items-center justify-center backdrop-blur-md border border-slate-700 transition-colors"
        aria-label="Foto Berikutnya"
      >
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
      </button>

      <!-- Image Area -->
      <div class="max-h-[65vh] sm:max-h-[75vh] overflow-hidden bg-black flex items-center justify-center">
        <img 
          id="lightbox-image" 
          src="" 
          alt="Pratinjau Proyek" 
          class="w-full h-auto max-h-[70vh] object-contain"
        />
      </div>

      <!-- Caption Area -->
      <div class="p-6 bg-slate-900 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span id="lightbox-category" class="inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30 mb-1">
            Kategori
          </span>
          <h4 id="lightbox-title" class="text-base font-bold text-white">Judul Proyek</h4>
        </div>
        <a 
          href="#kontak" 
          onclick="document.getElementById('lightbox-modal').classList.remove('active'); document.body.style.overflow='';"
          class="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider self-start sm:self-auto transition-all"
        >
          Pesan Model Serupa
        </a>
      </div>
    </div>
  </div>

  <!-- 8. Global Configuration & Vanilla JavaScript File -->
  <script>
    window.BASE_URL = "<?= rtrim(base_url(), '/') ?>";
    window.WHATSAPP_CONFIG = {
      phone: <?= json_encode($whatsappPhone) ?>,
      defaultMessage: <?= json_encode($whatsappMessage) ?>
    };
  </script>
  <script src="<?= base_url('assets/js/main.js') ?>?v=<?= time() ?>"></script>
</body>
</html>

