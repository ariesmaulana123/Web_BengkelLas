<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<div class="max-w-3xl mx-auto space-y-6">

  <!-- Header -->
  <div class="pb-4 border-b border-slate-800">
    <h2 class="text-xl font-bold text-white font-display">Pengaturan Profil Pengguna</h2>
    <p class="text-xs text-slate-400">Perbarui identitas akun dan ubah kata sandi login Anda.</p>
  </div>

  <form method="POST" action="<?= base_url('admin/profil/update') ?>" class="space-y-6">
    <?= csrf_field() ?>

    <div class="p-6 rounded-2xl glass-card space-y-4">
      <h3 class="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center space-x-2">
        <span class="w-2 h-2 rounded-full bg-blue-400"></span>
        <span>Informasi Akun</span>
      </h3>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Nama Lengkap <span class="text-rose-400">*</span></label>
          <input type="text" name="nama" value="<?= esc($user['nama']) ?>" required class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Nomor WhatsApp Aktif <span class="text-rose-400">*</span></label>
          <input type="text" name="no_wa" value="<?= esc($user['no_wa']) ?>" required class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-blue-500">
        </div>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Alamat Email (Login)</label>
          <input type="email" value="<?= esc($user['email']) ?>" disabled class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 text-xs font-mono cursor-not-allowed">
          <span class="text-[10px] text-slate-500 mt-1 block">Email tidak dapat diubah sendiri. Hubungi Administrator Utama.</span>
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Role / Hak Akses</label>
          <input type="text" value="<?= esc(strtoupper($user['role'])) ?>" disabled class="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 text-xs font-mono uppercase cursor-not-allowed">
        </div>
      </div>
    </div>

    <!-- Ganti Password -->
    <div class="p-6 rounded-2xl glass-card space-y-4">
      <h3 class="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center space-x-2">
        <span class="w-2 h-2 rounded-full bg-amber-400"></span>
        <span>Keamanan Kata Sandi</span>
      </h3>
      <p class="text-xs text-slate-400">Biarkan kolom di bawah ini kosong jika Anda tidak ingin mengubah password akun Anda.</p>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Password Lama</label>
        <input type="password" name="old_password" placeholder="Masukkan password lama..." class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Password Baru</label>
          <input type="password" name="new_password" minlength="6" placeholder="Minimal 6 karakter..." class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Ulangi Password Baru</label>
          <input type="password" name="confirm_password" minlength="6" placeholder="Konfirmasi password baru..." class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
        </div>
      </div>
    </div>

    <div class="flex justify-end">
      <button type="submit" class="px-8 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-blue-600/30 hover:-translate-y-0.5 transition-all">
        Simpan Perubahan Profil
      </button>
    </div>

  </form>

</div>

<?= $this->endSection() ?>