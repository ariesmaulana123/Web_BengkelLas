<?php
$userName = session()->get('nama') ?? 'Administrator';
$userEmail = session()->get('email') ?? 'admin@sentosajayalas.com';
$userRole = session()->get('role') ?? 'admin';
$isAdmin = ($userRole === 'admin');
?>
<!-- Top Navigation Bar -->
<header class="h-20 bg-slate-900/80 border-b border-slate-800/80 backdrop-blur-xl sticky top-0 z-30 px-4 sm:px-8 flex items-center justify-between">
  
  <!-- Left: Sidebar Toggle & Page Title -->
  <div class="flex items-center space-x-4">
    <!-- Hamburger Button for Mobile -->
    <button type="button" onclick="toggleSidebar()" class="lg:hidden p-2.5 rounded-xl bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors border border-slate-700">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
      </svg>
    </button>

    <div>
      <h1 class="text-base sm:text-xl font-bold text-white font-display tracking-tight flex items-center space-x-2">
        <span><?= esc($pageTitle ?? 'Dashboard') ?></span>
      </h1>
      <p class="text-xs text-slate-400 hidden sm:block"><?= esc($pageSubtitle ?? 'Sentosa Jaya Las Workshop Management') ?></p>
    </div>
  </div>

  <!-- Right: Quick Actions & Profile Dropdown -->
  <div class="flex items-center space-x-3 sm:space-x-5">

    <!-- View Public Website -->
    <a href="<?= base_url() ?>" target="_blank" class="hidden sm:inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-slate-800/70 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700/80 transition-all hover:border-slate-600">
      <svg class="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
      </svg>
      <span>Lihat Website</span>
    </a>

    <!-- Notification Indicator / Live Server Status -->
    <div class="hidden md:flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono">
      <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
      <span class="font-medium">Sistem Aktif</span>
    </div>

    <!-- User Profile Dropdown -->
    <div class="relative" id="user-menu-container">
      <button 
        type="button" 
        id="user-menu-button" 
        onclick="toggleUserDropdown()"
        class="flex items-center space-x-3 p-1.5 sm:px-3 sm:py-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-slate-600 transition-all focus:outline-none focus:ring-2 focus:ring-blue-500/40"
      >
        <div class="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 to-sky-400 text-white font-bold flex items-center justify-center text-sm shadow-md">
          <?= esc(strtoupper(substr($userName, 0, 1))) ?>
        </div>
        <div class="text-left hidden md:block">
          <p class="text-xs font-bold text-white leading-tight truncate max-w-[120px]"><?= esc($userName) ?></p>
          <p class="text-[10px] text-slate-400 font-mono uppercase tracking-wider"><?= esc($userRole) ?></p>
        </div>
        <svg class="w-4 h-4 text-slate-400 hidden md:block" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
        </svg>
      </button>

      <!-- Dropdown Menu -->
      <div 
        id="user-dropdown-menu" 
        class="hidden absolute right-0 mt-2 w-64 rounded-2xl glass-dropdown shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150"
      >
        <!-- Header Info -->
        <div class="px-3.5 py-3 border-b border-slate-800/80">
          <p class="text-xs font-bold text-white truncate"><?= esc($userName) ?></p>
          <p class="text-xs text-slate-400 truncate font-mono"><?= esc($userEmail) ?></p>
          <div class="mt-2">
            <span class="inline-block px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider font-semibold <?= $isAdmin ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30' ?>">
              Hak Akses: <?= esc($userRole) ?>
            </span>
          </div>
        </div>

        <!-- Links -->
        <div class="py-1.5 space-y-0.5">
          <a href="<?= base_url('admin/profil') ?>" class="flex items-center space-x-3 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800/80 hover:text-white transition-colors">
            <svg class="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
            </svg>
            <span>Profil Saya</span>
          </a>

          <?php if ($isAdmin): ?>
          <a href="<?= base_url('admin/users') ?>" class="flex items-center space-x-3 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800/80 hover:text-white transition-colors">
            <svg class="w-4 h-4 text-sky-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
            </svg>
            <span>Role & Hak Akses</span>
          </a>

          <a href="<?= base_url('admin/pengaturan') ?>" class="flex items-center space-x-3 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800/80 hover:text-white transition-colors">
            <svg class="w-4 h-4 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            <span>Pengaturan</span>
          </a>
          <?php endif; ?>
        </div>

        <!-- Logout -->
        <div class="pt-1.5 border-t border-slate-800/80">
          <a href="<?= base_url('logout') ?>" class="flex items-center space-x-3 px-3 py-2 rounded-xl text-xs font-semibold text-rose-400 hover:bg-rose-500/10 transition-colors">
            <svg class="w-4 h-4 text-rose-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
            </svg>
            <span>Keluar (Logout)</span>
          </a>
        </div>

      </div>
    </div>

  </div>

</header>