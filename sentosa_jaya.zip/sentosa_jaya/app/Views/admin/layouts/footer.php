<!-- Footer -->
  <footer class="mt-auto py-6 px-8 border-t border-slate-900 bg-slate-950/60 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-3">
    <p>&copy; <?= date('Y') ?> <strong class="text-slate-300">Sentosa Jaya Las</strong>. Seluruh Hak Cipta Dilindungi.</p>
    <div class="flex items-center space-x-4 font-mono text-[11px]">
      <span class="text-blue-400/80">Sistem ERP & Kalkulator v2.5</span>
      <span class="text-slate-700">|</span>
      <span>Status: <span class="text-emerald-400 font-semibold">Produksi</span></span>
    </div>
  </footer>

  <!-- Admin Interactive Scripts -->
  <script>
    // 1. Sidebar Toggle (Mobile)
    function toggleSidebar() {
      const sidebar = document.getElementById('admin-sidebar');
      const overlay = document.getElementById('sidebar-overlay');
      if (sidebar && overlay) {
        sidebar.classList.toggle('-translate-x-full');
        overlay.classList.toggle('hidden');
      }
    }

    // 2. User Profile Dropdown Toggle
    function toggleUserDropdown() {
      const menu = document.getElementById('user-dropdown-menu');
      if (menu) {
        menu.classList.toggle('hidden');
      }
    }

    // Close Dropdown when clicking outside
    document.addEventListener('click', function(event) {
      const container = document.getElementById('user-menu-container');
      const menu = document.getElementById('user-dropdown-menu');
      if (container && menu && !container.contains(event.target)) {
        menu.classList.add('hidden');
      }
    });

    // 3. SweetAlert2 Flash Notifications
    <?php if (session()->getFlashdata('success')): ?>
      Swal.fire({
        icon: 'success',
        title: 'Berhasil!',
        text: '<?= addslashes(session()->getFlashdata('success')) ?>',
        background: '#0f172a',
        color: '#f8fafc',
        confirmButtonColor: '#2563eb',
        timer: 3500
      });
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
      Swal.fire({
        icon: 'error',
        title: 'Terjadi Kesalahan',
        text: '<?= addslashes(session()->getFlashdata('error')) ?>',
        background: '#0f172a',
        color: '#f8fafc',
        confirmButtonColor: '#ef4444'
      });
    <?php endif; ?>

    <?php if (session()->getFlashdata('warning')): ?>
      Swal.fire({
        icon: 'warning',
        title: 'Perhatian',
        text: '<?= addslashes(session()->getFlashdata('warning')) ?>',
        background: '#0f172a',
        color: '#f8fafc',
        confirmButtonColor: '#f59e0b'
      });
    <?php endif; ?>

    // Global Confirm Action Helper
    function confirmAction(url, message = 'Apakah Anda yakin ingin melanjutkan tindakan ini?') {
      Swal.fire({
        title: 'Konfirmasi Tindakan',
        text: message,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#2563eb',
        cancelButtonColor: '#64748b',
        confirmButtonText: 'Ya, Lanjutkan',
        cancelButtonText: 'Batal',
        background: '#0f172a',
        color: '#f8fafc'
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.href = url;
        }
      });
    }
  </script>
</body>
</html>