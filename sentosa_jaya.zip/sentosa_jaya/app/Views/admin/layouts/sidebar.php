<?php
$currentUri = uri_string();
$role = session()->get('role') ?? 'admin';
$isAdmin = ($role === 'admin');
?>
<!-- Sidebar Overlay for Mobile -->
<div id="sidebar-overlay" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden hidden transition-opacity" onclick="toggleSidebar()"></div>

<!-- Sidebar Container -->
<aside id="admin-sidebar" class="fixed inset-y-0 left-0 z-50 w-72 bg-slate-900/95 border-r border-slate-800/80 backdrop-blur-xl flex flex-col transition-transform duration-300 -translate-x-full lg:translate-x-0">
  
  <!-- Brand Logo -->
  <div class="h-20 px-6 flex items-center justify-between border-b border-slate-800/80">
    <a href="<?= base_url('admin/dashboard') ?>" class="flex items-center space-x-3 group">
      <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-blue-600/30 group-hover:scale-105 transition-transform font-display">
        SJ
      </div>
      <div>
        <span class="block text-sm font-bold text-white font-display tracking-tight group-hover:text-blue-400 transition-colors">
          SENTOSA JAYA
        </span>
        <span class="inline-flex items-center space-x-1.5 text-[10px] font-mono text-blue-400 uppercase tracking-wider font-semibold">
          <span class="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
          <span>Admin Portal</span>
        </span>
      </div>
    </a>

    <!-- Mobile Close Button -->
    <button type="button" onclick="toggleSidebar()" class="lg:hidden text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800">
      <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
      </svg>
    </button>
  </div>

  <!-- Navigation Menu -->
  <div class="flex-1 px-4 py-6 overflow-y-auto space-y-6">

    <!-- Section: Utama -->
    <div>
      <p class="px-3 text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">Utama</p>
      <ul class="space-y-1">
        <li>
          <a href="<?= base_url('admin/dashboard') ?>" class="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all <?= str_contains($currentUri, 'admin/dashboard') ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'text-slate-300 hover:bg-slate-800/70 hover:text-white' ?>">
            <svg class="w-5 h-5 <?= str_contains($currentUri, 'admin/dashboard') ? 'text-white' : 'text-slate-400' ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
            </svg>
            <span>Dashboard</span>
          </a>
        </li>
      </ul>
    </div>

    <!-- Section: SCM (Supply Chain Management) - Admin Only -->
    <?php if ($isAdmin): ?>
    <div>
      <p class="px-3 text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">SCM (Material & Harga)</p>
      <ul class="space-y-1">
        <li>
          <a href="<?= base_url('admin/scm/jenis-pekerjaan') ?>" class="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all <?= str_contains($currentUri, 'admin/scm/jenis-pekerjaan') ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'text-slate-300 hover:bg-slate-800/70 hover:text-white' ?>">
            <svg class="w-5 h-5 <?= str_contains($currentUri, 'admin/scm/jenis-pekerjaan') ? 'text-white' : 'text-slate-400' ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
            </svg>
            <span>Jenis Pekerjaan</span>
          </a>
        </li>
        <li>
          <a href="<?= base_url('admin/scm/material') ?>" class="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all <?= str_contains($currentUri, 'admin/scm/material') ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'text-slate-300 hover:bg-slate-800/70 hover:text-white' ?>">
            <svg class="w-5 h-5 <?= str_contains($currentUri, 'admin/scm/material') ? 'text-white' : 'text-slate-400' ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
            </svg>
            <span>Material</span>
          </a>
        </li>
        <li>
          <a href="<?= base_url('admin/scm/harga') ?>" class="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all <?= str_contains($currentUri, 'admin/scm/harga') ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'text-slate-300 hover:bg-slate-800/70 hover:text-white' ?>">
            <svg class="w-5 h-5 <?= str_contains($currentUri, 'admin/scm/harga') ? 'text-white' : 'text-slate-400' ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <span>Harga Bahan</span>
          </a>
        </li>
      </ul>
    </div>
    <?php endif; ?>

    <!-- Section: CRM (Customer Relationship Management) -->
    <div>
      <p class="px-3 text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">CRM & Operasional</p>
      <ul class="space-y-1">
        <?php if ($isAdmin): ?>
        <li>
          <a href="<?= base_url('admin/crm/estimasi') ?>" class="flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all <?= str_contains($currentUri, 'admin/crm/estimasi') ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'text-slate-300 hover:bg-slate-800/70 hover:text-white' ?>">
            <div class="flex items-center space-x-3">
              <svg class="w-5 h-5 <?= str_contains($currentUri, 'admin/crm/estimasi') ? 'text-white' : 'text-slate-400' ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
              <span>Catatan Pekerjaan</span>
            </div>
            <?php if (!empty($badgeEstimasiBaru) && $badgeEstimasiBaru > 0): ?>
              <span class="px-2 py-0.5 text-[10px] font-bold rounded-full bg-amber-500 text-slate-950 font-mono">
                <?= $badgeEstimasiBaru ?>
              </span>
            <?php endif; ?>
          </a>
        </li>
        <li>
          <a href="<?= base_url('admin/crm/customer') ?>" class="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all <?= str_contains($currentUri, 'admin/crm/customer') ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'text-slate-300 hover:bg-slate-800/70 hover:text-white' ?>">
            <svg class="w-5 h-5 <?= str_contains($currentUri, 'admin/crm/customer') ? 'text-white' : 'text-slate-400' ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
            </svg>
            <span>Customer</span>
          </a>
        </li>
        <?php endif; ?>

        <li>
          <a href="<?= base_url('admin/crm/proyek?mark_read=1') ?>" class="flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all <?= str_contains($currentUri, 'admin/crm/proyek') ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'text-slate-300 hover:bg-slate-800/70 hover:text-white' ?>">
            <div class="flex items-center space-x-3">
              <svg class="w-5 h-5 <?= str_contains($currentUri, 'admin/crm/proyek') ? 'text-white' : 'text-slate-400' ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
              </svg>
              <span><?= $isAdmin ? 'Proyek' : 'Proyek Saya' ?></span>
            </div>
            <?php $projectNotificationCount = $isAdmin ? ($badgeProyekAdmin ?? 0) : ($badgeProyekTukang ?? 0); ?>
            <?php if ($projectNotificationCount > 0): ?>
              <span class="px-2 py-0.5 text-[10px] font-bold rounded-full <?= $isAdmin ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/40' : 'bg-blue-500/30 text-blue-300 border border-blue-500/40' ?> font-mono" title="<?= $isAdmin ? 'Proyek deal baru' : 'Proyek baru yang ditugaskan' ?>">
                <?= $projectNotificationCount ?>
              </span>
            <?php endif; ?>
          </a>
        </li>

        <li>
          <a href="<?= base_url('admin/crm/kasbon') ?>" class="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all <?= str_contains($currentUri, 'admin/crm/kasbon') ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/25' : 'text-slate-300 hover:bg-slate-800/70 hover:text-white' ?>">
            <svg class="w-5 h-5 <?= str_contains($currentUri, 'admin/crm/kasbon') ? 'text-white' : 'text-amber-400' ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <span><?= $isAdmin ? 'Kasbon Tukang' : 'Riwayat Kasbon' ?></span>
          </a>
        </li>

        <?php if ($isAdmin): ?>
        <li>
          <a href="<?= base_url('admin/crm/follow-up') ?>" class="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all <?= str_contains($currentUri, 'admin/crm/follow-up') ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'text-slate-300 hover:bg-slate-800/70 hover:text-white' ?>">
            <svg class="w-5 h-5 <?= str_contains($currentUri, 'admin/crm/follow-up') ? 'text-white' : 'text-slate-400' ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
            </svg>
            <span>Follow Up</span>
          </a>
        </li>
        <?php endif; ?>
      </ul>
    </div>

    <!-- Section: Analisis & Laporan - Admin Only -->
    <?php if ($isAdmin): ?>
    <div>
      <p class="px-3 text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">Laporan</p>
      <ul class="space-y-1">
        <li>
          <a href="<?= base_url('admin/laporan') ?>" class="flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all <?= str_contains($currentUri, 'admin/laporan') ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'text-slate-300 hover:bg-slate-800/70 hover:text-white' ?>">
            <svg class="w-5 h-5 <?= str_contains($currentUri, 'admin/laporan') ? 'text-white' : 'text-slate-400' ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
            </svg>
            <span>Laporan</span>
          </a>
        </li>
      </ul>
    </div>
    <?php endif; ?>

  </div>

  <!-- Bottom User Session Badge -->
  <div class="p-4 border-t border-slate-800/80 bg-slate-950/40">
    <div class="flex items-center space-x-3">
      <div class="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/30 text-blue-400 flex items-center justify-center font-bold text-sm font-display">
        <?= esc(strtoupper(substr(session()->get('nama') ?? 'A', 0, 1))) ?>
      </div>
      <div class="overflow-hidden flex-1">
        <p class="text-xs font-bold text-white truncate"><?= esc(session()->get('nama') ?? 'User') ?></p>
        <span class="inline-block px-1.5 py-0.2 rounded text-[10px] font-mono uppercase tracking-wider font-semibold <?= $isAdmin ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20' ?>">
          <?= esc($role) ?>
        </span>
      </div>
    </div>
  </div>

</aside>