<?= $this->include('admin/layouts/header') ?>

<div class="flex min-h-screen">
  <!-- Sidebar -->
  <?= $this->include('admin/layouts/sidebar') ?>

  <!-- Main Content Wrapper -->
  <div class="flex-1 flex flex-col min-w-0 lg:pl-72">
    <!-- Navbar -->
    <?= $this->include('admin/layouts/navbar') ?>

    <!-- Main Page Content -->
    <main class="flex-1 p-4 sm:p-8 bg-slate-950">
      <div class="max-w-7xl mx-auto space-y-8">
        <?= $this->renderSection('content') ?>
      </div>
    </main>

    <!-- Footer -->
    <?= $this->include('admin/layouts/footer') ?>
  </div>
</div>