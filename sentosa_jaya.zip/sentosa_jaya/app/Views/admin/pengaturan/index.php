<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<div class="max-w-4xl mx-auto space-y-6">

  <!-- Header -->
  <div class="pb-4 border-b border-slate-800">
    <h2 class="text-xl font-bold text-white font-display">Pengaturan Identitas Perusahaan</h2>
    <p class="text-xs text-slate-400">Data ini digunakan secara dinamis pada Surat Penawaran PDF, footer, dan pesan WhatsApp.</p>
  </div>

  <form method="POST" action="<?= base_url('admin/pengaturan/update') ?>" class="space-y-6">
    <?= csrf_field() ?>

    <!-- Section 1: Profil Dasar Perusahaan -->
    <div class="p-6 rounded-2xl glass-card space-y-4">
      <h3 class="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center space-x-2">
        <span class="w-2 h-2 rounded-full bg-blue-400"></span>
        <span>1. Identitas Usaha / Workshop</span>
      </h3>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Nama Perusahaan / Workshop <span class="text-rose-400">*</span></label>
          <input type="text" name="nama_perusahaan" value="<?= esc($settings['nama_perusahaan']) ?>" required class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Tagline Slogan</label>
          <input type="text" name="tagline" value="<?= esc($settings['tagline'] ?? '') ?>" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
        </div>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Alamat Lengkap Workshop <span class="text-rose-400">*</span></label>
        <textarea name="alamat" rows="2" required class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500 resize-none"><?= esc($settings['alamat']) ?></textarea>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">No. WhatsApp Resmi <span class="text-rose-400">*</span></label>
          <input type="text" name="no_wa" value="<?= esc($settings['no_wa']) ?>" required class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-blue-500">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Email Bisnis <span class="text-rose-400">*</span></label>
          <input type="email" name="email" value="<?= esc($settings['email']) ?>" required class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-blue-500">
        </div>
      </div>
    </div>

    <!-- Section 2: Rekening Bank Pembayaran -->
    <div class="p-6 rounded-2xl glass-card space-y-4">
      <h3 class="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center space-x-2">
        <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
        <span>2. Rekening Bank Transfer Pembayaran</span>
      </h3>

      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Nama Bank</label>
          <input type="text" name="nama_bank" value="<?= esc($settings['nama_bank'] ?? 'BCA') ?>" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Nomor Rekening</label>
          <input type="text" name="no_rekening" value="<?= esc($settings['no_rekening'] ?? '') ?>" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-blue-500">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Atas Nama Rekening</label>
          <input type="text" name="atas_nama_bank" value="<?= esc($settings['atas_nama_bank'] ?? '') ?>" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
        </div>
      </div>
    </div>

    <!-- Section 3: Penanggung Jawab & Ketentuan Penawaran PDF -->
    <div class="p-6 rounded-2xl glass-card space-y-4">
      <h3 class="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center space-x-2">
        <span class="w-2 h-2 rounded-full bg-purple-400"></span>
        <span>3. Format Penawaran PDF & Penanggung Jawab</span>
      </h3>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Nama Penanggung Jawab TTD</label>
          <input type="text" name="nama_penanggung_jawab" value="<?= esc($settings['nama_penanggung_jawab'] ?? 'Bambang Sentosa') ?>" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Jabatan Penanggung Jawab</label>
          <input type="text" name="jabatan_penanggung_jawab" value="<?= esc($settings['jabatan_penanggung_jawab'] ?? 'Kepala Workshop') ?>" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
        </div>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Syarat & Ketentuan Penawaran (Tampil di Dokumen PDF)</label>
        <textarea name="catatan_penawaran" rows="4" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500 resize-none"><?= esc($settings['catatan_penawaran'] ?? '') ?></textarea>
      </div>
    </div>

    <div class="flex justify-end">
      <button type="submit" class="px-8 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-blue-600/30 hover:-translate-y-0.5 transition-all">
        Simpan Seluruh Pengaturan
      </button>
    </div>

  </form>

</div>

<?= $this->endSection() ?>