<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<!-- Header -->
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
  <div>
    <nav class="flex items-center space-x-2 text-xs text-slate-400 mb-1">
      <a href="<?= base_url('admin/crm/customer') ?>" class="hover:text-white transition-colors">CRM Customer</a>
      <span>/</span>
      <span class="text-blue-400 font-semibold"><?= esc($customer['nama']) ?></span>
    </nav>
    <h2 class="text-xl sm:text-2xl font-bold text-white font-display">
      Profil & Riwayat Pelanggan
    </h2>
  </div>

  <a 
    href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $customer['no_wa']) ?>" 
    target="_blank"
    class="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-emerald-600/30 transition-all"
  >
    <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24">
      <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
    </svg>
    <span>Hubungi via WhatsApp</span>
  </a>
</div>

<!-- Profile Info Card -->
<div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
  <div class="p-5 rounded-2xl glass-card flex items-center space-x-4">
    <div class="w-12 h-12 rounded-xl bg-blue-600/20 text-blue-400 font-bold text-xl flex items-center justify-center font-display">
      <?= esc(strtoupper(substr($customer['nama'], 0, 1))) ?>
    </div>
    <div class="overflow-hidden">
      <p class="text-[10px] font-mono text-slate-400 uppercase">Nama Lengkap</p>
      <h3 class="text-sm font-bold text-white truncate"><?= esc($customer['nama']) ?></h3>
      <p class="text-xs text-slate-400 font-mono"><?= esc($customer['email']) ?></p>
    </div>
  </div>

  <div class="p-5 rounded-2xl glass-card">
    <p class="text-[10px] font-mono text-slate-400 uppercase">Nomor WhatsApp Aktif</p>
    <p class="text-base font-bold text-emerald-400 font-mono mt-1"><?= esc($customer['no_wa']) ?></p>
    <p class="text-[11px] text-slate-400 mt-1">Terdaftar: <?= date('d F Y', strtotime($customer['created_at'])) ?></p>
  </div>

  <div class="p-5 rounded-2xl glass-card">
    <p class="text-[10px] font-mono text-slate-400 uppercase">Aktivitas di Sentosa Jaya</p>
    <p class="text-sm font-bold text-white mt-1">
      <span class="text-blue-400 font-mono"><?= count($estimasiList) ?></span> Estimasi • 
      <span class="text-emerald-400 font-mono"><?= count($proyekList) ?></span> Proyek Deal
    </p>
  </div>
</div>

<!-- Riwayat Proyek Deal -->
<div class="space-y-3">
  <h3 class="text-base font-bold text-white font-display">Proyek Berjalan & Selesai</h3>
  <div class="rounded-2xl glass-card overflow-hidden">
    <table class="w-full text-left text-xs text-slate-300">
      <thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
        <tr>
          <th class="py-3 px-4">Kode Proyek</th>
          <th class="py-3 px-4">Nama Proyek</th>
          <th class="py-3 px-4">Nilai Kontrak</th>
          <th class="py-3 px-4">DP</th>
          <th class="py-3 px-4">Sisa Bayar</th>
          <th class="py-3 px-4">Progress</th>
          <th class="py-3 px-4">Status</th>
          <th class="py-3 px-4 text-right">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-800/60">
        <?php if (empty($proyekList)): ?>
          <tr><td colspan="8" class="py-6 text-center text-slate-400 italic">Customer ini belum memiliki proyek kontrak deal.</td></tr>
        <?php else: ?>
          <?php foreach ($proyekList as $p): ?>
            <tr class="hover:bg-slate-800/30">
              <td class="py-3 px-4 font-mono font-bold text-blue-400"><?= esc($p['kode_proyek']) ?></td>
              <td class="py-3 px-4 font-bold text-white"><?= esc($p['nama_proyek']) ?></td>
              <td class="py-3 px-4 font-mono font-bold text-emerald-400">Rp <?= number_format($p['nilai_proyek'], 0, ',', '.') ?></td>
              <td class="py-3 px-4 font-mono text-slate-300">Rp <?= number_format($p['dp'], 0, ',', '.') ?></td>
              <td class="py-3 px-4 font-mono text-amber-400">Rp <?= number_format($p['sisa_pembayaran'], 0, ',', '.') ?></td>
              <td class="py-3 px-4 font-mono font-bold text-white"><?= $p['progress'] ?>%</td>
              <td class="py-3 px-4 uppercase font-mono text-[10px] text-blue-300"><?= esc($p['status']) ?></td>
              <td class="py-3 px-4 text-right">
                <a href="<?= base_url('admin/crm/proyek/detail/' . $p['id_proyek']) ?>" class="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold">Kelola</a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Riwayat Seluruh Estimasi -->
<div class="space-y-3">
  <h3 class="text-base font-bold text-white font-display">Riwayat Seluruh Perhitungan Estimasi</h3>
  <div class="rounded-2xl glass-card overflow-hidden">
    <table class="w-full text-left text-xs text-slate-300">
      <thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
        <tr>
          <th class="py-3 px-4">No. Estimasi</th>
          <th class="py-3 px-4">Pekerjaan</th>
          <th class="py-3 px-4">Dimensi</th>
          <th class="py-3 px-4">Subtotal Sistem</th>
          <th class="py-3 px-4">Total Final</th>
          <th class="py-3 px-4">Status</th>
          <th class="py-3 px-4">Tanggal</th>
          <th class="py-3 px-4 text-right">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-800/60">
        <?php if (empty($estimasiList)): ?>
          <tr><td colspan="8" class="py-6 text-center text-slate-400 italic">Belum ada estimasi yang dihitung.</td></tr>
        <?php else: ?>
          <?php foreach ($estimasiList as $e): ?>
            <tr class="hover:bg-slate-800/30">
              <td class="py-3 px-4 font-mono font-bold text-blue-400">#EST-<?= str_pad((string)$e['id_estimasi'], 5, '0', STR_PAD_LEFT) ?></td>
              <td class="py-3 px-4 font-semibold text-white"><?= esc($e['nama_jp']) ?></td>
              <td class="py-3 px-4 font-mono text-slate-300"><?= $e['panjang'] ?>m x <?= $e['lebar'] ?>m (<?= $e['luas'] ?>m²)</td>
              <td class="py-3 px-4 font-mono">Rp <?= number_format($e['subtotal'], 0, ',', '.') ?></td>
              <td class="py-3 px-4 font-mono font-bold text-emerald-400">
                Rp <?= number_format($e['total_final'] ? $e['total_final'] : $e['subtotal'], 0, ',', '.') ?>
              </td>
              <td class="py-3 px-4 uppercase font-mono text-[10px] text-amber-300"><?= esc($e['status']) ?></td>
              <td class="py-3 px-4 font-mono text-slate-400"><?= date('d/m/Y H:i', strtotime($e['created_at'])) ?></td>
              <td class="py-3 px-4 text-right">
                <a href="<?= base_url('admin/crm/estimasi/detail/' . $e['id_estimasi']) ?>" class="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold">Tinjau</a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection() ?>