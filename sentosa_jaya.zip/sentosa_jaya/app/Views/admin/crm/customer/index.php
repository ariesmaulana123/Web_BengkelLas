<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<!-- Header -->
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
  <div>
    <h2 class="text-xl font-bold text-white font-display">Direktori Pelanggan (Customer)</h2>
    <p class="text-xs text-slate-400">Daftar pengguna terdaftar yang membuat akun dan estimasi pada website Sentosa Jaya Las.</p>
  </div>
  <span class="text-xs font-mono text-slate-400">Total: <strong class="text-white"><?= count($customers) ?></strong> Pelanggan</span>
</div>

<!-- Search Bar -->
<div class="p-4 rounded-2xl glass-card">
  <form method="GET" action="<?= base_url('admin/crm/customer') ?>" class="flex items-center gap-3">
    <div class="relative flex-1">
      <svg class="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
      </svg>
      <input 
        type="text" 
        name="q" 
        value="<?= esc($search ?? '') ?>" 
        placeholder="Cari berdasarkan nama customer, nomor whatsapp, atau email..." 
        class="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
      >
    </div>
    <button type="submit" class="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider">
      Cari
    </button>
    <?php if ($search): ?>
      <a href="<?= base_url('admin/crm/customer') ?>" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold">
        Reset
      </a>
    <?php endif; ?>
  </form>
</div>

<!-- Table Card -->
<div class="rounded-2xl glass-card overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-left text-xs text-slate-300">
      <thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
        <tr>
          <th class="py-3.5 px-4">Customer</th>
          <th class="py-3.5 px-4">Kontak WhatsApp</th>
          <th class="py-3.5 px-4">Email</th>
          <th class="py-3.5 px-4 text-center">Total Estimasi</th>
          <th class="py-3.5 px-4 text-center">Total Proyek</th>
          <th class="py-3.5 px-4">Total Nilai Proyek</th>
          <th class="py-3.5 px-4">Terdaftar Sejak</th>
          <th class="py-3.5 px-4 text-right">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-800/60">
        <?php if (empty($customers)): ?>
          <tr>
            <td colspan="8" class="py-8 text-center text-slate-400 italic">Belum ada data customer terdaftar.</td>
          </tr>
        <?php else: ?>
          <?php foreach ($customers as $c): ?>
            <tr class="hover:bg-slate-800/30 transition-colors">
              <td class="py-3.5 px-4">
                <div class="flex items-center space-x-3">
                  <div class="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 font-bold flex items-center justify-center font-display">
                    <?= esc(strtoupper(substr($c['nama'], 0, 1))) ?>
                  </div>
                  <div>
                    <span class="font-bold text-white block"><?= esc($c['nama']) ?></span>
                    <span class="text-[10px] font-mono text-slate-500">ID #<?= $c['id_user'] ?></span>
                  </div>
                </div>
              </td>
              <td class="py-3.5 px-4">
                <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $c['no_wa']) ?>" target="_blank" class="text-emerald-400 hover:underline font-mono flex items-center space-x-1">
                  <span><?= esc($c['no_wa']) ?></span>
                </a>
              </td>
              <td class="py-3.5 px-4 text-slate-300 font-mono"><?= esc($c['email']) ?></td>
              <td class="py-3.5 px-4 text-center font-mono font-bold text-white">
                <?= $c['total_estimasi'] ?>
              </td>
              <td class="py-3.5 px-4 text-center font-mono font-bold text-blue-400">
                <?= $c['total_proyek'] ?>
              </td>
              <td class="py-3.5 px-4 font-mono font-bold text-emerald-400">
                Rp <?= number_format($c['total_nilai_proyek'], 0, ',', '.') ?>
              </td>
              <td class="py-3.5 px-4 font-mono text-[11px] text-slate-400">
                <?= date('d/m/Y', strtotime($c['created_at'])) ?>
              </td>
              <td class="py-3.5 px-4 text-right">
                <a 
                  href="<?= base_url('admin/crm/customer/detail/' . $c['id_user']) ?>" 
                  class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
                >
                  Detail Riwayat
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection() ?>