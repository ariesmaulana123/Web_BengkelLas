<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<?php
$isAdmin = (session()->get('role') === 'admin');
$fotos = !empty($proyek['foto_dokumentasi']) ? json_decode($proyek['foto_dokumentasi'], true) : [];
if (!is_array($fotos)) $fotos = [];
$canKasbon = $isAdmin
  && !empty($proyek['id_tukang'])
  && (float) ($proyek['nilai_tukang'] ?? 0) > 0
  && (float) ($sisaKasbon ?? 0) > 0;
$formatRupiah = static fn ($value) => 'Rp ' . number_format((float) $value, 0, ',', '.');
?>

<!-- Header -->
<div class="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
  <div>
    <nav class="flex items-center space-x-2 text-xs text-slate-400 mb-1">
      <a href="<?= base_url('admin/crm/proyek') ?>" class="hover:text-white transition-colors">Manajemen Proyek</a>
      <span>/</span>
      <span class="text-blue-400 font-mono"><?= esc($proyek['kode_proyek']) ?></span>
    </nav>
    <h2 class="text-xl sm:text-2xl font-bold text-white font-display flex items-center space-x-3">
      <span><?= esc($proyek['nama_proyek']) ?></span>
      <span class="text-xs px-3 py-1 rounded-full font-mono uppercase tracking-wider font-bold bg-blue-500/10 border border-blue-500/20 text-blue-400">
        <?= esc(str_replace('_', ' ', $proyek['status'])) ?>
      </span>
    </h2>
  </div>

  <div class="flex items-center space-x-3">
    <a 
      href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $proyek['no_wa_customer']) ?>" 
      target="_blank"
      class="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-emerald-600/30 transition-all"
    >
      <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24">
        <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
      </svg>
      <span>WhatsApp Customer</span>
    </a>
  </div>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="p-3 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-300 text-sm"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('warning')): ?><div class="p-3 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-300 text-sm"><?= esc(session()->getFlashdata('warning')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="p-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-sm"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<!-- 1. Stats & Overview Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
  <?php if ($isAdmin): ?>
    <!-- Admin Card 1: Total Nilai Kontrak Proyek -->
    <div class="p-5 rounded-2xl glass-card border border-blue-500/20">
      <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Total Nilai Proyek (Deal)</span>
      <p class="text-xl font-bold text-emerald-400 font-mono mt-1">Rp <?= number_format($proyek['nilai_proyek'] ?? 0, 0, ',', '.') ?></p>
      <p class="text-[11px] text-slate-400 mt-1">Estimasi #EST-<?= str_pad((string)($proyek['id_estimasi'] ?? 0), 5, '0', STR_PAD_LEFT) ?></p>
    </div>

    <!-- Admin Card 2: Alokasi Nilai Tukang -->
    <div class="p-5 rounded-2xl glass-card border border-cyan-500/20">
      <span class="text-[10px] font-mono text-cyan-400 uppercase tracking-wider font-semibold">Alokasi Upah Tukang</span>
      <p class="text-xl font-bold text-cyan-300 font-mono mt-1">Rp <?= number_format($proyek['nilai_tukang'] ?? 0, 0, ',', '.') ?></p>
      <p class="text-[11px] text-slate-400 mt-1 truncate" title="<?= esc($proyek['pekerjaan_tukang'] ?? '-') ?>">
        Tugas: <?= !empty($proyek['pekerjaan_tukang']) ? esc($proyek['pekerjaan_tukang']) : 'Belum dirinci' ?>
      </p>
    </div>

    <!-- Admin Card 3: Status Pembayaran Customer -->
    <div class="p-5 rounded-2xl glass-card">
      <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Pembayaran Customer</span>
      <p class="text-sm font-bold text-white font-mono mt-1">
        DP: <span class="text-emerald-400">Rp <?= number_format($proyek['dp'] ?? 0, 0, ',', '.') ?></span>
      </p>
      <p class="text-[11px] text-amber-400 mt-0.5 font-mono">
        Sisa: Rp <?= number_format($proyek['sisa_pembayaran'] ?? 0, 0, ',', '.') ?> (<?= esc(str_replace('_', ' ', $proyek['status_pembayaran'] ?? 'belum_lunas')) ?>)
      </p>
    </div>

    <!-- Admin Card 4: Tukang Ditugaskan & Jadwal -->
    <div class="p-5 rounded-2xl glass-card">
      <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Tukang Ditugaskan</span>
      <p class="text-sm font-bold text-blue-400 mt-1"><?= esc($proyek['nama_tukang'] ?? 'Belum Ditugaskan') ?></p>
      <p class="text-[11px] text-slate-400 font-mono mt-0.5">
        Target: <?= !empty($proyek['tanggal_target_selesai']) ? date('d/m/Y', strtotime($proyek['tanggal_target_selesai'])) : '-' ?>
      </p>
    </div>

  <?php else: ?>
    <!-- Tukang Card 1: Nilai Pekerjaan Anda -->
    <div class="p-5 rounded-2xl glass-card border border-cyan-500/30 bg-slate-900/90">
      <span class="text-[10px] font-mono text-cyan-400 uppercase tracking-wider font-bold">Nilai Pekerjaan Anda</span>
      <p class="text-2xl font-black text-cyan-300 font-mono mt-1">Rp <?= number_format($proyek['nilai_tukang'] ?? 0, 0, ',', '.') ?></p>
      <p class="text-[11px] text-slate-400 mt-1">Alokasi upah pengerjaan proyek</p>
    </div>

    <!-- Tukang Card 2: Lingkup Pekerjaan Dialokasikan -->
    <div class="p-5 rounded-2xl glass-card lg:col-span-2">
      <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Rincian Tugas / Pekerjaan Anda</span>
      <p class="text-sm font-semibold text-white mt-1 leading-snug">
        <?= !empty($proyek['pekerjaan_tukang']) ? nl2br(esc($proyek['pekerjaan_tukang'])) : '<span class="text-slate-500 italic">Fabrikasi & perakitan proyek secara keseluruhan</span>' ?>
      </p>
    </div>

    <!-- Tukang Card 3: Jadwal Pengerjaan -->
    <div class="p-5 rounded-2xl glass-card">
      <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Target Waktu Kerja</span>
      <p class="text-xs font-bold text-slate-200 mt-1">Mulai: <?= !empty($proyek['tanggal_mulai']) ? date('d/m/Y', strtotime($proyek['tanggal_mulai'])) : '-' ?></p>
      <p class="text-xs text-amber-400 mt-0.5">Deadline: <?= !empty($proyek['tanggal_target_selesai']) ? date('d/m/Y', strtotime($proyek['tanggal_target_selesai'])) : '-' ?></p>
    </div>
  <?php endif; ?>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

  <!-- Left: Progress Form & Timeline Updates -->
  <div class="lg:col-span-2 space-y-6">

    <!-- Update Progress Form -->
    <div class="p-6 rounded-2xl glass-card space-y-5">
      <div class="flex items-center justify-between">
        <div>
          <h3 class="text-base font-bold text-white font-display">Update Progress Fisik & Status</h3>
          <p class="text-xs text-slate-400">
            <?= $isAdmin ? 'Kelola progres fisik, alokasi tukang, jadwal, dan dokumentasi foto pengerjaan.' : 'Perbarui persentase kemajuan pekerjaan, catatan pengerjaan, dan unggah foto dokumentasi.' ?>
          </p>
        </div>
        <span class="text-2xl font-black text-emerald-400 font-mono"><?= $proyek['progress'] ?>%</span>
      </div>

      <form method="POST" action="<?= base_url('admin/crm/proyek/update-progress/' . $proyek['id_proyek']) ?>" enctype="multipart/form-data" class="space-y-4">
        <?= csrf_field() ?>

        <!-- Progress Slider -->
        <div>
          <div class="flex items-center justify-between text-xs text-slate-300 mb-1.5">
            <label class="font-semibold uppercase tracking-wider text-[11px]">Persentase Kemajuan Fisik (%)</label>
            <span id="sliderVal" class="font-mono font-bold text-emerald-400 text-sm"><?= $proyek['progress'] ?>%</span>
          </div>
          <input 
            type="range" 
            name="progress" 
            id="progressRange" 
            min="0" 
            max="100" 
            value="<?= $proyek['progress'] ?>" 
            oninput="document.getElementById('sliderVal').innerText = this.value + '%'"
            class="w-full h-2.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
          >
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Tahapan / Status Proyek</label>
            <select name="status" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
              <option value="rencana" <?= $proyek['status'] === 'rencana' ? 'selected' : '' ?>>1. Rencana / Pengadaan Bahan</option>
              <option value="proses_fabrikasi" <?= $proyek['status'] === 'proses_fabrikasi' ? 'selected' : '' ?>>2. Proses Fabrikasi di Workshop</option>
              <option value="finishing" <?= $proyek['status'] === 'finishing' ? 'selected' : '' ?>>3. Finishing & Pengecatan</option>
              <option value="pemasangan" <?= $proyek['status'] === 'pemasangan' ? 'selected' : '' ?>>4. Pemasangan / Instalasi Lokasi</option>
              <option value="selesai" <?= $proyek['status'] === 'selesai' ? 'selected' : '' ?>>5. Selesai (Serah Terima)</option>
              <option value="dibatalkan" <?= $proyek['status'] === 'dibatalkan' ? 'selected' : '' ?>>Dibatalkan</option>
            </select>
          </div>

          <?php if ($isAdmin): ?>
          <div>
            <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Penugasan Tukang</label>
            <select name="id_tukang" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
              <option value="">-- Belum Ditugaskan --</option>
              <?php foreach ($tukangList as $t): ?>
                <option value="<?= $t['id_user'] ?>" <?= ($proyek['id_tukang'] ?? 0) == $t['id_user'] ? 'selected' : '' ?>>
                  <?= esc($t['nama']) ?> (<?= esc($t['no_wa']) ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <?php endif; ?>
        </div>

        <?php if ($isAdmin): ?>
        <!-- Admin-Only Allocation & Financial Management -->
        <div class="pt-3 border-t border-slate-800 space-y-3">
          <p class="text-[11px] font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center space-x-1.5">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/>
            </svg>
            <span>Pengaturan Alokasi Pekerjaan & Upah Tukang</span>
          </p>

          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label class="block text-xs text-slate-400 mb-1">Nominal Alokasi Tukang (Rp)</label>
              <input type="number" name="nilai_tukang" value="<?= (int)($proyek['nilai_tukang'] ?? 0) ?>" min="0" max="<?= (int) ($proyek['nilai_proyek'] ?? 0) ?>" step="50000" placeholder="Misal: 5000000" class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-cyan-500/40 text-cyan-300 font-mono text-xs focus:outline-none focus:border-cyan-500">
              <span class="text-[10px] text-slate-500 mt-0.5 block">Hanya nominal ini yang terlihat oleh tukang.</span>
            </div>

            <div class="sm:col-span-2">
              <label class="block text-xs text-slate-400 mb-1">Deskripsi Bagian / Porsi Pekerjaan Tukang</label>
              <input type="text" name="pekerjaan_tukang" value="<?= esc($proyek['pekerjaan_tukang'] ?? '') ?>" placeholder="Misal: Fabrikasi rangka hollow galvanis & instalasi atap" class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
            </div>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 border-t border-slate-800">
          <div>
            <label class="block text-xs text-slate-400 mb-1">Nominal DP Terbayar Customer (Rp)</label>
            <input type="number" name="dp" value="<?= (int)($proyek['dp'] ?? 0) ?>" min="0" max="<?= (int) ($proyek['nilai_proyek'] ?? 0) ?>" step="50000" class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs">
          </div>
          <div>
            <label class="block text-xs text-slate-400 mb-1">Tanggal Mulai</label>
            <input type="date" name="tanggal_mulai" value="<?= esc($proyek['tanggal_mulai'] ?? '') ?>" class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs">
          </div>
          <div>
            <label class="block text-xs text-slate-400 mb-1">Target Selesai</label>
            <input type="date" name="tanggal_target_selesai" value="<?= esc($proyek['tanggal_target_selesai'] ?? '') ?>" class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs">
          </div>
        </div>
        <?php endif; ?>

        <!-- Upload Foto Dokumentasi -->
        <div class="pt-3 border-t border-slate-800 space-y-3">
          <p class="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-wider">Upload Foto Dokumentasi Progres</p>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <input type="file" name="foto_dokumentasi" accept="image/*" class="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-blue-600/20 file:text-blue-300 hover:file:bg-blue-600/30 cursor-pointer">
            </div>
            <div>
              <input type="text" name="caption_foto" placeholder="Keterangan foto (misal: Perakitan rangka selesai)" class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
            </div>
          </div>
        </div>

        <div>
          <label class="block text-xs text-slate-400 mb-1">Catatan Pengerjaan / Laporan Lapangan</label>
          <textarea name="catatan" rows="3" placeholder="Catatan perkembangan material, kendala teknis lapangan, atau detail pengerjaan..." class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500 resize-none"><?= esc($proyek['catatan'] ?? '') ?></textarea>
        </div>

        <button 
          type="submit" 
          class="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-blue-600/30 transition-all"
        >
          Simpan Pembaruan Proyek
        </button>
      </form>
    </div>

    <!-- Gallery Foto Dokumentasi -->
    <div class="p-6 rounded-2xl glass-card space-y-4">
      <h3 class="text-base font-bold text-white font-display">Galeri Dokumentasi Pengerjaan (<?= count($fotos) ?>)</h3>
      
      <?php if (empty($fotos)): ?>
        <p class="text-xs text-slate-500 py-6 text-center italic">Belum ada foto dokumentasi diunggah untuk proyek ini.</p>
      <?php else: ?>
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
          <?php foreach ($fotos as $f): ?>
            <div class="rounded-xl overflow-hidden bg-slate-900 border border-slate-800 space-y-2 p-2">
              <img src="<?= base_url('uploads/proyek/' . $f['file']) ?>" alt="Foto Progres" class="w-full h-36 object-cover rounded-lg">
              <p class="text-[11px] text-slate-300 font-medium truncate"><?= esc($f['caption']) ?></p>
              <p class="text-[9px] text-slate-500 font-mono"><?= date('d/m/Y H:i', strtotime($f['created_at'])) ?></p>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

  </div>

  <!-- Right: Customer Info & Link to Estimasi -->
  <div class="space-y-6">
    <div class="p-6 rounded-2xl glass-card space-y-4">
      <h3 class="text-sm font-bold text-white uppercase tracking-wider font-mono">Informasi Pelanggan & Lokasi</h3>
      
      <div class="space-y-2 text-xs">
        <div>
          <span class="text-slate-400 block text-[10px] uppercase font-mono">Nama:</span>
          <strong class="text-white text-sm"><?= esc($proyek['nama_customer']) ?></strong>
        </div>
        <div>
          <span class="text-slate-400 block text-[10px] uppercase font-mono">WhatsApp:</span>
          <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $proyek['no_wa_customer']) ?>" target="_blank" class="text-emerald-400 font-mono hover:underline"><?= esc($proyek['no_wa_customer']) ?></a>
        </div>
        <div>
          <span class="text-slate-400 block text-[10px] uppercase font-mono">Email:</span>
          <span class="text-slate-300 font-mono"><?= esc($proyek['email_customer']) ?></span>
        </div>
        <?php if (!empty($proyek['panjang']) || !empty($proyek['luas'])): ?>
          <div class="pt-2 border-t border-slate-800">
            <span class="text-slate-400 block text-[10px] uppercase font-mono">Dimensi / Ukuran:</span>
            <span class="text-slate-200 font-mono font-semibold">
              <?= $proyek['panjang'] ?>m x <?= $proyek['lebar'] ?>m (Luas: <?= $proyek['luas'] ?>m²)
            </span>
          </div>
        <?php endif; ?>
      </div>

      <?php if ($isAdmin && !empty($proyek['id_estimasi'])): ?>
        <div class="pt-4 border-t border-slate-800">
          <a href="<?= base_url('admin/crm/estimasi/detail/' . $proyek['id_estimasi']) ?>" class="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center space-x-2 transition-colors">
            <svg class="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
            </svg>
            <span>Tinjau Estimasi Asli (Admin)</span>
          </a>
        </div>
      <?php endif; ?>
    </div>

    <?php if ($isAdmin): ?>
      <div class="p-6 rounded-2xl glass-card space-y-4">
        <div>
          <h3 class="text-sm font-bold text-white uppercase tracking-wider font-mono">Kasbon Tukang</h3>
          <p class="mt-1 text-xs text-slate-400">
            Total kasbon <?= $formatRupiah($totalKasbon ?? 0) ?>, sisa alokasi <?= $formatRupiah($sisaKasbon ?? 0) ?>.
          </p>
          <?php if (!$canKasbon): ?>
            <p class="mt-2 text-xs text-amber-300">Kasbon bisa dicatat setelah tukang dan nilai upah dialokasikan, serta masih ada sisa alokasi.</p>
          <?php endif; ?>
        </div>

        <form method="POST" action="<?= base_url('admin/crm/proyek/tambah-kasbon/' . $proyek['id_proyek']) ?>" enctype="multipart/form-data" class="space-y-3 pt-3 border-t border-slate-800">
          <?= csrf_field() ?>
          <div class="grid grid-cols-2 gap-3">
            <label class="block text-xs text-slate-400">Nominal
              <input type="number" name="nominal" min="1" max="<?= (int) ($sisaKasbon ?? 0) ?>" step="1000" <?= !$canKasbon ? 'disabled' : '' ?> required class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono disabled:opacity-50" />
            </label>
            <label class="block text-xs text-slate-400">Tanggal
              <input type="date" name="tanggal_kasbon" value="<?= date('Y-m-d') ?>" <?= !$canKasbon ? 'disabled' : '' ?> required class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white disabled:opacity-50" />
            </label>
          </div>
          <label class="block text-xs text-slate-400">Metode
            <select name="metode_pembayaran" <?= !$canKasbon ? 'disabled' : '' ?> class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white disabled:opacity-50">
              <option value="transfer">Transfer</option>
              <option value="tunai">Tunai</option>
              <option value="lainnya">Lainnya</option>
            </select>
          </label>
          <label class="block text-xs text-slate-400">Keterangan
            <textarea name="keterangan" rows="2" <?= !$canKasbon ? 'disabled' : '' ?> class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white resize-none disabled:opacity-50"></textarea>
          </label>
          <label class="block text-xs text-slate-400">Bukti transfer
            <input type="file" name="bukti_transfer" accept="image/*,.pdf" <?= !$canKasbon ? 'disabled' : '' ?> class="mt-1 w-full text-xs text-slate-400 disabled:opacity-50 file:mr-3 file:rounded-lg file:border-0 file:bg-slate-800 file:px-3 file:py-2 file:text-xs file:font-semibold file:text-slate-200" />
          </label>
          <button type="submit" <?= !$canKasbon ? 'disabled' : '' ?> class="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold uppercase">Simpan Kasbon</button>
        </form>

        <div class="pt-3 border-t border-slate-800 space-y-2">
          <?php if (empty($kasbonList)): ?>
            <p class="text-xs text-slate-500 italic">Belum ada kasbon untuk proyek ini.</p>
          <?php else: ?>
            <?php foreach ($kasbonList as $kasbon): ?>
              <div class="flex items-start justify-between gap-3 text-xs">
                <div>
                  <p class="font-mono font-bold text-amber-300"><?= $formatRupiah($kasbon['nominal']) ?></p>
                  <p class="text-slate-400"><?= date('d/m/Y', strtotime($kasbon['tanggal_kasbon'])) ?> - <?= esc($kasbon['keterangan'] ?: 'Kasbon tukang') ?></p>
                </div>
                <a href="<?= base_url('admin/crm/proyek/hapus-kasbon/' . $proyek['id_proyek'] . '/' . $kasbon['id_kasbon']) ?>" onclick="return confirm('Hapus catatan kasbon ini?')" class="text-rose-400 hover:text-rose-300 font-semibold">Hapus</a>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>

</div>

<?= $this->endSection() ?>
