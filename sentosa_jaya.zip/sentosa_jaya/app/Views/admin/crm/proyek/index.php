<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<?php
$isAdmin = (session()->get('role') === 'admin');
?>

<!-- Header -->
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
  <div>
    <h2 class="text-xl font-bold text-white font-display">
      <?= $isAdmin ? 'Daftar Proyek & Monitoring Fabrikasi' : 'Daftar Proyek & Tugas Fabrikasi Anda' ?>
    </h2>
    <p class="text-xs text-slate-400">
      <?= $isAdmin ? 'Arsip seluruh proyek yang disepakati (Deal), alokasi upah tukang, dan status pembayaran.' : 'Daftar pekerjaan workshop yang dialokasikan kepada Anda beserta rincian nilai pekerjaan.' ?>
    </p>
  </div>
  <span class="text-xs font-mono text-slate-400">Total: <strong class="text-white"><?= count($list) ?></strong> Proyek</span>
</div>

<!-- Filter Bar -->
<div class="p-4 rounded-2xl glass-card flex flex-wrap items-center justify-between gap-3">
  <form method="GET" action="<?= base_url('admin/crm/proyek') ?>" class="flex flex-wrap items-center gap-3 w-full sm:w-auto">
    <div>
      <select name="status" onchange="this.form.submit()" class="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-blue-500">
        <option value="">-- Semua Status Proyek --</option>
        <option value="rencana" <?= $selectedStatus === 'rencana' ? 'selected' : '' ?>>Rencana / Persiapan</option>
        <option value="proses_fabrikasi" <?= $selectedStatus === 'proses_fabrikasi' ? 'selected' : '' ?>>Proses Fabrikasi Workshop</option>
        <option value="finishing" <?= $selectedStatus === 'finishing' ? 'selected' : '' ?>>Finishing & Cat</option>
        <option value="pemasangan" <?= $selectedStatus === 'pemasangan' ? 'selected' : '' ?>>Pemasangan Lokasi</option>
        <option value="selesai" <?= $selectedStatus === 'selesai' ? 'selected' : '' ?>>Selesai 100%</option>
        <option value="dibatalkan" <?= $selectedStatus === 'dibatalkan' ? 'selected' : '' ?>>Dibatalkan</option>
      </select>
    </div>

    <?php if ($isAdmin): ?>
    <div>
      <select name="id_tukang" onchange="this.form.submit()" class="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-blue-500">
        <option value="">-- Semua Tukang --</option>
        <?php foreach ($tukangList as $t): ?>
          <option value="<?= $t['id_user'] ?>" <?= $selectedTukang == $t['id_user'] ? 'selected' : '' ?>>
            <?= esc($t['nama']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <?php endif; ?>

    <?php if ($selectedStatus || ($isAdmin && $selectedTukang)): ?>
      <a href="<?= base_url('admin/crm/proyek') ?>" class="text-xs text-slate-400 hover:text-white underline">Reset Filter</a>
    <?php endif; ?>
  </form>
</div>

<!-- Table Card -->
<div class="rounded-2xl glass-card overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-left text-xs text-slate-300">
      <thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
        <tr>
          <th class="py-3.5 px-4">Kode Proyek</th>
          <th class="py-3.5 px-4">Nama Proyek & Customer</th>
          <?php if ($isAdmin): ?>
            <th class="py-3.5 px-4">Tukang Ditugaskan</th>
            <th class="py-3.5 px-4">Total Nilai Proyek</th>
            <th class="py-3.5 px-4">Alokasi Tukang</th>
            <th class="py-3.5 px-4">Status Bayar</th>
          <?php else: ?>
            <th class="py-3.5 px-4">Lingkup Pekerjaan Anda</th>
            <th class="py-3.5 px-4">Nilai Pekerjaan Anda</th>
          <?php endif; ?>
          <th class="py-3.5 px-4 w-40">Progress Fisik</th>
          <th class="py-3.5 px-4">Status Proyek</th>
          <th class="py-3.5 px-4 text-right">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-800/60">
        <?php if (empty($list)): ?>
          <tr>
            <td colspan="<?= $isAdmin ? 7 : 5 ?>" class="py-12 text-center text-slate-400 italic">Belum ada data proyek yang sesuai.</td>
          </tr>
        <?php else: ?>
          <?php foreach ($list as $p): ?>
            <tr class="hover:bg-slate-800/30 transition-colors">
              <td class="py-3.5 px-4 font-mono font-bold text-blue-400"><?= esc($p['kode_proyek']) ?></td>
              <td class="py-3.5 px-4">
                <p class="font-bold text-white"><?= esc($p['nama_proyek']) ?></p>
                <p class="text-[11px] text-slate-400 font-mono">
                  <?= esc($p['nama_customer']) ?> (<?= esc($p['no_wa_customer']) ?>)
                </p>
              </td>

              <?php if ($isAdmin): ?>
                <td class="py-3.5 px-4">
                  <?php if (!empty($p['nama_tukang'])): ?>
                    <span class="inline-flex items-center space-x-1 font-semibold text-slate-200">
                      <span class="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                      <span><?= esc($p['nama_tukang']) ?></span>
                    </span>
                  <?php else: ?>
                    <span class="text-slate-500 italic">Belum Ditugaskan</span>
                  <?php endif; ?>
                </td>
                <td class="py-3.5 px-4 font-mono">
                  <p class="font-bold text-emerald-400">Rp <?= number_format($p['nilai_proyek'] ?? 0, 0, ',', '.') ?></p>
                  <p class="text-[10px] text-slate-400">Sisa: Rp <?= number_format($p['sisa_pembayaran'] ?? 0, 0, ',', '.') ?></p>
                </td>
                <td class="py-3.5 px-4 font-mono">
                  <p class="font-bold text-cyan-400">Rp <?= number_format($p['nilai_tukang'] ?? 0, 0, ',', '.') ?></p>
                  <?php if (!empty($p['pekerjaan_tukang'])): ?>
                    <p class="text-[10px] text-slate-400 truncate max-w-xs" title="<?= esc($p['pekerjaan_tukang']) ?>">
                      <?= esc($p['pekerjaan_tukang']) ?>
                    </p>
                  <?php endif; ?>
                </td>
                <td class="py-3.5 px-4">
                  <span class="px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider font-bold <?= ($p['status_pembayaran'] ?? '') === 'lunas' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : (($p['status_pembayaran'] ?? '') === 'dp_terbayar' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20') ?>">
                    <?= esc(str_replace('_', ' ', $p['status_pembayaran'] ?? 'belum_lunas')) ?>
                  </span>
                </td>
              <?php else: ?>
                <td class="py-3.5 px-4">
                  <p class="text-xs text-slate-200 font-medium">
                    <?= !empty($p['pekerjaan_tukang']) ? esc($p['pekerjaan_tukang']) : '<span class="text-slate-500 italic">Seluruh Fabrikasi Proyek</span>' ?>
                  </p>
                </td>
                <td class="py-3.5 px-4 font-mono">
                  <p class="font-bold text-cyan-400 text-sm">Rp <?= number_format($p['nilai_tukang'] ?? 0, 0, ',', '.') ?></p>
                  <p class="text-[10px] text-slate-400">Nilai Alokasi Anda</p>
                </td>
              <?php endif; ?>

              <td class="py-3.5 px-4">
                <div class="space-y-1">
                  <div class="flex items-center justify-between text-[11px] font-mono">
                    <span class="text-slate-400">Progres:</span>
                    <span class="font-bold text-white"><?= $p['progress'] ?>%</span>
                  </div>
                  <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div class="bg-gradient-to-r from-blue-500 to-emerald-500 h-full rounded-full transition-all" style="width: <?= $p['progress'] ?>%"></div>
                  </div>
                </div>
              </td>
              <td class="py-3.5 px-4">
                <span class="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider <?= $p['status'] === 'selesai' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-800 text-slate-300 border border-slate-700' ?>">
                  <?= esc(str_replace('_', ' ', $p['status'])) ?>
                </span>
              </td>
              <td class="py-3.5 px-4 text-right">
                <a 
                  href="<?= base_url('admin/crm/proyek/detail/' . $p['id_proyek']) ?>" 
                  class="px-3 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600 text-blue-300 hover:text-white text-xs font-semibold border border-blue-500/30 transition-all"
                >
                  Detail
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection() ?>