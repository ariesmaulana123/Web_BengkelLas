<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<?php
$isAdmin = ($role === 'admin');
$formatRupiah = static fn ($value) => 'Rp ' . number_format((float) $value, 0, ',', '.');
?>

<div class="flex flex-col md:flex-row md:items-end justify-between gap-4">
	<div>
		<p class="text-[10px] font-mono uppercase tracking-[0.2em] text-amber-400">Keuangan Tukang</p>
		<h2 class="text-2xl font-bold text-white font-display mt-1"><?= esc($pageTitle) ?></h2>
		<p class="text-xs text-slate-400 mt-1 max-w-2xl"><?= esc($pageSubtitle) ?></p>
	</div>
	<?php if ($isAdmin): ?>
		<span class="text-xs font-mono text-slate-400">Total transaksi: <strong class="text-white"><?= count($kasbonList) ?></strong></span>
	<?php endif; ?>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
	<div class="p-5 rounded-2xl glass-card border border-amber-500/20">
		<p class="text-[10px] uppercase tracking-wider font-mono text-slate-400">Total Kasbon Dicairkan</p>
		<p class="text-xl font-black font-mono text-amber-300 mt-2"><?= $formatRupiah($totalKasbonDicairkan) ?></p>
	</div>
	<div class="p-5 rounded-2xl glass-card border border-cyan-500/20">
		<p class="text-[10px] uppercase tracking-wider font-mono text-slate-400">Total Alokasi Upah</p>
		<p class="text-xl font-black font-mono text-cyan-300 mt-2"><?= $formatRupiah($totalAlokasiUpah) ?></p>
	</div>
	<div class="p-5 rounded-2xl glass-card border border-emerald-500/20">
		<p class="text-[10px] uppercase tracking-wider font-mono text-slate-400">Sisa Alokasi</p>
		<p class="text-xl font-black font-mono text-emerald-300 mt-2"><?= $formatRupiah($totalSisaAlokasi) ?></p>
	</div>
</div>

<?php if ($isAdmin): ?>
<div class="grid grid-cols-1 xl:grid-cols-3 gap-6">
	<div class="xl:col-span-1 p-6 rounded-2xl glass-card border border-amber-500/20">
		<div class="mb-5">
			<h3 class="text-base font-bold text-white font-display">Catat Kasbon Baru</h3>
			<p class="text-xs text-slate-400 mt-1">Nominal otomatis dibatasi oleh alokasi upah proyek.</p>
		</div>
		<form method="POST" action="<?= base_url('admin/crm/kasbon/store') ?>" enctype="multipart/form-data" class="space-y-4">
			<?= csrf_field() ?>
			<div>
				<label class="block text-[10px] uppercase tracking-wider font-bold text-slate-400 mb-1.5">Proyek & Tukang</label>
				<select name="id_proyek" required class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-amber-500">
					<option value="">-- Pilih proyek --</option>
					<?php foreach ($activeProjectsForKasbon as $project): ?>
						<option value="<?= (int) $project['id_proyek'] ?>">
							<?= esc($project['kode_proyek']) ?> - <?= esc($project['nama_tukang'] ?? 'Tanpa nama') ?> (sisa <?= $formatRupiah($project['sisa_alokasi']) ?>)
						</option>
					<?php endforeach; ?>
				</select>
				<?php if (empty($activeProjectsForKasbon)): ?>
					<p class="text-[11px] text-amber-300 mt-2">Belum ada proyek dengan tukang dan sisa alokasi upah.</p>
				<?php endif; ?>
			</div>
			<div class="grid grid-cols-2 gap-3">
				<div>
					<label class="block text-[10px] uppercase tracking-wider font-bold text-slate-400 mb-1.5">Nominal</label>
					<input type="number" name="nominal" min="1" step="1000" required placeholder="500000" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-500">
				</div>
				<div>
					<label class="block text-[10px] uppercase tracking-wider font-bold text-slate-400 mb-1.5">Tanggal</label>
					<input type="date" name="tanggal_kasbon" value="<?= date('Y-m-d') ?>" required class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-500">
				</div>
			</div>
			<div>
				<label class="block text-[10px] uppercase tracking-wider font-bold text-slate-400 mb-1.5">Metode Pembayaran</label>
				<select name="metode_pembayaran" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-amber-500">
					<option value="transfer">Transfer</option>
					<option value="tunai">Tunai</option>
					<option value="lainnya">Lainnya</option>
				</select>
			</div>
			<div>
				<label class="block text-[10px] uppercase tracking-wider font-bold text-slate-400 mb-1.5">Keterangan</label>
				<textarea name="keterangan" rows="3" placeholder="Contoh: Kasbon mingguan untuk kebutuhan proyek" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-amber-500"></textarea>
			</div>
			<div>
				<label class="block text-[10px] uppercase tracking-wider font-bold text-slate-400 mb-1.5">Bukti Transfer <span class="font-normal normal-case">(opsional)</span></label>
				<input type="file" name="bukti_transfer" accept="image/*,.pdf" class="w-full text-xs text-slate-400 file:mr-3 file:rounded-lg file:border-0 file:bg-slate-800 file:px-3 file:py-2 file:text-xs file:font-semibold file:text-slate-200">
			</div>
			<button type="submit" <?= empty($activeProjectsForKasbon) ? 'disabled' : '' ?> class="w-full inline-flex justify-center items-center px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold transition-colors">Simpan Kasbon</button>
		</form>
	</div>
	<div class="xl:col-span-2 space-y-4">
<?php endif; ?>

<div class="p-4 rounded-2xl glass-card flex flex-wrap items-center gap-3">
	<form method="GET" action="<?= base_url('admin/crm/kasbon') ?>" class="flex flex-wrap items-center gap-3 w-full">
		<?php if ($isAdmin): ?>
			<select name="id_tukang" onchange="this.form.submit()" class="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-blue-500">
				<option value="">-- Semua Tukang --</option>
				<?php foreach ($tukangList as $tukang): ?>
					<option value="<?= (int) $tukang['id_user'] ?>" <?= (int) $selectedTukang === (int) $tukang['id_user'] ? 'selected' : '' ?>><?= esc($tukang['nama']) ?></option>
				<?php endforeach; ?>
			</select>
		<?php endif; ?>
		<select name="id_proyek" onchange="this.form.submit()" class="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-blue-500">
			<option value="">-- Semua Proyek --</option>
			<?php foreach ($proyekList as $project): ?>
				<option value="<?= (int) $project['id_proyek'] ?>" <?= (int) $selectedProyek === (int) $project['id_proyek'] ? 'selected' : '' ?>><?= esc($project['kode_proyek']) ?> - <?= esc($project['nama_proyek']) ?></option>
			<?php endforeach; ?>
		</select>
		<?php if ($selectedTukang || $selectedProyek): ?><a href="<?= base_url('admin/crm/kasbon') ?>" class="text-xs text-slate-400 hover:text-white underline">Reset filter</a><?php endif; ?>
	</form>
</div>

<div class="rounded-2xl glass-card overflow-hidden">
	<div class="overflow-x-auto">
		<table class="w-full text-left text-xs text-slate-300">
			<thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
				<tr>
					<th class="py-3.5 px-4">Tanggal</th><th class="py-3.5 px-4">Proyek</th>
					<?php if ($isAdmin): ?><th class="py-3.5 px-4">Tukang</th><?php endif; ?>
					<th class="py-3.5 px-4">Nominal</th><th class="py-3.5 px-4">Metode</th><th class="py-3.5 px-4">Keterangan</th>
					<?php if ($isAdmin): ?><th class="py-3.5 px-4 text-right">Aksi</th><?php endif; ?>
				</tr>
			</thead>
			<tbody class="divide-y divide-slate-800/60">
				<?php if (empty($kasbonList)): ?>
					<tr><td colspan="<?= $isAdmin ? 7 : 5 ?>" class="px-4 py-12 text-center text-slate-500">Belum ada riwayat kasbon.</td></tr>
				<?php else: ?>
					<?php foreach ($kasbonList as $kasbon): ?>
						<tr class="hover:bg-slate-800/30">
							<td class="px-4 py-3 font-mono text-slate-400 whitespace-nowrap"><?= date('d/m/Y', strtotime($kasbon['tanggal_kasbon'])) ?></td>
							<td class="px-4 py-3"><p class="font-semibold text-white"><?= esc($kasbon['kode_proyek'] ?? '-') ?></p><p class="text-[11px] text-slate-500 truncate max-w-[220px]"><?= esc($kasbon['nama_proyek'] ?? '-') ?></p></td>
							<?php if ($isAdmin): ?><td class="px-4 py-3 text-slate-200"><?= esc($kasbon['nama_tukang'] ?? '-') ?></td><?php endif; ?>
							<td class="px-4 py-3 font-mono font-bold text-amber-300 whitespace-nowrap"><?= $formatRupiah($kasbon['nominal']) ?></td>
							<td class="px-4 py-3 capitalize text-slate-300"><?= esc($kasbon['metode_pembayaran'] ?? '-') ?></td>
							<td class="px-4 py-3 max-w-[260px] text-slate-400"><?= esc($kasbon['keterangan'] ?: '-') ?></td>
							<?php if ($isAdmin): ?><td class="px-4 py-3 text-right"><a href="<?= base_url('admin/crm/kasbon/hapus/' . $kasbon['id_kasbon']) ?>" onclick="return confirm('Hapus catatan kasbon ini?')" class="text-rose-400 hover:text-rose-300 font-semibold">Hapus</a></td><?php endif; ?>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>

<?php if ($isAdmin): ?></div></div><?php endif; ?>

<?= $this->endSection() ?>
