<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<!-- Header -->
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
  <div>
    <h2 class="text-xl font-bold text-white font-display">Pencatatan Pekerjaan Manual</h2>
    <p class="text-xs text-slate-400">Catat kesepakatan pekerjaan customer dari WhatsApp. Data kalkulator user tidak ditampilkan di CRM ini.</p>
  </div>
  <a href="<?= base_url('admin/crm/estimasi/create') ?>" class="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-blue-600/20 transition-all">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
    <span>Catat Pekerjaan</span>
  </a>
</div>

<!-- Status Filter Tabs -->
<div class="flex items-center gap-2 overflow-x-auto pb-2">
  <a href="<?= base_url('admin/crm/estimasi') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= empty($selectedStatus) ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800' ?>">
    Semua (<?= $stats['total'] ?>)
  </a>
  <a href="<?= base_url('admin/crm/estimasi?status=baru') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= $selectedStatus === 'baru' ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/25' : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800' ?>">
    Baru / Pengajuan (<?= $stats['baru'] ?>)
  </a>
  <a href="<?= base_url('admin/crm/estimasi?status=dihubungi') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= $selectedStatus === 'dihubungi' ? 'bg-sky-600 text-white shadow-lg shadow-sky-600/25' : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800' ?>">
    Dihubungi
  </a>
  <a href="<?= base_url('admin/crm/estimasi?status=survey') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= $selectedStatus === 'survey' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25' : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800' ?>">
    Survey (<?= $stats['survey'] ?>)
  </a>
  <a href="<?= base_url('admin/crm/estimasi?status=penawaran') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= $selectedStatus === 'penawaran' ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/25' : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800' ?>">
    Penawaran (<?= $stats['penawaran'] ?>)
  </a>
  <a href="<?= base_url('admin/crm/estimasi?status=deal') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= $selectedStatus === 'deal' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/25' : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800' ?>">
    Deal (<?= $stats['deal'] ?>)
  </a>
  <a href="<?= base_url('admin/crm/estimasi?status=ditolak') ?>" class="px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= $selectedStatus === 'ditolak' ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/25' : 'bg-slate-900/80 text-slate-400 hover:text-white hover:bg-slate-800' ?>">
    Ditolak (<?= $stats['ditolak'] ?>)
  </a>
</div>

<!-- Search Bar -->
<div class="p-4 rounded-2xl glass-card">
  <form method="GET" action="<?= base_url('admin/crm/estimasi') ?>" class="flex flex-col sm:flex-row items-center gap-3">
    <?php if ($selectedStatus): ?>
      <input type="hidden" name="status" value="<?= esc($selectedStatus) ?>">
    <?php endif; ?>
    <div class="relative flex-1 w-full">
      <svg class="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
      </svg>
      <input 
        type="text" 
        name="q" 
        value="<?= esc($search ?? '') ?>" 
        placeholder="Cari berdasarkan nama customer, no. whatsapp, no. estimasi (#EST-00001)..." 
        class="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
      >
    </div>
    <div class="flex items-center space-x-2 w-full sm:w-auto">
      <button type="submit" class="w-full sm:w-auto px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider">
        Cari
      </button>
      <?php if ($search || $selectedStatus): ?>
        <a href="<?= base_url('admin/crm/estimasi') ?>" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold">
          Reset
        </a>
      <?php endif; ?>
    </div>
  </form>
</div>

<!-- Table Card -->
<div class="rounded-2xl glass-card overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-left text-xs text-slate-300">
      <thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
        <tr>
          <th class="py-3.5 px-4">No. Catatan</th>
          <th class="py-3.5 px-4">Customer</th>
          <th class="py-3.5 px-4">Pekerjaan & Ukuran</th>
          <th class="py-3.5 px-4">Harga Bahan</th>
          <th class="py-3.5 px-4">Total Manual</th>
          <th class="py-3.5 px-4">Status</th>
          <th class="py-3.5 px-4">Tanggal Masuk</th>
          <th class="py-3.5 px-4 text-right">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-800/60">
        <?php if (empty($list)): ?>
          <tr>
            <td colspan="8" class="py-12 text-center text-slate-400 italic">
              Belum ada catatan pekerjaan manual.
            </td>
          </tr>
        <?php else: ?>
          <?php foreach ($list as $item): ?>
            <?php 
              $cleanStatus = in_array($item['status'], ['pengajuan_survey', 'dihitung', 'baru']) ? 'baru' : $item['status'];
            ?>
            <tr class="hover:bg-slate-800/30 transition-colors">
              <td class="py-3.5 px-4 font-mono font-bold text-blue-400">
                #EST-<?= str_pad((string)$item['id_estimasi'], 5, '0', STR_PAD_LEFT) ?>
              </td>
              <td class="py-3.5 px-4">
                <p class="font-bold text-white"><?= esc($item['nama_customer']) ?></p>
                <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $item['no_wa_customer']) ?>" target="_blank" class="text-[11px] text-emerald-400 hover:underline font-mono flex items-center space-x-1 mt-0.5">
                  <span><?= esc($item['no_wa_customer']) ?></span>
                </a>
              </td>
              <td class="py-3.5 px-4">
                <p class="font-semibold text-white"><?= esc($item['nama_pekerjaan'] ?: $item['nama_jp']) ?></p>
                <p class="text-[11px] text-slate-400 font-mono">
                  <?= esc($item['nama_jenis_pekerjaan'] ?? $item['nama_jp']) ?> · <?= $item['panjang'] ?>m x <?= $item['lebar'] ?>m x <?= $item['tinggi'] ?: '-' ?>m · <?= esc($item['qty_unit']) ?> unit
                </p>
              </td>
              <td class="py-3.5 px-4 font-mono text-slate-300">
                Rp <?= number_format($item['harga_bahan'], 0, ',', '.') ?>
              </td>
              <td class="py-3.5 px-4 font-mono font-bold text-emerald-400">
                Rp <?= number_format($item['total_final'], 0, ',', '.') ?>
              </td>
              <td class="py-3.5 px-4">
                <span class="inline-block px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider <?= $cleanStatus === 'baru' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : ($cleanStatus === 'deal' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : ($cleanStatus === 'penawaran' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' : ($cleanStatus === 'survey' ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' : 'bg-slate-800 text-slate-300 border border-slate-700'))) ?>">
                  <?= esc(str_replace('_', ' ', $cleanStatus)) ?>
                </span>
              </td>
              <td class="py-3.5 px-4 font-mono text-[11px] text-slate-400">
                <?= date('d/m/Y H:i', strtotime($item['created_at'])) ?>
              </td>
              <td class="py-3.5 px-4 text-right">
                <div class="flex items-center justify-end space-x-2">
                  <a 
                    href="<?= base_url('admin/crm/estimasi/detail/' . $item['id_estimasi']) ?>" 
                    class="px-3 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600 text-blue-300 hover:text-white text-xs font-semibold border border-blue-500/30 transition-all"
                  >
                    Kelola
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection() ?>