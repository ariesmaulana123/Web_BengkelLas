<?php
  $settings = array_merge([
    'nama_perusahaan'            => 'Sentosa Jaya Las',
    'tagline'                    => 'Bengkel Las & Spesialis Fabrikasi Baja Presisi',
    'alamat'                     => 'Jl. Raya Setu, Kec. Setu, Kabupaten Bekasi, Jawa Barat 17320',
    'no_wa'                      => '087766364557',
    'email'                      => 'kontak@sentosajayalas.com',
    'nama_bank'                  => 'BCA',
    'no_rekening'                => '123-456-7890',
    'atas_nama'                  => 'Sentosa Jaya Las',
    'atas_nama_bank'             => 'Sentosa Jaya Las',
    'catatan_penawaran'          => '1. Harga sudah termasuk material, fabrikasi, dan pemasangan di lokasi.\n2. Pembayaran DP 50% saat deal penawaran, sisa 50% setelah pekerjaan selesai terpasang.',
    'nama_penanggung_jawab'     => 'Bambang Sentosa',
    'jabatan_penanggung_jawab'   => 'Kepala Workshop',
  ], $settings ?? []);
  $details = $details ?? [];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Penawaran Harga #EST-<?= str_pad((string)$estimasi['id_estimasi'], 5, '0', STR_PAD_LEFT) ?></title>
  <style>
    * { box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
    body { font-size: 11px; color: #1e293b; line-height: 1.4; margin: 0; padding: 15px; }
    .header-table { width: 100%; border-bottom: 2px solid #0284c7; padding-bottom: 12px; margin-bottom: 15px; }
    .company-title { font-size: 18px; font-weight: bold; color: #0369a1; text-transform: uppercase; margin: 0; letter-spacing: 0.5px; }
    .company-tagline { font-size: 10px; color: #64748b; margin-top: 2px; }
    .company-contact { font-size: 9px; color: #475569; text-align: right; line-height: 1.3; }
    .doc-title { text-align: center; font-size: 14px; font-weight: bold; text-transform: uppercase; margin: 12px 0 16px 0; color: #0f172a; letter-spacing: 1px; }
    .info-table { width: 100%; margin-bottom: 15px; }
    .info-box { width: 48%; vertical-align: top; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; padding: 8px 10px; }
    .info-title { font-size: 9px; font-weight: bold; text-transform: uppercase; color: #64748b; margin-bottom: 4px; border-bottom: 1px solid #cbd5e1; padding-bottom: 2px; }
    .items-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 10px; }
    .items-table th { background: #0f172a; color: #ffffff; padding: 6px 8px; text-transform: uppercase; font-size: 9px; }
    .items-table td { padding: 6px 8px; border-bottom: 1px solid #e2e8f0; }
    .items-table tr:nth-child(even) td { background: #f8fafc; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .font-bold { font-weight: bold; }
    .font-mono { font-family: 'Courier New', Courier, monospace; }
    .summary-table { width: 50%; float: right; margin-bottom: 15px; border-collapse: collapse; font-size: 10px; }
    .summary-table td { padding: 4px 6px; }
    .total-row { background: #f0f9ff; border-top: 2px solid #0284c7; border-bottom: 2px solid #0284c7; font-size: 12px; font-weight: bold; color: #0369a1; }
    .clear { clear: both; }
    .terms-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px; padding: 8px 10px; margin-bottom: 20px; font-size: 9px; }
    .bank-box { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 4px; padding: 8px 10px; margin-bottom: 20px; font-size: 9px; }
    .signature-table { width: 100%; text-align: center; margin-top: 25px; page-break-inside: avoid; }
    .signature-space { height: 55px; }
  </style>
</head>
<body>

  <!-- Kop Surat Perusahaan -->
  <table class="header-table">
    <tr>
      <td style="width: 60%; vertical-align: middle;">
        <h1 class="company-title"><?= esc($settings['nama_perusahaan']) ?></h1>
        <p class="company-tagline"><?= esc($settings['tagline']) ?></p>
        <p style="font-size: 9px; color: #475569; margin-top: 4px;"><?= esc($settings['alamat']) ?></p>
      </td>
      <td class="company-contact" style="width: 40%; vertical-align: middle;">
        <p><strong>WhatsApp:</strong> <?= esc($settings['no_wa']) ?></p>
        <p><strong>Email:</strong> <?= esc($settings['email']) ?></p>
        <p><strong>Tanggal:</strong> <?= date('d F Y', strtotime($estimasi['created_at'])) ?></p>
      </td>
    </tr>
  </table>

  <!-- Judul Dokumen -->
  <div class="doc-title">
    Surat Penawaran Harga (Quotation)
  </div>

  <!-- Info Pelanggan & Proyek -->
  <table class="info-table">
    <tr>
      <td class="info-box">
        <div class="info-title">Ditujukan Kepada:</div>
        <p><strong><?= esc($estimasi['nama_customer']) ?></strong></p>
        <p>No. Telp/WA: <?= esc($estimasi['no_wa_customer']) ?></p>
        <p>Email: <?= esc($estimasi['email_customer']) ?></p>
        <?php if (!empty($estimasi['lokasi_survey'])): ?>
          <p>Lokasi: <?= esc($estimasi['lokasi_survey']) ?></p>
        <?php endif; ?>
      </td>
      <td style="width: 4%;"></td>
      <td class="info-box">
        <div class="info-title">Rincian Referensi:</div>
        <p><strong>No. Penawaran:</strong> <span class="font-mono">#EST-<?= str_pad((string)$estimasi['id_estimasi'], 5, '0', STR_PAD_LEFT) ?></span></p>
        <p><strong>Pekerjaan:</strong> <?= esc($estimasi['nama_jp']) ?></p>
        <p><strong>Ukuran / Volume:</strong> <?= $estimasi['panjang'] ?>m x <?= $estimasi['lebar'] ?>m = <strong><?= $estimasi['luas'] ?> m²</strong><?= $estimasi['tinggi'] ? " (T: {$estimasi['tinggi']}m)" : "" ?></p>
        <p><strong>Masa Berlaku:</strong> 14 Hari sejak tanggal terbit</p>
      </td>
    </tr>
  </table>

  <!-- Tabel Breakdown Rincian Biaya -->
  <table class="items-table">
    <thead>
      <tr>
        <th style="width: 5%; text-align: center;">No</th>
        <th style="width: 15%;">Kategori</th>
        <th style="width: 45%;">Deskripsi Material & Spesifikasi Teknis</th>
        <th style="width: 10%; text-align: right;">Volume</th>
        <th style="width: 12%; text-align: right;">Harga (Rp)</th>
        <th style="width: 13%; text-align: right;">Subtotal (Rp)</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!empty($details)): ?>
        <?php $no = 1; foreach ($details as $d): ?>
          <tr>
            <td class="text-center font-mono"><?= $no++ ?></td>
            <td style="text-transform: capitalize; color: #475569;"><?= esc($d['kategori'] ?? 'Material') ?></td>
            <td><strong><?= esc($d['nama_material']) ?></strong></td>
            <td class="text-right font-mono"><?= $d['qty'] ?> <?= esc($d['satuan'] ?? '') ?></td>
            <td class="text-right font-mono"><?= number_format($d['harga'], 0, ',', '.') ?></td>
            <td class="text-right font-mono font-bold"><?= number_format($d['subtotal'], 0, ',', '.') ?></td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr>
          <td class="text-center font-mono">1</td>
          <td style="color: #475569;">Bahan / Material</td>
          <td>
            <strong><?= esc($estimasi['material_custom'] ?? $estimasi['nama_pekerjaan']) ?></strong>
            <?php if (!empty($estimasi['ukuran_lubang'])): ?>
              <br><span style="font-size: 8px; color: #64748b;">Ukuran / Lubang: <?= esc($estimasi['ukuran_lubang']) ?></span>
            <?php endif; ?>
          </td>
          <td class="text-right font-mono"><?= esc($estimasi['qty_unit'] ?? '1 Unit') ?></td>
          <td class="text-right font-mono"><?= number_format((float)($estimasi['harga_bahan'] ?? 0), 0, ',', '.') ?></td>
          <td class="text-right font-mono font-bold"><?= number_format((float)($estimasi['harga_bahan'] ?? 0), 0, ',', '.') ?></td>
        </tr>
        <?php if (!empty($estimasi['harga_jasa']) && $estimasi['harga_jasa'] > 0): ?>
          <tr>
            <td class="text-center font-mono">2</td>
            <td style="color: #475569;">Jasa Fabrikasi</td>
            <td><strong>Jasa Fabrikasi, Pengelasan & Finishing</strong></td>
            <td class="text-right font-mono"><?= esc($estimasi['qty_unit'] ?? '1 Unit') ?></td>
            <td class="text-right font-mono"><?= number_format((float)$estimasi['harga_jasa'], 0, ',', '.') ?></td>
            <td class="text-right font-mono font-bold"><?= number_format((float)$estimasi['harga_jasa'], 0, ',', '.') ?></td>
          </tr>
        <?php endif; ?>
      <?php endif; ?>
    </tbody>
  </table>

  <!-- Rekapitulasi Summary -->
  <table class="summary-table">
    <tr>
      <td>Subtotal Material:</td>
      <td class="text-right font-mono font-bold">Rp <?= number_format($estimasi['subtotal'], 0, ',', '.') ?></td>
    </tr>
    <?php if (!empty($estimasi['biaya_jasa']) && $estimasi['biaya_jasa'] > 0): ?>
      <tr>
        <td>Jasa Pemasangan Khusus:</td>
        <td class="text-right font-mono">Rp <?= number_format($estimasi['biaya_jasa'], 0, ',', '.') ?></td>
      </tr>
    <?php endif; ?>
    <?php if (!empty($estimasi['biaya_pengiriman']) && $estimasi['biaya_pengiriman'] > 0): ?>
      <tr>
        <td>Biaya Pengiriman & Logistik:</td>
        <td class="text-right font-mono">Rp <?= number_format($estimasi['biaya_pengiriman'], 0, ',', '.') ?></td>
      </tr>
    <?php endif; ?>
    <?php if (!empty($estimasi['biaya_tambahan']) && $estimasi['biaya_tambahan'] > 0): ?>
      <tr>
        <td>Biaya Tambahan / Printilan:</td>
        <td class="text-right font-mono">Rp <?= number_format($estimasi['biaya_tambahan'], 0, ',', '.') ?></td>
      </tr>
    <?php endif; ?>
    <?php if (!empty($estimasi['diskon']) && $estimasi['diskon'] > 0): ?>
      <tr>
        <td style="color: #e11d48;">Potongan Diskon:</td>
        <td class="text-right font-mono" style="color: #e11d48;">- Rp <?= number_format($estimasi['diskon'], 0, ',', '.') ?></td>
      </tr>
    <?php endif; ?>
    <tr class="total-row">
      <td>TOTAL FINAL:</td>
      <td class="text-right font-mono">Rp <?= number_format($estimasi['total_final'] ? $estimasi['total_final'] : $estimasi['subtotal'], 0, ',', '.') ?></td>
    </tr>
  </table>

  <div class="clear"></div>

  <!-- Rekening Pembayaran -->
  <div class="bank-box">
    <strong>INFORMASI REKENING PEMBAYARAN RESMI:</strong><br>
    Bank: <strong><?= esc($settings['nama_bank']) ?></strong> | No. Rekening: <strong><?= esc($settings['no_rekening']) ?></strong> | A.N: <strong><?= esc($settings['atas_nama_bank']) ?></strong>
  </div>

  <!-- Syarat & Ketentuan -->
  <div class="terms-box">
    <strong>SYARAT & KETENTUAN PENAWARAN:</strong><br>
    <?= nl2br(esc($settings['catatan_penawaran'])) ?>
  </div>

  <!-- Kolom Tanda Tangan -->
  <table class="signature-table">
    <tr>
      <td style="width: 50%;">
        Disetujui Oleh (Pelanggan),
        <div class="signature-space"></div>
        <strong>( <?= esc($estimasi['nama_customer']) ?> )</strong>
      </td>
      <td style="width: 50%;">
        Hormat Kami, <strong><?= esc($settings['nama_perusahaan']) ?></strong>
        <div class="signature-space"></div>
        <strong>( <?= esc($settings['nama_penanggung_jawab'] ?? 'Bambang Sentosa') ?> )</strong><br>
        <span style="font-size: 8px; color: #64748b;"><?= esc($settings['jabatan_penanggung_jawab'] ?? 'Kepala Workshop') ?></span>
      </td>
    </tr>
  </table>

</body>
</html>
