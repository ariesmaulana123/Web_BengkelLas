<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Laporan Pekerjaan #EST-<?= str_pad((string) $estimasi['id_estimasi'], 5, '0', STR_PAD_LEFT) ?></title>
  <style>
    * { box-sizing: border-box; font-family: Helvetica, Arial, sans-serif; }
    body { color: #1e293b; font-size: 11px; line-height: 1.5; }
    h1 { color: #0369a1; font-size: 18px; margin: 0; }
    h2 { color: #0f172a; font-size: 15px; text-align: center; margin: 24px 0; }
    .muted { color: #64748b; }
    table { width: 100%; border-collapse: collapse; margin: 12px 0 20px; }
    th, td { border: 1px solid #cbd5e1; padding: 8px; text-align: left; vertical-align: top; }
    th { width: 28%; background: #f1f5f9; }
    .total { background: #e0f2fe; font-weight: bold; color: #0369a1; }
    .header { border-bottom: 2px solid #0284c7; padding-bottom: 10px; }
    .right { text-align: right; }
  </style>
</head>
<body>
  <div class="header"><h1><?= esc($settings['nama_perusahaan']) ?></h1><div class="muted"><?= esc($settings['tagline']) ?> · <?= esc($settings['no_wa']) ?></div></div>
  <h2>Laporan Pekerjaan #EST-<?= str_pad((string) $estimasi['id_estimasi'], 5, '0', STR_PAD_LEFT) ?></h2>
  <table>
    <tr><th>Customer</th><td><?= esc($estimasi['nama_customer']) ?></td></tr>
    <tr><th>WhatsApp</th><td><?= esc($estimasi['no_wa_customer']) ?></td></tr>
    <tr><th>Jenis pekerjaan</th><td><?= esc($estimasi['nama_jenis_pekerjaan'] ?? 'Custom') ?></td></tr>
    <tr><th>Nama pekerjaan</th><td><?= esc($estimasi['nama_pekerjaan'] ?: $estimasi['nama_jp']) ?></td></tr>
    <tr><th>Ukuran</th><td><?= esc($estimasi['panjang']) ?> × <?= esc($estimasi['lebar']) ?> × <?= esc($estimasi['tinggi'] ?: '-') ?> m · <?= esc($estimasi['luas']) ?> m² · <?= esc($estimasi['qty_unit'] ?? '1') ?> unit</td></tr>
    <tr><th>Ukuran per lubang</th><td><?= esc($estimasi['ukuran_lubang'] ?: '-') ?></td></tr>
    <tr><th>Material dan spesifikasi</th><td><?= nl2br(esc($estimasi['material_custom'] ?: '-')) ?></td></tr>
    <tr><th>Tanggal pekerjaan / survey</th><td><?= $estimasi['tanggal_survey'] ? date('d/m/Y H:i', strtotime($estimasi['tanggal_survey'])) : '-' ?></td></tr>
    <tr><th>Lokasi</th><td><?= nl2br(esc($estimasi['lokasi_survey'] ?: '-')) ?></td></tr>
    <tr><th>Status</th><td><?= esc(strtoupper(str_replace('_', ' ', $estimasi['status']))) ?></td></tr>
    <tr><th>Catatan</th><td><?= nl2br(esc($estimasi['catatan'] ?: '-')) ?></td></tr>
  </table>
  <table>
    <tr><th>Harga bahan</th><td class="right">Rp <?= number_format((float) $estimasi['harga_bahan'], 0, ',', '.') ?></td></tr>
    <tr><th>Biaya jasa</th><td class="right">Rp <?= number_format((float) $estimasi['harga_jasa'], 0, ',', '.') ?></td></tr>
    <tr><th>Subtotal manual</th><td class="right">Rp <?= number_format((float) $estimasi['subtotal'], 0, ',', '.') ?></td></tr>
    <tr class="total"><th>Harga final / total</th><td class="right">Rp <?= number_format((float) $estimasi['total_final'], 0, ',', '.') ?></td></tr>
  </table>
  <p class="muted">Dicatat pada <?= date('d/m/Y H:i', strtotime($estimasi['created_at'])) ?>. Nominal berdasarkan input manual Admin.</p>
</body>
</html>