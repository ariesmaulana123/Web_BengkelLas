<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>
<?php
$nilaiProyek = (float) ($estimasi['total_final'] ?? 0);
if ($nilaiProyek <= 0) {
  $nilaiProyek = (float) ($estimasi['subtotal'] ?? 0);
}
if ($nilaiProyek <= 0) {
  $nilaiProyek = (float) ($estimasi['harga_bahan'] ?? 0) + (float) ($estimasi['harga_jasa'] ?? 0);
}
$canKasbon = !empty($existingProyek)
  && !empty($existingProyek['id_tukang'])
  && (float) ($existingProyek['nilai_tukang'] ?? 0) > 0
  && (float) ($sisaKasbon ?? 0) > 0;
$formatRupiah = static fn ($value) => 'Rp ' . number_format((float) $value, 0, ',', '.');
?>
<div class="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 pb-5 border-b border-slate-800">
  <div>
    <a href="<?= base_url('admin/crm/estimasi') ?>" class="text-xs text-slate-400 hover:text-white">Pencatatan Pekerjaan Manual</a>
    <div class="mt-1 flex flex-wrap items-center gap-3">
      <h2 class="text-xl sm:text-2xl font-bold text-white">Catatan #EST-<?= str_pad((string) $estimasi['id_estimasi'], 5, '0', STR_PAD_LEFT) ?></h2>
      <span class="px-3 py-1 rounded-full text-[10px] uppercase font-bold bg-blue-500/10 border border-blue-500/20 text-blue-300"><?= esc(str_replace('_', ' ', $estimasi['status'])) ?></span>
    </div>
  </div>
  <div class="flex flex-wrap gap-2">
    <a href="<?= base_url('admin/crm/estimasi/edit/' . $estimasi['id_estimasi']) ?>" class="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold">Edit Catatan</a>
    <a href="<?= base_url('admin/crm/estimasi/pdf/' . $estimasi['id_estimasi']) ?>" target="_blank" class="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold">Unduh Laporan PDF</a>
    <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $estimasi['no_wa_customer']) ?>" target="_blank" rel="noopener noreferrer" class="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold">WhatsApp Customer</a>
  </div>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="p-3 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-300 text-sm"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('warning')): ?><div class="p-3 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-300 text-sm"><?= esc(session()->getFlashdata('warning')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="p-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-sm"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="grid grid-cols-1 xl:grid-cols-3 gap-5">
  <section class="xl:col-span-2 p-5 sm:p-6 rounded-2xl glass-card space-y-5">
    <div>
      <h3 class="text-sm font-bold text-white uppercase tracking-wider">Customer</h3>
      <div class="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
        <div><p class="text-xs text-slate-500">Nama</p><p class="text-white font-semibold"><?= esc($estimasi['nama_customer']) ?></p></div>
        <div><p class="text-xs text-slate-500">WhatsApp</p><p class="text-white"><?= esc($estimasi['no_wa_customer']) ?></p></div>
        <div><p class="text-xs text-slate-500">Akun</p><p class="text-white"><?= esc($estimasi['email_customer']) ?></p></div>
        <div><p class="text-xs text-slate-500">Tanggal dicatat</p><p class="text-white"><?= date('d/m/Y H:i', strtotime($estimasi['created_at'])) ?></p></div>
      </div>
    </div>
    <div class="pt-4 border-t border-slate-800">
      <h3 class="text-sm font-bold text-white uppercase tracking-wider">Pekerjaan dan Spesifikasi</h3>
      <div class="mt-3 grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
        <div><p class="text-xs text-slate-500">Jenis</p><p class="text-white"><?= esc($estimasi['nama_jenis_pekerjaan'] ?? 'Custom') ?></p></div>
        <div><p class="text-xs text-slate-500">Nama pekerjaan</p><p class="text-white font-semibold"><?= esc($estimasi['nama_pekerjaan'] ?: $estimasi['nama_jp']) ?></p></div>
        <div><p class="text-xs text-slate-500">Jumlah</p><p class="text-white"><?= esc($estimasi['qty_unit'] ?? '1') ?> unit</p></div>
        <div><p class="text-xs text-slate-500">Ukuran</p><p class="text-white"><?= esc($estimasi['panjang']) ?> × <?= esc($estimasi['lebar']) ?> × <?= esc($estimasi['tinggi'] ?: '-') ?> m</p></div>
        <div><p class="text-xs text-slate-500">Luas</p><p class="text-white"><?= esc($estimasi['luas']) ?> m²</p></div>
        <div><p class="text-xs text-slate-500">Ukuran per lubang</p><p class="text-white"><?= esc($estimasi['ukuran_lubang'] ?: '-') ?></p></div>
      </div>
      <div class="mt-4"><p class="text-xs text-slate-500">Material dan spesifikasi</p><p class="mt-1 text-sm text-white whitespace-pre-line"><?= esc($estimasi['material_custom'] ?: '-') ?></p></div>
    </div>
    <?php if (!empty($estimasi['catatan'])): ?>
      <div class="pt-4 border-t border-slate-800"><p class="text-xs text-slate-500">Catatan</p><p class="mt-1 text-sm text-slate-200 whitespace-pre-line"><?= esc($estimasi['catatan']) ?></p></div>
    <?php endif; ?>
  </section>

  <div class="space-y-5">
    <section class="p-5 sm:p-6 rounded-2xl glass-card">
      <h3 class="text-sm font-bold text-white uppercase tracking-wider">Nilai yang Dicatat Admin</h3>
      <dl class="mt-4 space-y-3 text-sm">
        <div class="flex justify-between gap-3"><dt class="text-slate-400">Harga bahan</dt><dd class="text-white font-mono"><?= $formatRupiah($estimasi['harga_bahan']) ?></dd></div>
        <div class="flex justify-between gap-3"><dt class="text-slate-400">Biaya jasa</dt><dd class="text-white font-mono"><?= $formatRupiah($estimasi['harga_jasa']) ?></dd></div>
        <div class="flex justify-between gap-3"><dt class="text-slate-400">Subtotal</dt><dd class="text-white font-mono"><?= $formatRupiah($estimasi['subtotal']) ?></dd></div>
        <div class="pt-3 border-t border-slate-700 flex justify-between gap-3"><dt class="text-emerald-300 font-bold">Nilai proyek dipakai</dt><dd class="text-emerald-300 font-mono font-bold"><?= $formatRupiah($nilaiProyek) ?></dd></div>
      </dl>
      <?php if (!empty($estimasi['tanggal_survey'])): ?><p class="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-400">Tanggal pekerjaan/survey: <?= date('d/m/Y H:i', strtotime($estimasi['tanggal_survey'])) ?></p><?php endif; ?>
      <?php if (!empty($estimasi['lokasi_survey'])): ?><p class="mt-2 text-xs text-slate-400">Lokasi: <?= esc($estimasi['lokasi_survey']) ?></p><?php endif; ?>
    </section>

    <?php if (!empty($existingProyek)): ?>
      <section class="p-5 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 space-y-3">
        <div class="flex items-start justify-between gap-3">
          <div>
            <h3 class="text-sm font-bold text-emerald-200">Proyek Sudah Disimpan</h3>
            <p class="mt-1 text-xs text-emerald-300/80 font-mono"><?= esc($existingProyek['kode_proyek']) ?></p>
          </div>
          <span class="px-2 py-1 rounded-lg bg-emerald-500/15 text-[10px] text-emerald-200 font-bold uppercase"><?= esc(str_replace('_', ' ', $existingProyek['status'])) ?></span>
        </div>
        <a href="<?= base_url('admin/crm/proyek/detail/' . $existingProyek['id_proyek']) ?>" class="block w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-center text-xs font-bold uppercase">Buka Detail Proyek</a>
      </section>
    <?php else: ?>
      <form method="POST" action="<?= base_url('admin/crm/estimasi/convert/' . $estimasi['id_estimasi']) ?>" class="p-5 rounded-2xl glass-card space-y-3">
        <?= csrf_field() ?>
        <div>
          <h3 class="text-sm font-bold text-white">Simpan Proyek</h3>
          <p class="mt-1 text-xs text-slate-400">Data pekerjaan ini akan masuk ke menu Proyek. Jika belum ada akun customer, sistem membuat akun customer otomatis dari nomor WhatsApp.</p>
        </div>
        <label class="block text-xs text-slate-400">DP customer (Rp)
          <input name="dp" type="number" min="0" max="<?= (int) $nilaiProyek ?>" step="1" value="0" required class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono" />
        </label>
        <button class="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase">Simpan Proyek</button>
      </form>
    <?php endif; ?>

    <form method="POST" action="<?= base_url('admin/crm/estimasi/alokasi/' . $estimasi['id_estimasi']) ?>" class="p-5 rounded-2xl glass-card space-y-3">
      <?= csrf_field() ?>
      <div>
        <h3 class="text-sm font-bold text-white">Alokasikan Pekerjaan</h3>
        <p class="mt-1 text-xs text-slate-400">Batas alokasi maksimal <?= $formatRupiah($nilaiProyek) ?>.</p>
      </div>
      <label class="block text-xs text-slate-400">Tukang
        <select name="id_tukang" <?= empty($existingProyek) ? 'disabled' : '' ?> required class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white">
          <option value="">Pilih tukang</option>
          <?php foreach ($tukangList as $tukang): ?>
            <option value="<?= (int) $tukang['id_user'] ?>" <?= !empty($existingProyek) && (int) ($existingProyek['id_tukang'] ?? 0) === (int) $tukang['id_user'] ? 'selected' : '' ?>>
              <?= esc($tukang['nama']) ?><?= !empty($tukang['no_wa']) ? ' - ' . esc($tukang['no_wa']) : '' ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="block text-xs text-slate-400">Nilai upah tukang (Rp)
        <input name="nilai_tukang" type="number" min="1" max="<?= (int) $nilaiProyek ?>" step="1" value="<?= (int) ($existingProyek['nilai_tukang'] ?? 0) ?>" <?= empty($existingProyek) ? 'disabled' : '' ?> required class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono" />
      </label>
      <label class="block text-xs text-slate-400">Bagian pekerjaan tukang
        <input name="pekerjaan_tukang" value="<?= esc($existingProyek['pekerjaan_tukang'] ?? '') ?>" <?= empty($existingProyek) ? 'disabled' : '' ?> placeholder="Contoh: fabrikasi rangka dan pemasangan" class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white" />
      </label>
      <div class="grid grid-cols-2 gap-3">
        <label class="block text-xs text-slate-400">Tanggal mulai
          <input name="tanggal_mulai" type="date" value="<?= esc($existingProyek['tanggal_mulai'] ?? date('Y-m-d')) ?>" <?= empty($existingProyek) ? 'disabled' : '' ?> class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white" />
        </label>
        <label class="block text-xs text-slate-400">Target selesai
          <input name="tanggal_target_selesai" type="date" value="<?= esc($existingProyek['tanggal_target_selesai'] ?? date('Y-m-d', strtotime('+14 days'))) ?>" <?= empty($existingProyek) ? 'disabled' : '' ?> class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white" />
        </label>
      </div>
      <button class="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold uppercase">Alokasikan Pekerjaan</button>
    </form>

    <?php if (!empty($existingProyek)): ?>
      <form method="POST" action="<?= base_url('admin/crm/estimasi/kasbon/' . $estimasi['id_estimasi']) ?>" enctype="multipart/form-data" class="p-5 rounded-2xl glass-card space-y-3">
        <?= csrf_field() ?>
        <div>
          <h3 class="text-sm font-bold text-white">Kasbon Tukang</h3>
          <p class="mt-1 text-xs text-slate-400">Total kasbon <?= $formatRupiah($totalKasbon ?? 0) ?>, sisa alokasi <?= $formatRupiah($sisaKasbon ?? 0) ?>.</p>
          <?php if (!$canKasbon): ?>
            <p class="mt-2 text-xs text-amber-300">Kasbon bisa dicatat setelah tukang dan nilai upah dialokasikan, serta masih ada sisa alokasi.</p>
          <?php endif; ?>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <label class="block text-xs text-slate-400">Nominal
            <input name="nominal" type="number" min="1" max="<?= (int) ($sisaKasbon ?? 0) ?>" step="1000" <?= !$canKasbon ? 'disabled' : '' ?> required class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono disabled:opacity-50" />
          </label>
          <label class="block text-xs text-slate-400">Tanggal
            <input name="tanggal_kasbon" type="date" value="<?= date('Y-m-d') ?>" <?= !$canKasbon ? 'disabled' : '' ?> required class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white disabled:opacity-50" />
          </label>
        </div>
        <label class="block text-xs text-slate-400">Metode pembayaran
          <select name="metode_pembayaran" <?= !$canKasbon ? 'disabled' : '' ?> class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white disabled:opacity-50">
            <option value="transfer">Transfer</option>
            <option value="tunai">Tunai</option>
            <option value="lainnya">Lainnya</option>
          </select>
        </label>
        <label class="block text-xs text-slate-400">Keterangan
          <textarea name="keterangan" rows="2" <?= !$canKasbon ? 'disabled' : '' ?> class="mt-1 w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white resize-none disabled:opacity-50"></textarea>
        </label>
        <label class="block text-xs text-slate-400">Bukti transfer
          <input type="file" name="bukti_transfer" accept="image/*,.pdf" <?= !$canKasbon ? 'disabled' : '' ?> class="mt-1 w-full text-xs text-slate-400 disabled:opacity-50 file:mr-3 file:rounded-lg file:border-0 file:bg-slate-800 file:px-3 file:py-2 file:text-xs file:font-semibold file:text-slate-200" />
        </label>
        <button <?= !$canKasbon ? 'disabled' : '' ?> class="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold uppercase">Simpan Kasbon</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<section class="p-5 sm:p-6 rounded-2xl glass-card space-y-4">
  <h3 class="text-sm font-bold text-white uppercase tracking-wider">Riwayat Follow Up</h3>
  <?php if (empty($followUps)): ?><p class="text-xs text-slate-500">Belum ada follow up.</p><?php else: ?>
    <div class="space-y-3">
      <?php foreach ($followUps as $followUp): ?>
        <div class="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs"><div class="flex justify-between gap-3"><strong class="text-white"><?= esc(strtoupper($followUp['metode'])) ?> · <?= esc($followUp['nama_admin']) ?></strong><span class="text-slate-500"><?= date('d/m/Y H:i', strtotime($followUp['tanggal_follow_up'])) ?></span></div><p class="mt-1 text-slate-300 whitespace-pre-line"><?= esc($followUp['hasil']) ?></p></div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <form method="POST" action="<?= base_url('admin/crm/follow-up/store') ?>" class="grid grid-cols-1 md:grid-cols-4 gap-3 pt-3 border-t border-slate-800">
    <?= csrf_field() ?><input type="hidden" name="id_estimasi" value="<?= $estimasi['id_estimasi'] ?>" />
    <select name="tipe" class="px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs"><option value="lainnya">Lainnya</option><option value="survey">Survey</option><option value="penawaran">Penawaran</option><option value="pembayaran">Pembayaran</option></select>
    <select name="metode" class="px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs"><option value="whatsapp">WhatsApp</option><option value="telepon">Telepon</option><option value="kunjungan">Kunjungan</option><option value="email">Email</option></select>
    <input name="hasil" required placeholder="Catatan komunikasi" class="px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs" />
    <button class="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold">Tambah Follow Up</button>
  </form>
</section>
<?= $this->endSection() ?>
