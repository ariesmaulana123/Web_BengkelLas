<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>
<?php
  $isEdit = !empty($estimasi);
  $field = static fn (string $name, mixed $fallback = '') => old($name, $fallback);
  $dateValue = $estimasi['tanggal_survey'] ?? date('Y-m-d H:i:s');
?>

<div class="flex items-center justify-between gap-4 pb-4 border-b border-slate-800">
  <div>
    <a href="<?= base_url('admin/crm/estimasi') ?>" class="text-xs text-slate-400 hover:text-white">Kembali ke Pencatatan Pekerjaan</a>
    <h2 class="mt-1 text-xl font-bold text-white font-display"><?= $isEdit ? 'Edit Pekerjaan Manual' : 'Catat Pekerjaan Manual' ?></h2>
    <p class="mt-1 text-xs text-slate-400">Masukkan spesifikasi dan nominal sesuai kesepakatan Admin dengan customer.</p>
  </div>
</div>

<?php if (session()->getFlashdata('error')): ?>
  <div class="p-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-sm"><?= esc(session()->getFlashdata('error')) ?></div>
<?php endif; ?>
<?php if (session()->getFlashdata('errors')): ?>
  <div class="p-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-sm space-y-1">
    <?php foreach (session()->getFlashdata('errors') as $error): ?><p><?= esc($error) ?></p><?php endforeach; ?>
  </div>
<?php endif; ?>

<form method="POST" action="<?= base_url($isEdit ? 'admin/crm/estimasi/update/' . $estimasi['id_estimasi'] : 'admin/crm/estimasi/store') ?>" class="space-y-6">
  <?= csrf_field() ?>

  <section class="p-5 sm:p-6 rounded-2xl glass-card space-y-4">
    <h3 class="text-sm font-bold text-white uppercase tracking-wider">Customer</h3>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div>
        <label for="nama_customer_manual" class="block text-xs text-slate-300 mb-1.5">Nama customer *</label>
        <input id="nama_customer_manual" name="nama_customer_manual" required maxlength="150" value="<?= esc($field('nama_customer_manual', $estimasi['nama_customer_manual'] ?? '')) ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white" />
      </div>
      <div>
        <label for="no_wa_manual" class="block text-xs text-slate-300 mb-1.5">WhatsApp *</label>
        <input id="no_wa_manual" name="no_wa_manual" required maxlength="30" value="<?= esc($field('no_wa_manual', $estimasi['no_wa_manual'] ?? '')) ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white" />
      </div>
      <div>
        <label for="id_user" class="block text-xs text-slate-300 mb-1.5">Akun customer (opsional)</label>
        <select id="id_user" name="id_user" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white">
          <option value="">Catatan manual tanpa akun</option>
          <?php foreach ($customerList as $customer): ?>
            <option value="<?= $customer['id_user'] ?>" <?= (string) $field('id_user', $estimasi['id_user'] ?? '') === (string) $customer['id_user'] ? 'selected' : '' ?>><?= esc($customer['nama']) ?> · <?= esc($customer['no_wa']) ?></option>
          <?php endforeach; ?>
        </select>
        <p class="mt-1 text-[10px] text-slate-500">Akun terhubung dapat dipakai untuk membuat proyek dan menampilkan catatan di riwayat customer.</p>
      </div>
    </div>
  </section>

  <section class="p-5 sm:p-6 rounded-2xl glass-card space-y-4">
    <h3 class="text-sm font-bold text-white uppercase tracking-wider">Detail Pekerjaan</h3>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label for="id_jp" class="block text-xs text-slate-300 mb-1.5">Jenis pekerjaan</label>
        <select id="id_jp" name="id_jp" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white">
          <option value="">Jenis lain / custom</option>
          <?php foreach ($jenisList as $jenis): ?>
            <option value="<?= $jenis['id_jp'] ?>" <?= (string) $field('id_jp', $estimasi['id_jp'] ?? '') === (string) $jenis['id_jp'] ? 'selected' : '' ?>><?= esc($jenis['nama']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label for="nama_pekerjaan" class="block text-xs text-slate-300 mb-1.5">Nama pekerjaan *</label>
        <input id="nama_pekerjaan" name="nama_pekerjaan" required maxlength="255" value="<?= esc($field('nama_pekerjaan', $estimasi['nama_pekerjaan'] ?? '')) ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white" />
      </div>
      <div>
        <label for="material_custom" class="block text-xs text-slate-300 mb-1.5">Material dan spesifikasi *</label>
        <textarea id="material_custom" name="material_custom" required rows="3" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white"><?= esc($field('material_custom', $estimasi['material_custom'] ?? '')) ?></textarea>
      </div>
      <div>
        <label for="ukuran_lubang" class="block text-xs text-slate-300 mb-1.5">Ukuran per lubang (opsional)</label>
        <input id="ukuran_lubang" name="ukuran_lubang" maxlength="100" value="<?= esc($field('ukuran_lubang', $estimasi['ukuran_lubang'] ?? '')) ?>" placeholder="Contoh: 120 x 90 cm, 4 lubang" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white" />
      </div>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
      <?php foreach (['panjang' => 'Panjang (m)', 'lebar' => 'Lebar (m)', 'tinggi' => 'Tinggi (m)', 'luas' => 'Total luas (m²)'] as $name => $label): ?>
        <div>
          <label for="<?= $name ?>" class="block text-xs text-slate-300 mb-1.5"><?= $label ?><?= in_array($name, ['panjang', 'lebar', 'luas'], true) ? ' *' : '' ?></label>
          <input id="<?= $name ?>" name="<?= $name ?>" type="number" min="0" step="0.01" <?= in_array($name, ['panjang', 'lebar', 'luas'], true) ? 'required' : '' ?> value="<?= esc($field($name, $estimasi[$name] ?? '')) ?>" class="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white" />
        </div>
      <?php endforeach; ?>
      <div>
        <label for="qty_unit" class="block text-xs text-slate-300 mb-1.5">Jumlah unit *</label>
        <input id="qty_unit" name="qty_unit" required maxlength="100" value="<?= esc($field('qty_unit', $estimasi['qty_unit'] ?? '1')) ?>" class="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white" />
      </div>
    </div>
  </section>

  <section class="p-5 sm:p-6 rounded-2xl glass-card space-y-4">
    <h3 class="text-sm font-bold text-white uppercase tracking-wider">Harga Manual Admin</h3>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <?php foreach (['harga_bahan' => 'Harga bahan (Rp)', 'harga_jasa' => 'Biaya jasa (Rp)', 'subtotal' => 'Subtotal (Rp)', 'total_final' => 'Harga final / total (Rp)'] as $name => $label): ?>
        <div>
          <label for="<?= $name ?>" class="block text-xs text-slate-300 mb-1.5"><?= $label ?> *</label>
          <input id="<?= $name ?>" name="<?= $name ?>" type="number" min="0" step="1" required value="<?= esc($field($name, $estimasi[$name] ?? '0')) ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm font-mono text-white" />
        </div>
      <?php endforeach; ?>
    </div>
    <p class="text-[11px] text-slate-500">Nominal disimpan sesuai input Admin dan tidak dihitung otomatis.</p>
  </section>

  <section class="p-5 sm:p-6 rounded-2xl glass-card space-y-4">
    <h3 class="text-sm font-bold text-white uppercase tracking-wider">Tanggal, Status, dan Catatan</h3>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div>
        <label for="tanggal_survey" class="block text-xs text-slate-300 mb-1.5">Tanggal pekerjaan / survey</label>
        <input id="tanggal_survey" name="tanggal_survey" type="datetime-local" value="<?= esc($field('tanggal_survey', date('Y-m-d\\TH:i', strtotime($dateValue)))) ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white" />
      </div>
      <div>
        <label for="status" class="block text-xs text-slate-300 mb-1.5">Status *</label>
        <?php $selectedStatus = $field('status', $estimasi['status'] ?? 'deal'); ?>
        <select id="status" name="status" required class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white">
          <?php foreach (['baru' => 'Baru', 'dihubungi' => 'Dihubungi', 'survey' => 'Survey', 'penawaran' => 'Penawaran', 'deal' => 'Deal', 'ditolak' => 'Ditolak'] as $value => $label): ?>
            <option value="<?= $value ?>" <?= $selectedStatus === $value ? 'selected' : '' ?>><?= $label ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label for="catatan" class="block text-xs text-slate-300 mb-1.5">Catatan</label>
        <textarea id="catatan" name="catatan" rows="2" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white"><?= esc($field('catatan', $estimasi['catatan'] ?? '')) ?></textarea>
      </div>
      <div>
        <label for="lokasi_survey" class="block text-xs text-slate-300 mb-1.5">Alamat / lokasi pekerjaan</label>
        <textarea id="lokasi_survey" name="lokasi_survey" rows="2" class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white"><?= esc($field('lokasi_survey', $estimasi['lokasi_survey'] ?? '')) ?></textarea>
      </div>
    </div>
  </section>

  <div class="flex justify-end gap-3">
    <a href="<?= base_url('admin/crm/estimasi') ?>" class="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold">Batal</a>
    <button type="submit" class="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider"><?= $isEdit ? 'Simpan Perubahan' : 'Simpan Catatan' ?></button>
  </div>
</form>
<?= $this->endSection() ?>