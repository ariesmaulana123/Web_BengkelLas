<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<!-- Header -->
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
  <div>
    <h2 class="text-xl font-bold text-white font-display">Aktivitas Follow Up Customer</h2>
    <p class="text-xs text-slate-400">Catatan kronologis koordinasi survey, konfirmasi penawaran, dan penagihan proyek.</p>
  </div>
  <span class="text-xs font-mono text-slate-400">Total: <strong class="text-white"><?= count($list) ?></strong> Aktivitas</span>
</div>

<!-- Table Card -->
<div class="rounded-2xl glass-card overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-left text-xs text-slate-300">
      <thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
        <tr>
          <th class="py-3.5 px-4">Waktu</th>
          <th class="py-3.5 px-4">Tipe & Media</th>
          <th class="py-3.5 px-4">Customer / Proyek</th>
          <th class="py-3.5 px-4">Hasil Komunikasi</th>
          <th class="py-3.5 px-4">PIC Admin</th>
          <th class="py-3.5 px-4">Follow Up Lanjutan</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-800/60">
        <?php if (empty($list)): ?>
          <tr>
            <td colspan="6" class="py-12 text-center text-slate-400 italic">Belum ada catatan aktivitas follow up.</td>
          </tr>
        <?php else: ?>
          <?php foreach ($list as $fu): ?>
            <tr class="hover:bg-slate-800/30 transition-colors">
              <td class="py-3.5 px-4 font-mono text-slate-400">
                <?= date('d/m/Y H:i', strtotime($fu['tanggal_follow_up'])) ?>
              </td>
              <td class="py-3.5 px-4">
                <span class="px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  <?= esc($fu['tipe']) ?>
                </span>
                <span class="text-slate-400 text-[10px] block mt-1 uppercase font-mono"><?= esc($fu['metode']) ?></span>
              </td>
              <td class="py-3.5 px-4">
                <?php if ($fu['nama_customer']): ?>
                  <p class="font-bold text-white"><?= esc($fu['nama_customer']) ?></p>
                  <p class="text-[10px] text-slate-400 font-mono"><?= esc($fu['no_wa_customer']) ?></p>
                <?php elseif ($fu['kode_proyek']): ?>
                  <p class="font-bold text-white"><?= esc($fu['nama_proyek']) ?></p>
                  <p class="text-[10px] text-blue-400 font-mono"><?= esc($fu['kode_proyek']) ?></p>
                <?php else: ?>
                  <span class="text-slate-500">-</span>
                <?php endif; ?>
              </td>
              <td class="py-3.5 px-4 max-w-sm">
                <p class="text-slate-200 leading-relaxed"><?= nl2br(esc($fu['hasil'])) ?></p>
              </td>
              <td class="py-3.5 px-4 font-semibold text-slate-300">
                <?= esc($fu['nama_admin']) ?>
              </td>
              <td class="py-3.5 px-4 font-mono text-[11px]">
                <?php if ($fu['tanggal_next_follow_up']): ?>
                  <span class="text-amber-400 font-bold"><?= date('d/m/Y H:i', strtotime($fu['tanggal_next_follow_up'])) ?></span>
                <?php else: ?>
                  <span class="text-slate-600">-</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection() ?>