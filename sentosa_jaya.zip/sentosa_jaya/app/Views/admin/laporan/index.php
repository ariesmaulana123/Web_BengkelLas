<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<!-- Header & Date Range Filter (Hidden during print) -->
<div class="no-print flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
  <div>
    <h2 class="text-xl font-bold text-white font-display">Laporan Penjualan & Proyek</h2>
    <p class="text-xs text-slate-400">Periode: <?= date('d M Y', strtotime($startDate)) ?> s/d <?= date('d M Y', strtotime($endDate)) ?></p>
  </div>

  <div class="flex items-center space-x-3">
    <!-- Tombol Cetak PDF Resmi (Dompdf) -->
    <a 
      href="<?= base_url('admin/laporan/pdf?start_date=' . $startDate . '&end_date=' . $endDate) ?>" 
      target="_blank" 
      class="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider flex items-center space-x-2 shadow-lg shadow-blue-600/30 hover:shadow-blue-500/50 hover:-translate-y-0.5 transition-all"
    >
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
      </svg>
      <span>Cetak Laporan (PDF Resmi)</span>
    </a>
  </div>
</div>

<!-- Date Filter Form (Hidden during print) -->
<div class="no-print p-4 rounded-2xl glass-card">
  <form method="GET" action="<?= base_url('admin/laporan') ?>" class="flex flex-wrap items-center gap-3">
    <div class="flex items-center space-x-2 text-xs text-slate-300">
      <span>Dari Tanggal:</span>
      <input type="date" name="start_date" value="<?= esc($startDate) ?>" class="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs">
    </div>
    <div class="flex items-center space-x-2 text-xs text-slate-300">
      <span>Sampai Tanggal:</span>
      <input type="date" name="end_date" value="<?= esc($endDate) ?>" class="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs">
    </div>
    <button type="submit" class="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider">
      Tampilkan
    </button>
  </form>
</div>

<!-- Printable Area Container -->
<div id="printable-report-section" class="space-y-6">

  <!-- Kop Surat (Only Visible during Browser Print) -->
  <div class="hidden print:block pb-4 mb-6 border-b-2 border-slate-900">
    <div class="flex items-start justify-between">
      <div>
        <h1 class="text-2xl font-black uppercase text-slate-900 tracking-tight font-display">SENTOSA JAYA LAS</h1>
        <p class="text-xs text-slate-600">Spesialis Fabrikasi Besi, Konstruksi Baja WF, Kanopi & Pagar</p>
        <p class="text-[10px] text-slate-500 mt-1">Jl. Raya Setu, Kec. Setu, Kabupaten Bekasi, Jawa Barat 17320</p>
      </div>
      <div class="text-right text-[10px] text-slate-600 space-y-0.5">
        <p><strong>WhatsApp:</strong> <?= esc($companySettings['no_wa'] ?? '087766364557') ?></p>
        <p><strong>Email:</strong> <?= esc($companySettings['email'] ?? 'sentosajayalas.1@gmail.com') ?></p>
        <p><strong>Website:</strong> www.sentosajayalas.com</p>
      </div>
    </div>
    <div class="text-center mt-4 pt-3 border-t border-slate-300">
      <h2 class="text-base font-bold uppercase tracking-wider text-slate-900">Laporan Rekapitulasi Penjualan & Proyek</h2>
      <p class="text-xs text-slate-600">Periode: <?= date('d F Y', strtotime($startDate)) ?> s/d <?= date('d F Y', strtotime($endDate)) ?></p>
    </div>
  </div>

  <!-- Summary Stats -->
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 print:grid-cols-4">
    <div class="p-5 rounded-2xl glass-card print:border print:border-slate-300 print:bg-slate-50 print:p-3">
      <span class="text-[10px] font-mono text-slate-400 print:text-slate-600 uppercase">Omzet Kontrak Proyek</span>
      <p class="text-xl font-bold text-white print:text-slate-900 font-mono mt-1">Rp <?= number_format($proyekStats['omzet'] ?? 0, 0, ',', '.') ?></p>
      <p class="text-[11px] text-slate-400 print:text-slate-500 mt-1"><?= (int)($proyekStats['total_proyek'] ?? 0) ?> Proyek Deal</p>
    </div>

    <div class="p-5 rounded-2xl glass-card print:border print:border-slate-300 print:bg-slate-50 print:p-3">
      <span class="text-[10px] font-mono text-slate-400 print:text-slate-600 uppercase">Total Uang Muka Masuk</span>
      <p class="text-xl font-bold text-emerald-400 print:text-emerald-700 font-mono mt-1">Rp <?= number_format($proyekStats['total_dp'] ?? 0, 0, ',', '.') ?></p>
      <p class="text-[11px] text-slate-400 print:text-slate-500 mt-1">Penerimaan DP Workshop</p>
    </div>

    <div class="p-5 rounded-2xl glass-card print:border print:border-slate-300 print:bg-slate-50 print:p-3">
      <span class="text-[10px] font-mono text-slate-400 print:text-slate-600 uppercase">Sisa Piutang Berjalan</span>
      <p class="text-xl font-bold text-amber-400 print:text-amber-700 font-mono mt-1">Rp <?= number_format($proyekStats['total_piutang'] ?? 0, 0, ',', '.') ?></p>
      <p class="text-[11px] text-slate-400 print:text-slate-500 mt-1">Pelunasan saat serah terima</p>
    </div>

    <div class="p-5 rounded-2xl glass-card print:border print:border-slate-300 print:bg-slate-50 print:p-3">
      <span class="text-[10px] font-mono text-slate-400 print:text-slate-600 uppercase">Total Estimasi Masuk</span>
      <p class="text-xl font-bold text-blue-400 print:text-blue-700 font-mono mt-1"><?= number_format($totalEstimasi) ?></p>
      <p class="text-[11px] text-slate-400 print:text-slate-500 mt-1">Kalkulasi di Landing Page</p>
    </div>
  </div>

  <!-- Breakdown Proyek dalam Periode -->
  <div class="space-y-3">
    <h3 class="text-base font-bold text-white print:text-slate-900 font-display">Rekapitulasi Proyek Periode Ini</h3>
    <div class="rounded-2xl glass-card overflow-hidden print:border print:border-slate-300">
      <table class="w-full text-left text-xs text-slate-300 print:text-slate-800">
        <thead class="bg-slate-900/90 print:bg-slate-800 text-slate-400 print:text-white font-mono uppercase tracking-wider text-[10px] border-b border-slate-800 print:border-slate-800">
          <tr>
            <th class="py-3 px-4">Tanggal</th>
            <th class="py-3 px-4">Kode Proyek</th>
            <th class="py-3 px-4">Customer</th>
            <th class="py-3 px-4">Pekerjaan</th>
            <th class="py-3 px-4">Nilai Kontrak</th>
            <th class="py-3 px-4">DP</th>
            <th class="py-3 px-4">Status</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-800/60 print:divide-slate-200">
          <?php if (empty($proyekList)): ?>
            <tr><td colspan="7" class="py-8 text-center text-slate-400 print:text-slate-500 italic">Tidak ada proyek dalam rentang tanggal ini.</td></tr>
          <?php else: ?>
            <?php foreach ($proyekList as $p): ?>
              <tr class="print:even:bg-slate-50">
                <td class="py-3 px-4 font-mono text-slate-400 print:text-slate-600"><?= date('d/m/Y', strtotime($p['created_at'])) ?></td>
                <td class="py-3 px-4 font-mono font-bold text-blue-400 print:text-blue-700"><?= esc($p['kode_proyek']) ?></td>
                <td class="py-3 px-4 font-bold text-white print:text-slate-900"><?= esc($p['nama_customer']) ?></td>
                <td class="py-3 px-4 text-slate-300 print:text-slate-700"><?= esc($p['nama_jp']) ?></td>
                <td class="py-3 px-4 font-mono font-bold text-emerald-400 print:text-emerald-700">Rp <?= number_format($p['nilai_proyek'], 0, ',', '.') ?></td>
                <td class="py-3 px-4 font-mono text-slate-300 print:text-slate-700">Rp <?= number_format($p['dp'], 0, ',', '.') ?></td>
                <td class="py-3 px-4 uppercase font-mono text-[10px] print:text-slate-800"><?= esc($p['status']) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Kolom Tanda Tangan (Only Visible during Browser Print) -->
  <div class="hidden print:block pt-8 mt-12 page-break-inside-avoid">
    <div class="grid grid-cols-2 text-center text-xs text-slate-800">
      <div>
        <p class="text-slate-600">Dibuat & Disusun Oleh:</p>
        <p class="font-bold text-slate-900 mt-0.5">Bagian Administrasi & Keuangan</p>
        <div class="h-16"></div>
        <p class="font-bold underline text-slate-900">( <?= esc(session()->get('nama') ?? 'Administrator') ?> )</p>
        <p class="text-[10px] text-slate-500"><?= ucfirst(esc(session()->get('role') ?? 'Admin')) ?> Sentosa Jaya Las</p>
      </div>
      <div>
        <p class="text-slate-600">Bekasi, <?= date('d F Y') ?></p>
        <p class="font-bold text-slate-900 mt-0.5">Mengetahui & Menyetujui,</p>
        <div class="h-16"></div>
        <p class="font-bold underline text-slate-900">( <?= esc($companySettings['nama_penanggung_jawab'] ?? 'Bambang Sentosa') ?> )</p>
        <p class="text-[10px] text-slate-500"><?= esc($companySettings['jabatan_penanggung_jawab'] ?? 'Kepala Workshop') ?></p>
      </div>
    </div>
  </div>

</div>

<!-- Print Stylesheet Override -->
<style>
  @media print {
    /* Hide admin sidebar, navbar, footer, actions, debug bar */
    #admin-sidebar, 
    #sidebar-overlay,
    header, 
    footer, 
    .no-print,
    .debug-bar,
    #debug-bar,
    .ci-debugbar {
      display: none !important;
    }
    
    body, html {
      background: #ffffff !important;
      color: #0f172a !important;
    }
    
    main {
      padding: 0 !important;
      background: #ffffff !important;
    }
    
    .lg\:pl-72 {
      padding-left: 0 !important;
    }
    
    .glass-card {
      background: transparent !important;
      backdrop-filter: none !important;
    }
    
    .page-break-inside-avoid {
      page-break-inside: avoid;
    }
  }
</style>

<?= $this->endSection() ?>
