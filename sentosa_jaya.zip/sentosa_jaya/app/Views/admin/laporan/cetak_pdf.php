<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Laporan Penjualan & Proyek - Sentosa Jaya Las</title>
  <style>
    * { box-sizing: border-box; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
    body { font-size: 10.5px; color: #1e293b; line-height: 1.4; margin: 0; padding: 15px 20px; }
    
    /* Kop Surat */
    .header-table { width: 100%; border-bottom: 2.5px solid #0369a1; padding-bottom: 10px; margin-bottom: 12px; }
    .company-title { font-size: 18px; font-weight: bold; color: #0369a1; text-transform: uppercase; margin: 0; letter-spacing: 0.5px; }
    .company-tagline { font-size: 9.5px; color: #64748b; margin-top: 2px; }
    .company-contact { font-size: 9px; color: #475569; text-align: right; line-height: 1.35; }
    
    /* Judul Dokumen */
    .doc-title-wrapper { text-align: center; margin: 12px 0 14px 0; }
    .doc-title { font-size: 14px; font-weight: bold; text-transform: uppercase; color: #0f172a; letter-spacing: 0.5px; }
    .doc-period { font-size: 10px; color: #475569; margin-top: 3px; }
    
    /* Metadata Print */
    .meta-table { width: 100%; font-size: 9px; color: #64748b; margin-bottom: 12px; border-bottom: 1px dashed #cbd5e1; padding-bottom: 5px; }
    
    /* Ringkasan Eksekutif */
    .summary-grid { width: 100%; margin-bottom: 16px; border-collapse: collapse; }
    .summary-card { width: 25%; padding: 8px 10px; background: #f8fafc; border: 1px solid #e2e8f0; vertical-align: top; border-radius: 4px; }
    .summary-card-title { font-size: 8px; font-weight: bold; text-transform: uppercase; color: #64748b; letter-spacing: 0.3px; }
    .summary-card-val { font-size: 13px; font-weight: bold; margin-top: 4px; font-family: 'Courier New', Courier, monospace; }
    .summary-card-sub { font-size: 8px; color: #94a3b8; margin-top: 2px; }
    
    /* Tabel Data */
    .section-heading { font-size: 11px; font-weight: bold; color: #0f172a; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.3px; border-left: 3px solid #0284c7; padding-left: 6px; }
    .data-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 9.5px; }
    .data-table th { background: #0f172a; color: #ffffff; padding: 6px 7px; text-transform: uppercase; font-size: 8.5px; letter-spacing: 0.3px; border: 1px solid #0f172a; }
    .data-table td { padding: 5.5px 7px; border: 1px solid #e2e8f0; vertical-align: middle; }
    .data-table tr:nth-child(even) td { background: #f8fafc; }
    .data-table .total-row td { background: #f0f9ff; font-weight: bold; border-top: 2px solid #0284c7; border-bottom: 2px solid #0284c7; color: #0369a1; }
    
    /* Utilities */
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .font-bold { font-weight: bold; }
    .font-mono { font-family: 'Courier New', Courier, monospace; }
    
    /* Status Badges */
    .badge { font-size: 8px; font-weight: bold; text-transform: uppercase; padding: 2px 4px; border-radius: 3px; }
    .badge-deal { background: #dcfce7; color: #15803d; }
    .badge-progress { background: #dbeafe; color: #1d4ed8; }
    .badge-selesai { background: #e0e7ff; color: #4338ca; }
    .badge-batal { background: #fee2e2; color: #b91c1c; }
    
    /* Tanda Tangan */
    .signature-table { width: 100%; text-align: center; margin-top: 25px; page-break-inside: avoid; }
    .signature-space { height: 60px; }
  </style>
</head>
<body>

  <!-- Kop Surat Perusahaan -->
  <table class="header-table">
    <tr>
      <td style="width: 60%; vertical-align: middle;">
        <h1 class="company-title"><?= esc($settings['nama_perusahaan'] ?? 'SENTOSA JAYA LAS') ?></h1>
        <p class="company-tagline"><?= esc($settings['tagline'] ?? 'Bengkel Las & Konstruksi Baja Presisi Bergaransi') ?></p>
        <p style="font-size: 8.5px; color: #475569; margin-top: 3px;"><?= esc($settings['alamat'] ?? 'Jl. Raya Setu, Kec. Setu, Kabupaten Bekasi, Jawa Barat 17320') ?></p>
      </td>
      <td class="company-contact" style="width: 40%; vertical-align: middle;">
        <p><strong>WhatsApp / Telp:</strong> <?= esc($settings['no_wa'] ?? '+62 877-6636-4557') ?></p>
        <p><strong>Email Resmi:</strong> <?= esc($settings['email'] ?? 'kontak@sentosajayalas.com') ?></p>
        <p><strong>Website:</strong> https://sentosajayalas.my.id/</p>
      </td>
    </tr>
  </table>

  <!-- Judul Laporan -->
  <div class="doc-title-wrapper">
    <div class="doc-title">Laporan Rekapitulasi Penjualan & Proyek</div>
    <div class="doc-period">Periode: <strong><?= date('d F Y', strtotime($startDate)) ?></strong> s/d <strong><?= date('d F Y', strtotime($endDate)) ?></strong></div>
  </div>

  <!-- Metadata Cetak -->
  <table class="meta-table">
    <tr>
      <td style="width: 50%;">Dicetak Oleh: <strong><?= esc($adminName) ?></strong> (<?= ucfirst(esc($adminRole)) ?>)</td>
      <td style="width: 50%; text-align: right;">Waktu Cetak: <strong><?= date('d/m/Y H:i') ?> WIB</strong></td>
    </tr>
  </table>

  <!-- Ringkasan Eksekutif Keuangan & Volume -->
  <table class="summary-grid">
    <tr>
      <td class="summary-card" style="border-left: 3px solid #0284c7;">
        <div class="summary-card-title">Omzet Kontrak Proyek</div>
        <div class="summary-card-val" style="color: #0f172a;">Rp <?= number_format($proyekStats['omzet'] ?? 0, 0, ',', '.') ?></div>
        <div class="summary-card-sub"><?= (int)($proyekStats['total_proyek'] ?? 0) ?> Proyek Disepakati (Deal)</div>
      </td>
      <td style="width: 2%;"></td>
      <td class="summary-card" style="border-left: 3px solid #16a34a;">
        <div class="summary-card-title">Total Uang Muka (DP)</div>
        <div class="summary-card-val" style="color: #16a34a;">Rp <?= number_format($proyekStats['total_dp'] ?? 0, 0, ',', '.') ?></div>
        <div class="summary-card-sub">Penerimaan DP Kas/Bank</div>
      </td>
      <td style="width: 2%;"></td>
      <td class="summary-card" style="border-left: 3px solid #6366f1;">
        <div class="summary-card-title">Sisa Piutang Berjalan</div>
        <div class="summary-card-val" style="color: #6366f1;">Rp <?= number_format($proyekStats['total_piutang'] ?? 0, 0, ',', '.') ?></div>
        <div class="summary-card-sub">Pelunasan saat serah terima</div>
      </td>
      <td style="width: 2%;"></td>
      <td class="summary-card" style="border-left: 3px solid #6366f1;">
        <div class="summary-card-title">Total Estimasi Masuk</div>
        <div class="summary-card-val" style="color: #4f46e5;"><?= number_format($totalEstimasi) ?></div>
        <div class="summary-card-sub">Kalkulasi & Survey Masuk</div>
      </td>
    </tr>
  </table>

  <!-- Tabel 1: Rekapitulasi Proyek Terinci -->
  <div class="section-heading">1. Rekapitulasi Transaksi Proyek Periode Ini</div>
  <table class="data-table">
    <thead>
      <tr>
        <th style="width: 4%; text-align: center;">No</th>
        <th style="width: 10%;">Tanggal</th>
        <th style="width: 13%;">Kode Proyek</th>
        <th style="width: 20%;">Customer</th>
        <th style="width: 18%;">Pekerjaan</th>
        <th style="width: 13%; text-align: right;">Nilai Kontrak</th>
        <th style="width: 11%; text-align: right;">DP Masuk</th>
        <th style="width: 11%; text-align: center;">Status</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($proyekList)): ?>
        <tr>
          <td colspan="8" class="text-center" style="padding: 15px; color: #94a3b8; font-style: italic;">
            Tidak ada transaksi proyek pada rentang tanggal ini.
          </td>
        </tr>
      <?php else: ?>
        <?php 
          $no = 1;
          $sumNilai = 0;
          $sumDP = 0;
          foreach ($proyekList as $p): 
            $sumNilai += (float) $p['nilai_proyek'];
            $sumDP += (float) $p['dp'];
        ?>
          <tr>
            <td class="text-center font-mono"><?= $no++ ?></td>
            <td class="font-mono"><?= date('d/m/Y', strtotime($p['created_at'])) ?></td>
            <td class="font-mono font-bold" style="color: #0284c7;"><?= esc($p['kode_proyek']) ?></td>
            <td><strong><?= esc($p['nama_customer']) ?></strong></td>
            <td><?= esc($p['nama_jp'] ?? '-') ?></td>
            <td class="text-right font-mono font-bold">Rp <?= number_format($p['nilai_proyek'], 0, ',', '.') ?></td>
            <td class="text-right font-mono" style="color: #16a34a;">Rp <?= number_format($p['dp'], 0, ',', '.') ?></td>
            <td class="text-center uppercase" style="font-size: 8px; font-weight: bold;"><?= esc($p['status']) ?></td>
          </tr>
        <?php endforeach; ?>
        
        <!-- Total Row -->
        <tr class="total-row">
          <td colspan="5" style="text-align: right; text-transform: uppercase;">TOTAL KESELURUHAN:</td>
          <td class="text-right font-mono">Rp <?= number_format($sumNilai, 0, ',', '.') ?></td>
          <td class="text-right font-mono">Rp <?= number_format($sumDP, 0, ',', '.') ?></td>
          <td class="text-center font-mono"><?= count($proyekList) ?> Proyek</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>

  <!-- Tabel 2: Rekapitulasi Estimasi Permintaan Pekerjaan (Jika ada) -->
  <?php if (!empty($jpStats)): ?>
    <div class="section-heading" style="margin-top: 15px;">2. Rekapitulasi Permintaan Estimasi per Kategori Pekerjaan</div>
    <table class="data-table" style="width: 70%;">
      <thead>
        <tr>
          <th style="width: 8%; text-align: center;">No</th>
          <th style="width: 52%;">Jenis Pekerjaan Fabrikasi</th>
          <th style="width: 20%; text-align: center;">Jumlah Pengajuan</th>
          <th style="width: 20%; text-align: right;">Total Nilai Estimasi</th>
        </tr>
      </thead>
      <tbody>
        <?php $n = 1; foreach ($jpStats as $jp): ?>
          <tr>
            <td class="text-center font-mono"><?= $n++ ?></td>
            <td><strong><?= esc($jp['nama'] ?? 'Custom / Lainnya') ?></strong></td>
            <td class="text-center font-mono"><?= (int) $jp['total'] ?> Pengajuan</td>
            <td class="text-right font-mono">Rp <?= number_format((float) ($jp['total_nilai'] ?? 0), 0, ',', '.') ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>

  <!-- Kolom Tanda Tangan Resmi -->
  <table class="signature-table">
    <tr>
      <td style="width: 50%;">
        <p style="margin: 0; font-size: 9.5px; color: #475569;">Dibuat & Disusun Oleh:</p>
        <p style="margin: 2px 0 0 0; font-size: 9.5px; font-weight: bold; color: #0f172a;">Bagian Administrasi & Keuangan</p>
        <div class="signature-space"></div>
        <strong style="text-decoration: underline; font-size: 10.5px;">( <?= esc($adminName) ?> )</strong><br>
        <span style="font-size: 8.5px; color: #64748b;"><?= ucfirst(esc($adminRole)) ?> Sentosa Jaya Las</span>
      </td>
      <td style="width: 50%;">
        <p style="margin: 0; font-size: 9.5px; color: #475569;">Bekasi, <?= date('d F Y') ?></p>
        <p style="margin: 2px 0 0 0; font-size: 9.5px; font-weight: bold; color: #0f172a;">Mengetahui & Menyetujui,</p>
        <div class="signature-space"></div>
        <strong style="text-decoration: underline; font-size: 10.5px;">( <?= esc($settings['nama_penanggung_jawab'] ?? 'Bambang Sentosa') ?> )</strong><br>
        <span style="font-size: 8.5px; color: #64748b;"><?= esc($settings['jabatan_penanggung_jawab'] ?? 'Kepala Workshop') ?></span>
      </td>
    </tr>
  </table>

</body>
</html>

