<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<!-- Header & Add Button -->
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
  <div>
    <h2 class="text-xl font-bold text-white font-display">Manajemen Role & Pengguna</h2>
    <p class="text-xs text-slate-400">Atur hak akses Administrator, Tukang Bengkel, dan Pelanggan.</p>
  </div>
  <button 
    type="button" 
    onclick="openModalAddUser()"
    class="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-blue-600/30 hover:-translate-y-0.5 transition-all"
  >
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
    </svg>
    <span>Tambah Pengguna Baru</span>
  </button>
</div>

<!-- Filter Bar -->
<div class="p-4 rounded-2xl glass-card flex flex-wrap items-center justify-between gap-3">
  <form method="GET" action="<?= base_url('admin/users') ?>" class="flex flex-wrap items-center gap-3 w-full sm:w-auto">
    <select name="role" onchange="this.form.submit()" class="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200">
      <option value="">-- Semua Role Akses --</option>
      <option value="admin" <?= $roleFilter === 'admin' ? 'selected' : '' ?>>Administrator (Akses Penuh)</option>
      <option value="tukang" <?= $roleFilter === 'tukang' ? 'selected' : '' ?>>Tukang Las (Hanya Proyek)</option>
      <option value="customer" <?= $roleFilter === 'customer' ? 'selected' : '' ?>>Customer</option>
    </select>
    <?php if ($roleFilter): ?>
      <a href="<?= base_url('admin/users') ?>" class="text-xs text-slate-400 hover:text-white underline">Reset</a>
    <?php endif; ?>
  </form>

  <span class="text-xs font-mono text-slate-400">Total: <strong class="text-white"><?= count($users) ?></strong> Akun</span>
</div>

<!-- Table Card -->
<div class="rounded-2xl glass-card overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-left text-xs text-slate-300">
      <thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
        <tr>
          <th class="py-3.5 px-4">Nama Pengguna</th>
          <th class="py-3.5 px-4">Email Login</th>
          <th class="py-3.5 px-4">Nomor WhatsApp</th>
          <th class="py-3.5 px-4">Role Akses</th>
          <th class="py-3.5 px-4">Terdaftar</th>
          <th class="py-3.5 px-4 text-right">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-800/60">
        <?php foreach ($users as $u): ?>
          <tr class="hover:bg-slate-800/30 transition-colors">
            <td class="py-3.5 px-4">
              <div class="flex items-center space-x-3">
                <div class="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 font-bold flex items-center justify-center font-display">
                  <?= esc(strtoupper(substr($u['nama'], 0, 1))) ?>
                </div>
                <div>
                  <span class="font-bold text-white block"><?= esc($u['nama']) ?></span>
                  <span class="text-[10px] font-mono text-slate-500">ID #<?= $u['id_user'] ?></span>
                </div>
              </div>
            </td>
            <td class="py-3.5 px-4 font-mono text-slate-300"><?= esc($u['email']) ?></td>
            <td class="py-3.5 px-4 font-mono text-slate-300"><?= esc($u['no_wa']) ?></td>
            <td class="py-3.5 px-4">
              <span class="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider <?= $u['role'] === 'admin' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' : ($u['role'] === 'tukang' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-blue-500/10 text-blue-400 border border-blue-500/20') ?>">
                <?= esc($u['role']) ?>
              </span>
            </td>
            <td class="py-3.5 px-4 font-mono text-slate-400 text-[11px]">
              <?= date('d/m/Y', strtotime($u['created_at'])) ?>
            </td>
            <td class="py-3.5 px-4">
              <div class="flex items-center justify-end gap-2">
                <button 
                  type="button" 
                  onclick='openModalEditUser(<?= json_encode($u) ?>)'
                  class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700"
                >
                  Edit Akun
                </button>
                <form method="POST" action="<?= base_url('admin/users/delete/' . $u['id_user']) ?>" onsubmit="return confirm(<?= esc(json_encode('Hapus akun ' . $u['nama'] . '?'), 'attr') ?>)" class="inline-flex">
                  <?= csrf_field() ?>
                  <button
                    type="submit"
                    title="Hapus akun"
                    aria-label="Hapus akun <?= esc($u['nama']) ?>"
                    class="inline-flex items-center justify-center w-8 h-8 rounded-lg border border-rose-500/30 bg-rose-500/10 text-rose-300 hover:bg-rose-500 hover:text-white transition-colors"
                  >
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6M9 7V4a1 1 0 011-1h4a1 1 0 011 1v3m-8 0h10"/>
                    </svg>
                    <span class="sr-only">Hapus akun</span>
                  </button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal User -->
<div id="userModal" class="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm hidden items-center justify-center p-4">
  <div class="w-full max-w-md rounded-3xl glass-dropdown p-6 sm:p-8 space-y-5 shadow-2xl border border-slate-700">
    <div class="flex items-center justify-between border-b border-slate-800 pb-3">
      <h3 id="modalUserTitle" class="text-lg font-bold text-white font-display">Tambah Akun Pengguna</h3>
      <button type="button" onclick="closeModalUser()" class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
        </svg>
      </button>
    </div>

    <form id="userForm" method="POST" action="<?= base_url('admin/users/store') ?>" class="space-y-4">
      <?= csrf_field() ?>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Nama Lengkap <span class="text-rose-400">*</span></label>
        <input type="text" id="u_nama" name="nama" required class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Email <span class="text-rose-400">*</span></label>
        <input type="email" id="u_email" name="email" required class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-blue-500">
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Nomor WhatsApp <span class="text-rose-400">*</span></label>
        <input type="text" id="u_no_wa" name="no_wa" required placeholder="08123456789" class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-blue-500">
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Role / Hak Akses <span class="text-rose-400">*</span></label>
        <select id="u_role" name="role" required class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
          <option value="admin">Administrator (Akses Penuh SCM, CRM, Pengaturan)</option>
          <option value="tukang">Tukang Las (Hanya Akses & Update Proyek)</option>
          <option value="customer">Customer</option>
        </select>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
          Password <span id="pwdNotice" class="text-slate-500 font-normal text-[10px]">(Biarkan kosong jika tidak diubah)</span>
        </label>
        <input type="password" id="u_password" name="password" minlength="6" class="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500">
      </div>

      <div class="pt-3 flex items-center justify-end space-x-3">
        <button type="button" onclick="closeModalUser()" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold">Batal</button>
        <button type="submit" class="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-blue-600/30">Simpan Akun</button>
      </div>
    </form>
  </div>
</div>

<script>
  const userModal = document.getElementById('userModal');
  const modalUserTitle = document.getElementById('modalUserTitle');
  const userForm = document.getElementById('userForm');
  const pwdNotice = document.getElementById('pwdNotice');
  const uPassword = document.getElementById('u_password');

  function openModalAddUser() {
    modalUserTitle.textContent = 'Tambah Pengguna Baru';
    userForm.action = '<?= base_url('admin/users/store') ?>';
    document.getElementById('u_nama').value = '';
    document.getElementById('u_email').value = '';
    document.getElementById('u_no_wa').value = '';
    document.getElementById('u_role').value = 'tukang';
    uPassword.value = '';
    uPassword.required = true;
    pwdNotice.textContent = '(Minimal 6 karakter)';
    userModal.classList.remove('hidden');
    userModal.classList.add('flex');
  }

  function openModalEditUser(u) {
    modalUserTitle.textContent = 'Edit Akun: ' + u.nama;
    userForm.action = '<?= base_url('admin/users/update') ?>/' + u.id_user;
    document.getElementById('u_nama').value = u.nama;
    document.getElementById('u_email').value = u.email;
    document.getElementById('u_no_wa').value = u.no_wa;
    document.getElementById('u_role').value = u.role;
    uPassword.value = '';
    uPassword.required = false;
    pwdNotice.textContent = '(Biarkan kosong jika tidak ingin mengubah password)';
    userModal.classList.remove('hidden');
    userModal.classList.add('flex');
  }

  function closeModalUser() {
    userModal.classList.add('hidden');
    userModal.classList.remove('flex');
  }
</script>

<?= $this->endSection() ?>
