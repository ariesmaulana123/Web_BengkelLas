<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<!-- Header & Add Button -->
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
  <div>
    <h2 class="text-xl font-bold text-white font-display">Daftar Jenis Pekerjaan</h2>
    <p class="text-xs text-slate-400">Master jenis pekerjaan fabrikasi (Kanopi, Pagar, Railing, Teralis, dll.)</p>
  </div>
  <button 
    type="button" 
    onclick="openModalAdd()"
    class="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-blue-600/30 hover:-translate-y-0.5 transition-all"
  >
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
    </svg>
    <span>Tambah Jenis Pekerjaan</span>
  </button>
</div>

<!-- Table Card -->
<div class="rounded-2xl glass-card overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-left text-xs text-slate-300">
      <thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
        <tr>
          <th class="py-3.5 px-4"># ID</th>
          <th class="py-3.5 px-4">Nama Pekerjaan</th>
          <th class="py-3.5 px-4">Deskripsi</th>
          <th class="py-3.5 px-4">Status</th>
          <th class="py-3.5 px-4 text-right">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-800/60">
        <?php if (empty($list)): ?>
          <tr>
            <td colspan="5" class="py-8 text-center text-slate-400 italic">Belum ada data jenis pekerjaan.</td>
          </tr>
        <?php else: ?>
          <?php foreach ($list as $item): ?>
            <tr class="hover:bg-slate-800/30 transition-colors">
              <td class="py-3.5 px-4 font-mono font-bold text-blue-400">#<?= $item['id_jp'] ?></td>
              <td class="py-3.5 px-4 font-bold text-white"><?= esc($item['nama']) ?></td>
              <td class="py-3.5 px-4 text-slate-400 max-w-xs truncate"><?= esc($item['deskripsi'] ?? '-') ?></td>
              <td class="py-3.5 px-4">
                <a href="<?= base_url('admin/scm/jenis-pekerjaan/toggle/' . $item['id_jp']) ?>" class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider transition-colors <?= $item['status'] === 'aktif' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20' ?>">
                  <span class="w-1.5 h-1.5 rounded-full <?= $item['status'] === 'aktif' ? 'bg-emerald-400' : 'bg-rose-400' ?>"></span>
                  <span><?= esc($item['status']) ?></span>
                </a>
              </td>
              <td class="py-3.5 px-4 text-right">
                <button 
                  type="button" 
                  onclick='openModalEdit(<?= json_encode($item) ?>)'
                  class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
                >
                  Edit
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Form Tambah / Edit -->
<div id="jpModal" class="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm hidden items-center justify-center p-4">
  <div class="w-full max-w-lg rounded-3xl glass-dropdown p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-700">
    <div class="flex items-center justify-between border-b border-slate-800 pb-4">
      <h3 id="modalTitle" class="text-lg font-bold text-white font-display">Tambah Jenis Pekerjaan</h3>
      <button type="button" onclick="closeModal()" class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
        </svg>
      </button>
    </div>

    <form id="jpForm" method="POST" action="<?= base_url('admin/scm/jenis-pekerjaan/store') ?>" class="space-y-4">
      <?= csrf_field() ?>
      
      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Nama Jenis Pekerjaan <span class="text-rose-400">*</span></label>
        <input type="text" id="nama" name="nama" required placeholder="Contoh: Kanopi Minimalis" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500">
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Deskripsi Singkat</label>
        <textarea id="deskripsi" name="deskripsi" rows="3" placeholder="Jelaskan spesifikasi umum pekerjaan..." class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"></textarea>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Status Aktif</label>
        <select id="status" name="status" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500">
          <option value="aktif">Aktif (Tampil di Landing Page & Kalkulator)</option>
          <option value="nonaktif">Non-Aktif (Disembunyikan)</option>
        </select>
      </div>

      <div class="pt-4 flex items-center justify-end space-x-3">
        <button type="button" onclick="closeModal()" class="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold">Batal</button>
        <button type="submit" class="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-blue-600/30">Simpan Data</button>
      </div>
    </form>
  </div>
</div>

<script>
  const modal = document.getElementById('jpModal');
  const modalTitle = document.getElementById('modalTitle');
  const jpForm = document.getElementById('jpForm');

  function openModalAdd() {
    modalTitle.textContent = 'Tambah Jenis Pekerjaan Baru';
    jpForm.action = '<?= base_url('admin/scm/jenis-pekerjaan/store') ?>';
    document.getElementById('nama').value = '';
    document.getElementById('deskripsi').value = '';
    document.getElementById('status').value = 'aktif';
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  function openModalEdit(item) {
    modalTitle.textContent = 'Edit Jenis Pekerjaan #' + item.id_jp;
    jpForm.action = '<?= base_url('admin/scm/jenis-pekerjaan/update') ?>/' + item.id_jp;
    document.getElementById('nama').value = item.nama;
    document.getElementById('deskripsi').value = item.deskripsi || '';
    document.getElementById('status').value = item.status;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  function closeModal() {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
</script>

<?= $this->endSection() ?>