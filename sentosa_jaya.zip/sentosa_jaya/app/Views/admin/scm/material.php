<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<!-- Header & Add Button -->
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
  <div>
    <h2 class="text-xl font-bold text-white font-display">Katalog Material & Harga Dasar</h2>
    <p class="text-xs text-slate-400">Daftar material konstruksi besi, rangka, atap, dan jasa yang aktif dihitung kalkulator.</p>
  </div>
  <button 
    type="button" 
    onclick="openModalAdd()"
    class="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-blue-600/30 hover:-translate-y-0.5 transition-all"
  >
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
    </svg>
    <span>Tambah Material Baru</span>
  </button>
</div>

<!-- Filter Bar -->
<div class="p-4 rounded-2xl glass-card flex flex-wrap items-center justify-between gap-3">
  <form method="GET" action="<?= base_url('admin/scm/material') ?>" class="flex flex-wrap items-center gap-3 w-full sm:w-auto">
    <div>
      <select name="id_jp" onchange="this.form.submit()" class="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-blue-500">
        <option value="">-- Semua Jenis Pekerjaan --</option>
        <?php foreach ($jpList as $jp): ?>
          <option value="<?= $jp['id_jp'] ?>" <?= $selectedJp == $jp['id_jp'] ? 'selected' : '' ?>>
            <?= esc($jp['nama']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <select name="kategori" onchange="this.form.submit()" class="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-blue-500">
        <option value="">-- Semua Kategori --</option>
        <option value="rangka" <?= $selectedKat === 'rangka' ? 'selected' : '' ?>>Rangka</option>
        <option value="atap" <?= $selectedKat === 'atap' ? 'selected' : '' ?>>Atap</option>
        <option value="tiang" <?= $selectedKat === 'tiang' ? 'selected' : '' ?>>Tiang</option>
        <option value="utama" <?= $selectedKat === 'utama' ? 'selected' : '' ?>>Model / Material Utama</option>
        <option value="jasa" <?= $selectedKat === 'jasa' ? 'selected' : '' ?>>Jasa Fabrikasi</option>
        <option value="aksesoris" <?= $selectedKat === 'aksesoris' ? 'selected' : '' ?>>Aksesoris</option>
      </select>
    </div>

    <?php if ($selectedJp || $selectedKat): ?>
      <a href="<?= base_url('admin/scm/material') ?>" class="text-xs text-slate-400 hover:text-white underline">Reset Filter</a>
    <?php endif; ?>
  </form>

  <span class="text-xs font-mono text-slate-400">Total: <strong class="text-white"><?= count($list) ?></strong> Material</span>
</div>

<!-- Table Card -->
<div class="rounded-2xl glass-card overflow-hidden">
  <div class="overflow-x-auto">
    <table class="w-full text-left text-xs text-slate-300">
      <thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
        <tr>
          <th class="py-3.5 px-4"># ID</th>
          <th class="py-3.5 px-4">Jenis Pekerjaan</th>
          <th class="py-3.5 px-4">Kategori</th>
          <th class="py-3.5 px-4">Nama Material</th>
          <th class="py-3.5 px-4">Satuan</th>
          <th class="py-3.5 px-4">Harga Aktif</th>
          <th class="py-3.5 px-4">Status</th>
          <th class="py-3.5 px-4 text-right">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-800/60">
        <?php if (empty($list)): ?>
          <tr>
            <td colspan="8" class="py-8 text-center text-slate-400 italic">Tidak ada data material yang cocok.</td>
          </tr>
        <?php else: ?>
          <?php foreach ($list as $item): ?>
            <tr class="hover:bg-slate-800/30 transition-colors">
              <td class="py-3.5 px-4 font-mono font-bold text-blue-400">#<?= $item['id_material'] ?></td>
              <td class="py-3.5 px-4 font-semibold text-white"><?= esc($item['nama_jp']) ?></td>
              <td class="py-3.5 px-4">
                <span class="px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                  <?= esc($item['kategori']) ?>
                </span>
              </td>
              <td class="py-3.5 px-4 font-bold text-white max-w-xs"><?= esc($item['nama_material']) ?></td>
              <td class="py-3.5 px-4 font-mono text-slate-300"><?= esc($item['satuan']) ?></td>
              <td class="py-3.5 px-4 font-mono font-bold text-emerald-400">
                Rp <?= number_format($item['harga'] ?? 0, 0, ',', '.') ?>
              </td>
              <td class="py-3.5 px-4">
                <a href="<?= base_url('admin/scm/material/toggle/' . $item['id_material']) ?>" class="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider transition-colors <?= $item['status'] === 'aktif' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20' ?>">
                  <span class="w-1.5 h-1.5 rounded-full <?= $item['status'] === 'aktif' ? 'bg-emerald-400' : 'bg-rose-400' ?>"></span>
                  <span><?= esc($item['status']) ?></span>
                </a>
              </td>
              <td class="py-3.5 px-4 text-right">
                <button 
                  type="button" 
                  onclick='openModalEdit(<?= json_encode($item) ?>)'
                  class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
                >
                  Edit
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Form Material -->
<div id="matModal" class="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm hidden items-center justify-center p-4">
  <div class="w-full max-w-lg rounded-3xl glass-dropdown p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-700">
    <div class="flex items-center justify-between border-b border-slate-800 pb-4">
      <h3 id="modalTitle" class="text-lg font-bold text-white font-display">Tambah Material Baru</h3>
      <button type="button" onclick="closeModal()" class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
        </svg>
      </button>
    </div>

    <form id="matForm" method="POST" action="<?= base_url('admin/scm/material/store') ?>" class="space-y-4">
      <?= csrf_field() ?>
      
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Jenis Pekerjaan <span class="text-rose-400">*</span></label>
          <select id="id_jp" name="id_jp" required class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500">
            <option value="" disabled selected>-- Pilih Jenis --</option>
            <?php foreach ($jpList as $jp): ?>
              <option value="<?= $jp['id_jp'] ?>"><?= esc($jp['nama']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Kategori Material <span class="text-rose-400">*</span></label>
          <select id="kategori" name="kategori" required class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500">
            <option value="rangka">Rangka</option>
            <option value="atap">Atap</option>
            <option value="tiang">Tiang</option>
            <option value="utama">Material / Model Utama</option>
            <option value="jasa">Jasa Fabrikasi</option>
            <option value="aksesoris">Aksesoris</option>
            <option value="lainnya">Lainnya</option>
          </select>
        </div>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Nama Material & Spesifikasi <span class="text-rose-400">*</span></label>
        <input type="text" id="nama_material" name="nama_material" required placeholder="Contoh: Alderon Twinwall 10mm" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500">
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Satuan Ukuran <span class="text-rose-400">*</span></label>
          <input type="text" id="satuan" name="satuan" required placeholder="m2 / m / unit / titik" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Panjang Standar (m) <span class="text-rose-400">*</span></label>
          <input type="number" id="panjang_standar" name="panjang_standar" required min="0.01" step="0.01" placeholder="6" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Harga Dasar (Rp) <span class="text-rose-400">*</span></label>
          <input type="number" id="harga" name="harga" required min="0" step="1000" placeholder="250000" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500">
        </div>
      </div>

      <div>
        <label class="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">Status Penggunaan</label>
        <select id="status" name="status" class="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500">
          <option value="aktif">Aktif (Digunakan Kalkulator Landing Page)</option>
          <option value="nonaktif">Non-Aktif (Disembunyikan)</option>
        </select>
      </div>

      <div class="pt-4 flex items-center justify-end space-x-3">
        <button type="button" onclick="closeModal()" class="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold">Batal</button>
        <button type="submit" class="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-blue-600/30">Simpan Material</button>
      </div>
    </form>
  </div>
</div>

<script>
  const modal = document.getElementById('matModal');
  const modalTitle = document.getElementById('modalTitle');
  const matForm = document.getElementById('matForm');

  function openModalAdd() {
    modalTitle.textContent = 'Tambah Material Baru';
    matForm.action = '<?= base_url('admin/scm/material/store') ?>';
    document.getElementById('id_jp').value = '';
    document.getElementById('kategori').value = 'rangka';
    document.getElementById('nama_material').value = '';
    document.getElementById('satuan').value = 'm2';
    document.getElementById('panjang_standar').value = '6';
    document.getElementById('harga').value = '';
    document.getElementById('status').value = 'aktif';
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  function openModalEdit(item) {
    modalTitle.textContent = 'Edit Material #' + item.id_material;
    matForm.action = '<?= base_url('admin/scm/material/update') ?>/' + item.id_material;
    document.getElementById('id_jp').value = item.id_jp;
    document.getElementById('kategori').value = item.kategori;
    document.getElementById('nama_material').value = item.nama_material;
    document.getElementById('satuan').value = item.satuan;
    document.getElementById('panjang_standar').value = item.panjang_standar || 6;
    document.getElementById('harga').value = item.harga || 0;
    document.getElementById('status').value = item.status;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  function closeModal() {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
</script>

<?= $this->endSection() ?>