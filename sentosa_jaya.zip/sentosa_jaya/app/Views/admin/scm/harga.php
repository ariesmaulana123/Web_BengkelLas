<?= $this->extend('admin/layouts/main') ?>

<?= $this->section('content') ?>

<!-- Header -->
<div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
  <div>
    <h2 class="text-xl font-bold text-white font-display">Tabel Master Harga Aktif</h2>
    <p class="text-xs text-slate-400">Harga di bawah ini langsung menentukan hasil kalkulasi otomatis di Landing Page.</p>
  </div>
  <button 
    type="submit" 
    form="bulkHargaForm"
    class="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-emerald-600/30 hover:-translate-y-0.5 transition-all"
  >
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
    </svg>
    <span>Simpan Semua Perubahan Harga</span>
  </button>
</div>

<!-- Filter Bar -->
<div class="p-4 rounded-2xl glass-card flex items-center justify-between">
  <form method="GET" action="<?= base_url('admin/scm/harga') ?>" class="flex items-center gap-3">
    <select name="id_jp" onchange="this.form.submit()" class="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-blue-500">
      <option value="">-- Tampilkan Semua Jenis Pekerjaan --</option>
      <?php foreach ($jpList as $jp): ?>
        <option value="<?= $jp['id_jp'] ?>" <?= $selectedJp == $jp['id_jp'] ? 'selected' : '' ?>>
          <?= esc($jp['nama']) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <?php if ($selectedJp): ?>
      <a href="<?= base_url('admin/scm/harga') ?>" class="text-xs text-slate-400 hover:text-white underline">Reset</a>
    <?php endif; ?>
  </form>

  <span class="text-xs font-mono text-slate-400">Total: <strong class="text-white"><?= count($list) ?></strong> Item Harga</span>
</div>

<!-- Table Card with Bulk Form -->
<div class="rounded-2xl glass-card overflow-hidden">
  <form id="bulkHargaForm" method="POST" action="<?= base_url('admin/scm/harga/bulk') ?>">
    <?= csrf_field() ?>
    <div class="overflow-x-auto">
      <table class="w-full text-left text-xs text-slate-300">
        <thead class="bg-slate-900/90 text-slate-400 font-mono uppercase tracking-wider text-[10px] border-b border-slate-800">
          <tr>
            <th class="py-3.5 px-4">Pekerjaan</th>
            <th class="py-3.5 px-4">Kategori</th>
            <th class="py-3.5 px-4">Nama Material</th>
            <th class="py-3.5 px-4">Satuan</th>
            <th class="py-3.5 px-4 w-52">Harga Aktif (Rp)</th>
            <th class="py-3.5 px-4">Status</th>
            <th class="py-3.5 px-4 text-right">Update Terakhir</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-800/60">
          <?php if (empty($list)): ?>
            <tr>
              <td colspan="7" class="py-8 text-center text-slate-400 italic">Tidak ada data harga.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($list as $item): ?>
              <tr class="hover:bg-slate-800/30 transition-colors">
                <td class="py-3 px-4 font-bold text-white"><?= esc($item['nama_jp']) ?></td>
                <td class="py-3 px-4">
                  <span class="px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                    <?= esc($item['kategori']) ?>
                  </span>
                </td>
                <td class="py-3 px-4 text-slate-200"><?= esc($item['nama_material']) ?></td>
                <td class="py-3 px-4 font-mono text-slate-400"><?= esc($item['satuan']) ?></td>
                <td class="py-3 px-4">
                  <div class="relative">
                    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-500">Rp</span>
                    <input 
                      type="number" 
                      name="prices[<?= $item['id_mharg'] ?>]" 
                      value="<?= (int) $item['harga'] ?>" 
                      min="0" 
                      step="500" 
                      class="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-emerald-400 font-mono font-bold text-xs focus:outline-none focus:border-blue-500 transition-colors"
                    >
                  </div>
                </td>
                <td class="py-3 px-4">
                  <span class="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider <?= $item['status'] === 'aktif' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20' ?>">
                    <span class="w-1.5 h-1.5 rounded-full <?= $item['status'] === 'aktif' ? 'bg-emerald-400' : 'bg-rose-400' ?>"></span>
                    <span><?= esc($item['status']) ?></span>
                  </span>
                </td>
                <td class="py-3 px-4 text-right font-mono text-[11px] text-slate-400">
                  <?= date('d/m/Y H:i', strtotime($item['updated_at'] ?? $item['created_at'])) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </form>
</div>

<?= $this->endSection() ?>