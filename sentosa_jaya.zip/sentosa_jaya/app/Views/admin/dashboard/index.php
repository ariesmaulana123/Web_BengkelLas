<?= $this->extend('admin/layouts/main') ?>
<?php
$isAdmin = (session()->get('role') === 'admin');
?>

<?= $this->section('content') ?>
<?php if ($isAdmin): ?>
<!-- ========================================== -->
<!-- 1. ADMIN EXECUTIVE DASHBOARD VIEW          -->
<!-- ========================================== -->

<!-- Top Stat Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">

  <!-- Card 1: Total Nilai Proyek -->
  <div class="p-6 rounded-2xl glass-card relative overflow-hidden group hover:border-blue-500/50 transition-all">
    <div class="absolute -right-4 -bottom-4 w-24 h-24 bg-blue-500/10 rounded-full blur-xl group-hover:bg-blue-500/20 transition-all"></div>
    <div class="flex items-center justify-between mb-3">
      <span class="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">Total Nilai Proyek (Deal)</span>
      <div class="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
      </div>
    </div>
    <div class="text-2xl font-black text-white font-mono tracking-tight">
      Rp <?= number_format($totalOmzet, 0, ',', '.') ?>
    </div>
    <p class="text-[11px] text-slate-400 mt-2 flex items-center space-x-1.5">
      <span class="text-emerald-400 font-semibold">DP: Rp <?= number_format($totalDp, 0, ',', '.') ?></span>
      <span>•</span>
      <span class="text-amber-400">Sisa: Rp <?= number_format($totalSisa, 0, ',', '.') ?></span>
    </p>
  </div>

  <!-- Card 2: Pengajuan Estimasi -->
  <div class="p-6 rounded-2xl glass-card relative overflow-hidden group hover:border-sky-500/50 transition-all">
    <div class="absolute -right-4 -bottom-4 w-24 h-24 bg-sky-500/10 rounded-full blur-xl group-hover:bg-sky-500/20 transition-all"></div>
    <div class="flex items-center justify-between mb-3">
      <span class="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">Total Estimasi Masuk</span>
      <div class="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-400 flex items-center justify-center">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
        </svg>
      </div>
    </div>
    <div class="text-2xl font-black text-white font-mono tracking-tight">
      <?= number_format($estStats['total'] ?? 0) ?> <span class="text-xs font-normal text-slate-400 font-sans">Kalkulasi</span>
    </div>
    <p class="text-[11px] text-slate-400 mt-2 flex items-center space-x-1.5">
      <span class="px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono"><?= $estStats['baru'] ?? 0 ?> Baru</span>
      <span>•</span>
      <span class="text-emerald-400 font-semibold"><?= $estStats['deal'] ?? 0 ?> Deal</span>
    </p>
  </div>

  <!-- Card 3: Proyek Sedang Berjalan -->
  <div class="p-6 rounded-2xl glass-card relative overflow-hidden group hover:border-emerald-500/50 transition-all">
    <div class="absolute -right-4 -bottom-4 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl group-hover:bg-emerald-500/20 transition-all"></div>
    <div class="flex items-center justify-between mb-3">
      <span class="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">Proyek Berjalan</span>
      <div class="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
        </svg>
      </div>
    </div>
    <div class="text-2xl font-black text-white font-mono tracking-tight">
      <?= number_format($proyekAktifCount) ?> <span class="text-xs font-normal text-slate-400 font-sans">Proyek Aktif</span>
    </div>
    <p class="text-[11px] text-slate-400 mt-2">
      <span class="text-emerald-400 font-semibold"><?= number_format($proyekSelesaiCount) ?> Selesai</span> dikerjakan workshop
    </p>
  </div>

  <!-- Card 4: Total Alokasi Upah Tukang -->
  <div class="p-6 rounded-2xl glass-card relative overflow-hidden group hover:border-cyan-500/50 transition-all">
    <div class="absolute -right-4 -bottom-4 w-24 h-24 bg-cyan-500/10 rounded-full blur-xl group-hover:bg-cyan-500/20 transition-all"></div>
    <div class="flex items-center justify-between mb-3">
      <span class="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">Total Alokasi Tukang</span>
      <div class="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/>
        </svg>
      </div>
    </div>
    <div class="text-2xl font-black text-white font-mono tracking-tight">
      Rp <?= number_format($totalAlokasiTukang ?? 0, 0, ',', '.') ?>
    </div>
    <p class="text-[11px] text-slate-400 mt-2">
      Total akumulasi biaya pekerjaan yang dialokasikan ke tukang
    </p>
  </div>

</div>

<!-- 2. Pipeline Estimasi Status Bar -->
<div class="p-6 rounded-2xl glass-card mt-6">
  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
    <div>
      <h3 class="text-base font-bold text-white font-display">Status Corong Estimasi CRM</h3>
      <p class="text-xs text-slate-400">Distribusi alur konversi dari kalkulator online hingga kontrak proyek</p>
    </div>
    <a href="<?= base_url('admin/crm/estimasi') ?>" class="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center space-x-1">
      <span>Kelola Semua Estimasi</span>
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
      </svg>
    </a>
  </div>

  <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
    <!-- Step 1: Baru -->
    <div class="p-4 rounded-xl bg-slate-900/90 border border-amber-500/30 text-center">
      <span class="text-[10px] font-mono uppercase font-bold text-amber-400 block mb-1">1. Pengajuan Baru</span>
      <span class="text-xl font-extrabold text-white font-mono"><?= $estStats['baru'] ?? 0 ?></span>
    </div>

    <!-- Step 2: Dihubungi -->
    <div class="p-4 rounded-xl bg-slate-900/90 border border-sky-500/30 text-center">
      <span class="text-[10px] font-mono uppercase font-bold text-sky-400 block mb-1">2. Dihubungi</span>
      <span class="text-xl font-extrabold text-white font-mono"><?= $estStats['dihubungi'] ?? 0 ?></span>
    </div>

    <!-- Step 3: Survey -->
    <div class="p-4 rounded-xl bg-slate-900/90 border border-indigo-500/30 text-center">
      <span class="text-[10px] font-mono uppercase font-bold text-indigo-400 block mb-1">3. Survey Lokasi</span>
      <span class="text-xl font-extrabold text-white font-mono"><?= $estStats['survey'] ?? 0 ?></span>
    </div>

    <!-- Step 4: Penawaran -->
    <div class="p-4 rounded-xl bg-slate-900/90 border border-purple-500/30 text-center">
      <span class="text-[10px] font-mono uppercase font-bold text-purple-400 block mb-1">4. Penawaran/PDF</span>
      <span class="text-xl font-extrabold text-white font-mono"><?= $estStats['penawaran'] ?? 0 ?></span>
    </div>

    <!-- Step 5: Deal -->
    <div class="p-4 rounded-xl bg-slate-900/90 border border-emerald-500/30 text-center col-span-2 sm:col-span-1">
      <span class="text-[10px] font-mono uppercase font-bold text-emerald-400 block mb-1">5. Deal / Proyek</span>
      <span class="text-xl font-extrabold text-white font-mono"><?= $estStats['deal'] ?? 0 ?></span>
    </div>
  </div>
</div>

<!-- 3. Chart Analytics Section -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
  <!-- Chart 1: Donut Distribution Status Estimasi -->
  <div class="p-6 rounded-2xl glass-card flex flex-col justify-between">
    <div>
      <h3 class="text-base font-bold text-white font-display mb-1">Distribusi Estimasi CRM</h3>
      <p class="text-xs text-slate-400 mb-4">Komposisi status siklus penawaran</p>
      <div class="h-56 relative flex items-center justify-center">
        <canvas id="crmDonutChart"></canvas>
      </div>
    </div>
    <div class="grid grid-cols-3 gap-2 text-center text-[10px] font-mono text-slate-400 pt-3 border-t border-slate-800">
      <div><span class="inline-block w-2 h-2 rounded-full bg-amber-400 mr-1"></span>Baru: <?= $estStats['baru'] ?? 0 ?></div>
      <div><span class="inline-block w-2 h-2 rounded-full bg-indigo-400 mr-1"></span>Survey: <?= $estStats['survey'] ?? 0 ?></div>
      <div><span class="inline-block w-2 h-2 rounded-full bg-emerald-400 mr-1"></span>Deal: <?= $estStats['deal'] ?? 0 ?></div>
    </div>
  </div>

  <!-- Chart 2: Proyek & Nilai Keuangan -->
  <div class="lg:col-span-2 p-6 rounded-2xl glass-card flex flex-col justify-between">
    <div>
      <div class="flex items-center justify-between mb-4">
        <div>
          <h3 class="text-base font-bold text-white font-display">Ringkasan Nilai Finansial Proyek</h3>
          <p class="text-xs text-slate-400">Total Nilai Kontrak, Realisasi DP, dan Sisa Pembayaran Piutang</p>
        </div>
      </div>
      <div class="h-56 relative">
        <canvas id="financeBarChart"></canvas>
      </div>
    </div>
    <div class="flex items-center justify-between text-xs text-slate-400 pt-3 border-t border-slate-800 font-mono">
      <span>Omzet: <strong class="text-blue-400 font-bold">Rp <?= number_format($totalOmzet, 0, ',', '.') ?></strong></span>
      <span>DP: <strong class="text-emerald-400 font-bold">Rp <?= number_format($totalDp, 0, ',', '.') ?></strong></span>
      <span>Sisa: <strong class="text-amber-400 font-bold">Rp <?= number_format($totalSisa, 0, ',', '.') ?></strong></span>
    </div>
  </div>
</div>

<!-- 4. Two Column Section: Recent Estimations & Active Projects -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">

  <!-- Left: Pengajuan Estimasi Terbaru -->
  <div class="p-6 rounded-2xl glass-card flex flex-col justify-between">
    <div>
      <div class="flex items-center justify-between mb-4">
        <div>
          <h3 class="text-base font-bold text-white font-display">Pengajuan Estimasi Masuk</h3>
          <p class="text-xs text-slate-400">5 data kalkulator online terbaru dari landing page</p>
        </div>
        <a href="<?= base_url('admin/crm/estimasi') ?>" class="text-xs font-semibold text-blue-400 hover:text-blue-300">Lihat Semua</a>
      </div>

      <div class="divide-y divide-slate-800/80">
        <?php if (empty($recentEstimasi)): ?>
          <p class="text-xs text-slate-400 py-6 text-center italic">Belum ada data pengajuan estimasi.</p>
        <?php else: ?>
          <?php foreach ($recentEstimasi as $item): ?>
            <div class="py-3.5 flex items-center justify-between gap-3 hover:bg-slate-800/30 px-2 rounded-xl transition-colors">
              <div class="overflow-hidden">
                <div class="flex items-center space-x-2 mb-1">
                  <span class="text-xs font-bold text-white truncate"><?= esc($item['nama_customer']) ?></span>
                  <span class="text-[10px] px-2 py-0.2 rounded-full font-mono font-medium <?= in_array($item['status'], ['baru', 'pengajuan_survey', 'dihitung']) ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : ($item['status'] === 'deal' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-800 text-slate-300') ?>">
                    <?= esc(strtoupper(str_replace('_', ' ', $item['status']))) ?>
                  </span>
                </div>
                <p class="text-xs text-slate-400 flex items-center space-x-2">
                  <span class="text-blue-400 font-semibold"><?= esc($item['nama_jp']) ?></span>
                  <span>•</span>
                  <span><?= $item['panjang'] ?>m x <?= $item['lebar'] ?>m (<?= $item['luas'] ?>m²)</span>
                </p>
              </div>
              <div class="text-right shrink-0">
                <p class="text-xs font-bold font-mono text-white">
                  Rp <?= number_format($item['total_final'] ? $item['total_final'] : $item['subtotal'], 0, ',', '.') ?>
                </p>
                <a href="<?= base_url('admin/crm/estimasi/detail/' . $item['id_estimasi']) ?>" class="text-[11px] text-blue-400 hover:text-blue-300 font-semibold">
                  Tinjau &rarr;
                </a>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Right: Proyek Aktif Terkini -->
  <div class="p-6 rounded-2xl glass-card flex flex-col justify-between">
    <div>
      <div class="flex items-center justify-between mb-4">
        <div>
          <h3 class="text-base font-bold text-white font-display">Monitoring Proyek Aktif</h3>
          <p class="text-xs text-slate-400">Status pekerjaan fabrikasi & progress tukang</p>
        </div>
        <a href="<?= base_url('admin/crm/proyek') ?>" class="text-xs font-semibold text-blue-400 hover:text-blue-300">Lihat Semua</a>
      </div>

      <div class="divide-y divide-slate-800/80">
        <?php if (empty($recentProyek)): ?>
          <p class="text-xs text-slate-400 py-6 text-center italic">Belum ada proyek aktif saat ini.</p>
        <?php else: ?>
          <?php foreach ($recentProyek as $prj): ?>
            <div class="py-3.5 space-y-2 hover:bg-slate-800/30 px-2 rounded-xl transition-colors">
              <div class="flex items-center justify-between">
                <div>
                  <h4 class="text-xs font-bold text-white"><?= esc($prj['nama_proyek']) ?></h4>
                  <p class="text-[11px] text-slate-400 font-mono">
                    <span class="text-blue-400"><?= esc($prj['kode_proyek']) ?></span> | Customer: <?= esc($prj['nama_customer']) ?>
                  </p>
                </div>
                <span class="text-xs font-bold font-mono text-emerald-400">
                  <?= $prj['progress'] ?>%
                </span>
              </div>
              <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div class="bg-gradient-to-r from-blue-500 to-emerald-500 h-full rounded-full transition-all duration-500" style="width: <?= $prj['progress'] ?>%"></div>
              </div>
              <div class="flex items-center justify-between text-[10px] text-slate-400">
                <span>Tukang: <strong class="text-slate-300"><?= esc($prj['nama_tukang'] ?? 'Belum Ditugaskan') ?></strong></span>
                <a href="<?= base_url('admin/crm/proyek/detail/' . $prj['id_proyek']) ?>" class="text-blue-400 hover:text-blue-300 font-semibold">Kelola Proyek &rarr;</a>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>

</div>

<!-- Chart Scripts for Admin -->
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const donutCtx = document.getElementById('crmDonutChart');
    if (donutCtx) {
      new Chart(donutCtx, {
        type: 'doughnut',
        data: {
          labels: ['Baru', 'Dihubungi', 'Survey', 'Penawaran', 'Deal', 'Ditolak'],
          datasets: [{
            data: [
              <?= (int) ($estStats['baru'] ?? 0) ?>,
              <?= (int) ($estStats['dihubungi'] ?? 0) ?>,
              <?= (int) ($estStats['survey'] ?? 0) ?>,
              <?= (int) ($estStats['penawaran'] ?? 0) ?>,
              <?= (int) ($estStats['deal'] ?? 0) ?>,
              <?= (int) ($estStats['ditolak'] ?? 0) ?>
            ],
            backgroundColor: ['#f59e0b', '#0ea5e9', '#6366f1', '#a855f7', '#10b981', '#ef4444'],
            borderColor: '#0f172a',
            borderWidth: 3
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          cutout: '70%'
        }
      });
    }

    const barCtx = document.getElementById('financeBarChart');
    if (barCtx) {
      new Chart(barCtx, {
        type: 'bar',
        data: {
          labels: ['Total Nilai Kontrak', 'Realisasi DP Masuk', 'Sisa Piutang Berjalan'],
          datasets: [{
            label: 'Nominal (Rp)',
            data: [
              <?= (float) $totalOmzet ?>,
              <?= (float) $totalDp ?>,
              <?= (float) $totalSisa ?>
            ],
            backgroundColor: ['rgba(59, 130, 246, 0.8)', 'rgba(16, 185, 129, 0.8)', 'rgba(245, 158, 11, 0.8)'],
            borderColor: ['#3b82f6', '#10b981', '#f59e0b'],
            borderWidth: 1,
            borderRadius: 8
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              grid: { color: 'rgba(51, 65, 85, 0.3)' },
              ticks: {
                color: '#94a3b8',
                callback: function(value) {
                  if (value >= 1000000) return 'Rp ' + (value / 1000000) + ' Jt';
                  return 'Rp ' + value.toLocaleString('id-ID');
                }
              }
            },
            x: {
              grid: { display: false },
              ticks: { color: '#cbd5e1' }
            }
          },
          plugins: { legend: { display: false } }
        }
      });
    }
  });
</script>

<?php else: ?>
<!-- ========================================== -->
<!-- 2. TUKANG DEDICATED WORKER DASHBOARD VIEW  -->
<!-- ========================================== -->

<!-- Top Stat Cards for Tukang -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">

  <div class="p-6 rounded-2xl glass-card border border-cyan-500/30 relative overflow-hidden group hover:border-cyan-500/60 transition-all bg-slate-900/90">
    <div class="absolute -right-4 -bottom-4 w-24 h-24 bg-cyan-500/10 rounded-full blur-xl group-hover:bg-cyan-500/20 transition-all"></div>
    <div class="flex items-center justify-between mb-3">
      <span class="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">Total Nilai Pekerjaan Anda</span>
      <div class="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
      </div>
    </div>
    <div class="text-2xl font-black text-white font-mono tracking-tight">
      Rp <?= number_format($totalNilaiAlokasiTukang, 0, ',', '.') ?>
    </div>
    <p class="text-[11px] text-slate-400 mt-2">Akumulasi nilai alokasi dari seluruh proyek yang ditugaskan</p>
  </div>

  <div class="p-6 rounded-2xl glass-card relative overflow-hidden group hover:border-blue-500/50 transition-all">
    <div class="absolute -right-4 -bottom-4 w-24 h-24 bg-blue-500/10 rounded-full blur-xl group-hover:bg-blue-500/20 transition-all"></div>
    <div class="flex items-center justify-between mb-3">
      <span class="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">Proyek Sedang Dikerjakan</span>
      <div class="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
        </svg>
      </div>
    </div>
    <div class="text-2xl font-black text-white font-mono tracking-tight">
      <?= number_format($proyekAktifCount) ?> <span class="text-xs font-normal text-slate-400 font-sans">Proyek Aktif</span>
    </div>
    <p class="text-[11px] text-slate-400 mt-2">Perlu pembaruan kemajuan fisik dan dokumentasi</p>
  </div>

  <div class="p-6 rounded-2xl glass-card relative overflow-hidden group hover:border-emerald-500/50 transition-all">
    <div class="absolute -right-4 -bottom-4 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl group-hover:bg-emerald-500/20 transition-all"></div>
    <div class="flex items-center justify-between mb-3">
      <span class="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">Proyek Selesai 100%</span>
      <div class="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
      </div>
    </div>
    <div class="text-2xl font-black text-white font-mono tracking-tight">
      <?= number_format($proyekSelesaiCount) ?> <span class="text-xs font-normal text-slate-400 font-sans">Selesai</span>
    </div>
    <p class="text-[11px] text-emerald-400 mt-2">Tuntas dikerjakan dan diserahterimakan</p>
  </div>

  <div class="p-6 rounded-2xl glass-card relative overflow-hidden group hover:border-purple-500/50 transition-all">
    <div class="absolute -right-4 -bottom-4 w-24 h-24 bg-purple-500/10 rounded-full blur-xl group-hover:bg-purple-500/20 transition-all"></div>
    <div class="flex items-center justify-between mb-3">
      <span class="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">Total Penugasan Anda</span>
      <div class="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
        </svg>
      </div>
    </div>
    <div class="text-2xl font-black text-white font-mono tracking-tight">
      <?= number_format($totalProyekTukang) ?> <span class="text-xs font-normal text-slate-400 font-sans">Proyek</span>
    </div>
    <p class="text-[11px] text-slate-400 mt-2">Total seluruh proyek yang pernah ditugaskan kepada Anda</p>
  </div>

</div>

<!-- Monitoring Daftar Proyek Aktif untuk Tukang -->
<div class="p-6 rounded-2xl glass-card space-y-4 mt-6">
  <div class="flex items-center justify-between">
    <div>
      <h3 class="text-base font-bold text-white font-display">Tugas & Proyek Fabrikasi Anda</h3>
      <p class="text-xs text-slate-400">Pantau tugas pekerjaan yang dialokasikan kepada Anda dan perbarui progres langsung</p>
    </div>
    <a href="<?= base_url('admin/crm/proyek') ?>" class="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center space-x-1">
      <span>Lihat Semua Proyek Saya &rarr;</span>
    </a>
  </div>

  <div class="divide-y divide-slate-800/80">
    <?php if (empty($recentProyek)): ?>
      <p class="text-xs text-slate-400 py-8 text-center italic">Saat ini belum ada proyek atau tugas yang ditugaskan kepada Anda.</p>
    <?php else: ?>
      <?php foreach ($recentProyek as $prj): ?>
        <div class="py-4 space-y-3 hover:bg-slate-800/30 px-3 rounded-xl transition-colors">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <div class="flex items-center space-x-2">
                <span class="text-xs font-bold text-white"><?= esc($prj['nama_proyek']) ?></span>
                <span class="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 font-bold">
                  <?= esc($prj['kode_proyek']) ?>
                </span>
              </div>
              <p class="text-xs text-slate-400 mt-0.5">
                Customer: <span class="text-slate-200"><?= esc($prj['nama_customer']) ?></span> (<?= esc($prj['no_wa_customer']) ?>)
              </p>
            </div>
            
            <div class="text-left sm:text-right">
              <span class="text-[10px] font-mono text-slate-400 block uppercase">Nilai Pekerjaan Anda</span>
              <span class="text-sm font-bold font-mono text-cyan-400">Rp <?= number_format($prj['nilai_tukang'] ?? 0, 0, ',', '.') ?></span>
            </div>
          </div>

          <?php if (!empty($prj['pekerjaan_tukang'])): ?>
            <div class="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800 text-xs">
              <span class="text-[10px] font-mono font-bold text-slate-400 uppercase block">Rincian Tugas Anda:</span>
              <p class="text-slate-200 mt-0.5"><?= esc($prj['pekerjaan_tukang']) ?></p>
            </div>
          <?php endif; ?>

          <div class="space-y-1">
            <div class="flex items-center justify-between text-xs font-mono">
              <span class="text-slate-400">Progress Pengerjaan:</span>
              <span class="font-bold text-emerald-400"><?= $prj['progress'] ?>%</span>
            </div>
            <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div class="bg-gradient-to-r from-blue-500 to-emerald-500 h-full rounded-full transition-all duration-500" style="width: <?= $prj['progress'] ?>%"></div>
            </div>
          </div>

          <div class="flex items-center justify-between pt-1 text-xs">
            <span class="px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider font-semibold <?= $prj['status'] === 'selesai' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-800 text-slate-300' ?>">
              Status: <?= esc(str_replace('_', ' ', $prj['status'])) ?>
            </span>
            <a href="<?= base_url('admin/crm/proyek/detail/' . $prj['id_proyek']) ?>" class="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-all shadow-md shadow-blue-600/20">
              Update Progres &rarr;
            </a>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<?php endif; ?>

<?= $this->endSection() ?>