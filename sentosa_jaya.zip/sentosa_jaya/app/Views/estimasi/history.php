﻿<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<section class="relative min-h-[90vh] pt-28 pb-20 bg-slate-950 px-4 sm:px-6 lg:px-8">
  <!-- Background Glow & Grid -->
  <div class="absolute inset-0 bg-industrial-grid opacity-25 pointer-events-none"></div>
  <div class="absolute w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none top-20 -left-40"></div>
  <div class="absolute w-[500px] h-[500px] bg-sky-500/10 rounded-full blur-[140px] pointer-events-none bottom-20 -right-40"></div>

  <div class="relative z-10 max-w-7xl mx-auto space-y-8">
    
    <!-- Top Action Bar & Breadcrumbs -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
      <div class="space-y-1">
        <div class="flex items-center space-x-2 text-xs text-slate-400">
          <a href="<?= base_url() ?>" class="hover:text-blue-400 transition-colors">Beranda</a>
          <span>/</span>
          <span class="text-blue-400 font-semibold">Riwayat Estimasi</span>
        </div>
        <h1 class="text-2xl sm:text-3xl font-extrabold text-white font-display tracking-tight">
          Riwayat Perhitungan <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-blue-500">Estimasi Proyek</span>
        </h1>
        <p class="text-xs sm:text-sm text-slate-400">
          Daftar seluruh estimasi kalkulator dan pengajuan survey lokasi milik <strong class="text-white"><?= esc($currentUser['nama']) ?></strong>.
        </p>
      </div>

      <div class="flex items-center space-x-3">
        <a 
          href="<?= base_url('/#kalkulator') ?>" 
          class="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-blue-600/25 hover:shadow-blue-500/40 hover:-translate-y-0.5 transition-all flex items-center space-x-2"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
          </svg>
          <span>Hitung Estimasi Baru</span>
        </a>
      </div>
    </div>

    <!-- Flash Notifications -->
    <?php if (session()->getFlashdata('success')): ?>
      <div class="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs sm:text-sm flex items-center space-x-3 shadow-lg shadow-emerald-500/5">
        <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
        </svg>
        <span><?= esc(session()->getFlashdata('success')) ?></span>
      </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
      <div class="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs sm:text-sm flex items-center space-x-3 shadow-lg shadow-red-500/5">
        <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <span><?= esc(session()->getFlashdata('error')) ?></span>
      </div>
    <?php endif; ?>

    <?php if (empty($estimasiList)): ?>
      <!-- Empty State -->
      <div class="p-12 sm:p-16 rounded-3xl bg-slate-900/60 border border-slate-800 border-dashed text-center flex flex-col items-center justify-center max-w-2xl mx-auto shadow-2xl backdrop-blur-xl">
        <div class="w-20 h-20 rounded-3xl bg-slate-800/80 text-blue-400 border border-slate-700/80 flex items-center justify-center mb-5 shadow-xl shadow-blue-500/5">
          <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
          </svg>
        </div>
        <h3 class="text-xl font-bold text-white mb-2">Belum Ada Riwayat Estimasi</h3>
        <p class="text-xs sm:text-sm text-slate-400 max-w-md mb-8 leading-relaxed">
          Anda belum pernah melakukan perhitungan estimasi biaya atau mengajukan survey lokasi. Gunakan kalkulator kami untuk menghitung perkiraan biaya proyek Anda.
        </p>
        <a 
          href="<?= base_url('/#kalkulator') ?>" 
          class="px-8 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-blue-600/30 hover:shadow-blue-500/50 hover:-translate-y-0.5 transition-all flex items-center space-x-2"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
          </svg>
          <span>Mulai Hitung Estimasi Sekarang</span>
        </a>
      </div>

    <?php else: ?>
      <!-- Grid List of Estimations -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <?php foreach ($estimasiList as $est): ?>
          <div class="p-6 sm:p-7 rounded-3xl bg-slate-900/80 border border-slate-800/90 shadow-2xl backdrop-blur-xl flex flex-col justify-between hover:border-slate-700/90 transition-all group">
            
            <!-- Card Header -->
            <div class="space-y-4">
              <div class="flex items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
                <div class="flex items-center space-x-2.5">
                  <span class="px-2.5 py-1 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 font-mono font-bold text-xs">
                    #EST-<?= str_pad($est['id_estimasi'], 5, '0', STR_PAD_LEFT) ?>
                  </span>
                  <span class="text-[11px] text-slate-400 font-mono">
                    <?= date('d M Y, H:i', strtotime($est['created_at'])) ?> WIB
                  </span>
                </div>

                <!-- Status Badge -->
                <?php if ($est['status'] === 'pengajuan_survey'): ?>
                  <span class="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/10 text-amber-300 border border-amber-500/20">
                    <span class="w-1.5 h-1.5 rounded-full bg-amber-400 mr-1.5 animate-pulse"></span>
                    Pengajuan Survey
                  </span>
                <?php elseif ($est['status'] === 'disetujui'): ?>
                  <span class="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Disetujui
                  </span>
                <?php else: ?>
                  <span class="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-800 text-slate-300 border border-slate-700">
                    <?= esc(ucfirst(str_replace('_', ' ', $est['status']))) ?>
                  </span>
                <?php endif; ?>
              </div>

              <!-- Main Job Info -->
              <div class="space-y-2">
                <h3 class="text-lg sm:text-xl font-bold text-white group-hover:text-blue-400 transition-colors">
                  <?= esc($est['nama_jp'] ?? 'Fabrikasi Besi') ?>
                </h3>

                <!-- Dimension Badges -->
                <div class="flex flex-wrap items-center gap-2 text-xs">
                  <span class="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono">
                    📐 <strong><?= number_format($est['panjang'], 2) ?> m</strong> × <strong><?= number_format($est['lebar'], 2) ?> m</strong>
                  </span>
                  <span class="px-2.5 py-1 rounded-lg bg-sky-500/10 border border-sky-500/20 text-sky-300 font-mono font-bold">
                    Luas: <?= number_format($est['luas'], 2) ?> m²
                  </span>
                  <?php if (!empty($est['tinggi'])): ?>
                    <span class="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono">
                      Tinggi Tiang: <?= number_format($est['tinggi'], 2) ?> m
                    </span>
                  <?php endif; ?>
                </div>
              </div>

              <!-- Breakdown Table (Collapsible Accordion) -->
              <?php if (!empty($est['details'])): ?>
                <div class="pt-2">
                  <details class="group/details text-xs rounded-xl border border-slate-800 bg-slate-950/60 overflow-hidden">
                    <summary class="py-2 px-3 bg-slate-900/90 text-slate-300 font-semibold cursor-pointer hover:text-white flex items-center justify-between select-none">
                      <span>Rincian Material & Jasa (<?= count($est['details']) ?> Item)</span>
                      <svg class="w-4 h-4 transition-transform group-open/details:rotate-180 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                      </svg>
                    </summary>
                    <div class="divide-y divide-slate-800/60 p-2 space-y-1.5 font-mono">
                      <?php foreach ($est['details'] as $det): ?>
                        <div class="flex items-center justify-between py-1 px-2 text-[11px]">
                          <span class="text-slate-300 truncate max-w-[200px] sm:max-w-xs">
                            • <?= esc($det['nama_material']) ?>
                          </span>
                          <span class="text-slate-400">
                            Rp <?= number_format($det['subtotal'], 0, ',', '.') ?>
                          </span>
                        </div>
                      <?php endforeach; ?>
                    </div>
                  </details>
                </div>
              <?php endif; ?>

              <!-- Catatan (If Any) -->
              <?php if (!empty($est['catatan'])): ?>
                <div class="p-3 rounded-xl bg-slate-950/50 border border-slate-800 text-xs text-slate-300">
                  <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-0.5">Catatan:</span>
                  <p class="italic text-slate-300 leading-relaxed"><?= esc($est['catatan']) ?></p>
                </div>
              <?php endif; ?>

              <!-- Total & Range Price Box -->
              <div class="p-4 rounded-2xl bg-blue-950/30 border border-blue-500/25 space-y-2">
                <div class="flex items-center justify-between text-xs text-slate-300">
                  <span>Subtotal Dasar:</span>
                  <span class="font-bold font-mono text-white">Rp <?= number_format($est['subtotal'], 0, ',', '.') ?></span>
                </div>
                <div class="pt-2 border-t border-blue-500/20 flex items-center justify-between">
                  <span class="text-xs font-semibold text-blue-300 uppercase tracking-wider">Estimasi Biaya:</span>
                  <span class="text-sm sm:text-base font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-300 via-sky-200 to-white font-mono">
                    Rp <?= number_format($est['estimasi_min'], 0, ',', '.') ?> - Rp <?= number_format($est['estimasi_max'], 0, ',', '.') ?>
                  </span>
                </div>
              </div>
            </div>

            <!-- Card Actions -->
            <div class="mt-6 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3">
              <a 
                href="<?= esc($est['wa_url']) ?>" 
                target="_blank" 
                rel="noopener noreferrer"
                class="w-full sm:w-auto flex-1 inline-flex items-center justify-center px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-emerald-600/20 hover:shadow-emerald-500/40 hover:-translate-y-0.5 transition-all space-x-2 text-center"
              >
                <svg class="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
                  <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
                </svg>
                <span>Hubungi Admin WA</span>
              </a>

              <form 
                action="<?= base_url('riwayat-estimasi/hapus/' . $est['id_estimasi']) ?>" 
                method="POST" 
                onsubmit="return confirm('Apakah Anda yakin ingin menghapus riwayat estimasi #EST-<?= str_pad($est['id_estimasi'], 5, '0', STR_PAD_LEFT) ?>?');"
                class="w-full sm:w-auto"
              >
                <?= csrf_field() ?>
                <button 
                  type="submit" 
                  class="w-full sm:w-auto px-3.5 py-2.5 rounded-xl bg-slate-800/80 hover:bg-red-500/20 text-slate-400 hover:text-red-400 border border-slate-700 hover:border-red-500/30 text-xs font-semibold transition-all flex items-center justify-center space-x-1.5"
                  title="Hapus Riwayat"
                >
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                  </svg>
                  <span class="sm:hidden">Hapus Estimasi</span>
                </button>
              </form>
            </div>

          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>
</section>
<?= $this->endSection() ?>
