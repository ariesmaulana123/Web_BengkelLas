<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

  <!-- 1. Hero Section -->
  <?= $this->include('sections/hero') ?>

  <!-- 2. Service Highlight Section -->
  <!-- 2. Kalkulator Estimasi Section -->
  <?= $this->include('sections/calculator') ?>

  <!-- 3. Service Highlight Section -->
  <?= $this->include('sections/service_highlight') ?>

  <!-- 3. Why Choose Us Section -->
  <!-- 4. Why Choose Us Section -->
  <?= $this->include('sections/why_choose_us') ?>

  <!-- 4. Tentang Kami Section -->
  <?= $this->include('sections/about') ?>

  <!-- 5. Layanan Section (8 Layanan Lengkap) -->
  <?= $this->include('sections/services') ?>

  <!-- 6. Portfolio Section (Gallery, Filter & Lightbox) -->
  <?= $this->include('sections/portfolio') ?>

  <!-- 7. Before -> Process -> After Section -->
  <?= $this->include('sections/comparison') ?>

  <!-- 8. Proses Kerja Section (6 Alur Terstruktur) -->
  <?= $this->include('sections/workflow') ?>

  <!-- 9. Material & Finishing Section -->
  <?= $this->include('sections/materials') ?>

  <!-- 10. Workshop Gallery Section -->
  <?= $this->include('sections/workshop') ?>

  <!-- 11. Testimonial Carousel Section -->
  <?= $this->include('sections/testimonials') ?>

  <!-- 12. Area Layanan Section (Setu, Bekasi, Cikarang, Tambun, Cibitung, Sekitarnya) -->
  <?= $this->include('sections/service_areas') ?>

  <!-- 13. FAQ Accordion Section -->
  <?= $this->include('sections/faq') ?>

  <!-- 14. Rating Bengkel Las Section -->
  <?= $this->include('sections/cta') ?>

  <!-- 15. Kontak Section -->
  <?= $this->include('sections/contact') ?>

<?= $this->endSection() ?>

