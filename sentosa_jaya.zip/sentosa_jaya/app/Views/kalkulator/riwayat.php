<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<section class="relative min-h-screen pt-28 pb-20 bg-slate-950 px-4 sm:px-6 lg:px-8">
  <!-- Background Glow & Grid -->
  <div class="absolute inset-0 bg-industrial-grid opacity-25 pointer-events-none"></div>
  <div class="absolute w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none top-16 -left-36"></div>
  <div class="absolute w-[500px] h-[500px] bg-sky-500/10 rounded-full blur-[140px] pointer-events-none bottom-20 -right-36"></div>

  <div class="relative z-10 max-w-7xl mx-auto space-y-10">

    <!-- 1. Breadcrumb & Header Title -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-800/80">
      <div>
        <nav class="flex items-center space-x-2 text-xs text-slate-400 mb-2">
          <a href="<?= base_url() ?>" class="hover:text-white transition-colors">Beranda</a>
          <span>/</span>
          <span class="text-blue-400 font-semibold">Riwayat Estimasi</span>
        </nav>
        <h1 class="text-2xl sm:text-4xl font-extrabold text-white font-display tracking-tight flex items-center space-x-3">
          <span>Riwayat Estimasi Proyek</span>
          <span class="text-xs px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 font-mono font-medium">
            <?= count($estimasiList) ?> Data
          </span>
        </h1>
        <p class="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
          Tinjau estimasi yang telah Anda simpan<?= $isLoggedIn ? '.' : ' di browser ini.' ?>
        </p>
      </div>

      <div class="flex items-center space-x-3">
        <a 
          href="<?= base_url('/#kalkulator') ?>" 
          class="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider shadow-lg shadow-blue-600/25 hover:shadow-blue-500/40 hover:-translate-y-0.5 transition-all flex items-center space-x-2"
        >
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
          </svg>
          <span>Hitung Estimasi Baru</span>
        </a>
      </div>
    </div>

    <!-- 2. Profile Summary & Quick Stats -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
      
      <!-- Stat 1: User Profile -->
      <div class="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl backdrop-blur-md flex items-center space-x-4">
        <div class="w-12 h-12 rounded-xl bg-blue-600/20 border border-blue-500/30 text-blue-400 flex items-center justify-center font-bold text-lg font-display">
          <?= esc(strtoupper(substr($currentUser['nama'] ?? 'U', 0, 1))) ?>
        </div>
        <div class="overflow-hidden">
          <p class="text-[11px] font-mono text-slate-400 uppercase tracking-wider"><?= $isLoggedIn ? 'Akun' : 'Riwayat Browser' ?></p>
          <h3 class="text-sm font-bold text-white truncate"><?= esc($currentUser['nama'] ?? 'Pelanggan') ?></h3>
          <p class="text-xs text-slate-400 font-mono truncate"><?= esc($currentUser['no_wa'] ?? '-') ?></p>
        </div>
      </div>

      <!-- Stat 2: Total Estimasi -->
      <div class="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl backdrop-blur-md flex items-center space-x-4">
        <div class="w-12 h-12 rounded-xl bg-sky-500/20 border border-sky-500/30 text-sky-400 flex items-center justify-center">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
          </svg>
        </div>
        <div>
          <p class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Total Estimasi Dihitung</p>
          <h3 class="text-xl font-extrabold text-white font-display"><?= count($estimasiList) ?> <span class="text-xs text-slate-400 font-sans font-normal">Proyek</span></h3>
        </div>
      </div>

      <!-- Stat 3: Status Survey -->
      <div class="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl backdrop-blur-md flex items-center space-x-4">
        <div class="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
          </svg>
        </div>
        <div>
          <p class="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Status Penyimpanan</p>
          <h3 class="text-sm font-bold text-emerald-400 flex items-center space-x-1.5 mt-0.5">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Tersimpan di Riwayat</span>
          </h3>
        </div>
      </div>

    </div>

    <!-- 3. Estimation History List -->
    <div class="space-y-6">
      
      <?php if (empty($estimasiList)): ?>
        <!-- Empty State -->
        <div class="p-12 sm:p-16 rounded-3xl bg-slate-900/50 border border-slate-800 border-dashed text-center max-w-2xl mx-auto space-y-5">
          <div class="w-16 h-16 rounded-2xl bg-slate-800/80 text-slate-500 flex items-center justify-center mx-auto shadow-inner">
            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
            </svg>
          </div>
          <div>
            <h3 class="text-lg font-bold text-white mb-1">Belum Ada Riwayat Estimasi</h3>
            <p class="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
              Belum ada perhitungan estimasi yang tersimpan. Gunakan kalkulator untuk menghitung dan menyimpan estimasi proyek Anda.
            </p>
          </div>
          <div class="pt-2">
            <a 
              href="<?= base_url('/#kalkulator') ?>" 
              class="inline-flex items-center px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-blue-600/30 hover:shadow-blue-500/50 transition-all space-x-2"
            >
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
              </svg>
              <span>Mulai Hitung Estimasi Sekarang</span>
            </a>
          </div>
        </div>

      <?php else: ?>
        
        <?php foreach ($estimasiList as $est): ?>
          <?php 
            $estNo = '#EST-' . str_pad($est['id_estimasi'], 5, '0', STR_PAD_LEFT);
            $createdAt = date('d M Y, H:i', strtotime($est['created_at']));
            $namaJp = $est['nama_jp'] ?? 'Pekerjaan Besi';
            $luas = number_format((float) $est['luas'], 2, ',', '.');
            $panjang = number_format((float) $est['panjang'], 2, ',', '.');
            $lebar = number_format((float) $est['lebar'], 2, ',', '.');
            $tinggi = $est['tinggi'] !== null ? number_format((float) $est['tinggi'], 2, ',', '.') : null;
            $subtotal = number_format((float) $est['subtotal'], 0, ',', '.');
            $estMin = number_format((float) $est['estimasi_min'], 0, ',', '.');
            $estMax = number_format((float) $est['estimasi_max'], 0, ',', '.');
            
          ?>

          <div class="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl backdrop-blur-xl space-y-6 hover:border-slate-700 transition-all">
            
            <!-- Card Header -->
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
              <div class="space-y-1">
                <div class="flex items-center space-x-2.5 flex-wrap gap-y-1">
                  <span class="text-sm sm:text-base font-black font-mono text-blue-400 bg-blue-500/10 border border-blue-500/20 px-2.5 py-0.5 rounded-lg">
                    <?= esc($estNo) ?>
                  </span>
                  <span class="text-base sm:text-lg font-bold text-white">
                    <?= esc($namaJp) ?>
                  </span>
                </div>
                <p class="text-xs text-slate-400 flex items-center space-x-1.5">
                  <svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                  </svg>
                  <span>Dihitung pada: <?= esc($createdAt) ?> WIB</span>
                </p>
              </div>

              <div>
                <span class="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                  <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse"></span>
                  Estimasi Tersimpan
                </span>
              </div>
            </div>

            <!-- Card Body: Grid Specs & Price -->
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              <!-- Left: Dimension & Notes -->
              <div class="lg:col-span-6 space-y-4">
                <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div class="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80">
                    <span class="text-[10px] font-mono text-slate-500 uppercase block">Panjang</span>
                    <span class="text-sm font-bold text-slate-200 font-mono"><?= esc($panjang) ?> m</span>
                  </div>
                  <div class="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80">
                    <span class="text-[10px] font-mono text-slate-500 uppercase block">Lebar</span>
                    <span class="text-sm font-bold text-slate-200 font-mono"><?= esc($lebar) ?> m</span>
                  </div>
                  <div class="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 col-span-2 sm:col-span-1">
                    <span class="text-[10px] font-mono text-blue-400 uppercase block">Total Luas</span>
                    <span class="text-sm font-extrabold text-sky-400 font-mono"><?= esc($luas) ?> m²</span>
                  </div>
                </div>

                <?php if ($tinggi): ?>
                  <div class="p-3 rounded-xl bg-slate-950/60 border border-slate-800/60 text-xs text-slate-300">
                    <span class="text-slate-500">Tinggi Tiang:</span> <strong class="font-mono text-slate-200"><?= esc($tinggi) ?> Meter</strong>
                  </div>
                <?php endif; ?>

                <?php if (!empty($est['catatan'])): ?>
                  <div class="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1">
                    <span class="text-[10px] font-mono uppercase text-slate-400 font-bold block">Catatan / Kebutuhan Tambahan:</span>
                    <p class="text-xs text-slate-300 italic"><?= esc($est['catatan']) ?></p>
                  </div>
                <?php endif; ?>
              </div>

              <!-- Right: Price Estimation Box -->
              <div class="lg:col-span-6 p-5 rounded-2xl bg-blue-950/30 border border-blue-500/25 space-y-3">
                <div class="flex items-center justify-between text-xs text-slate-300">
                  <span>Subtotal Perhitungan:</span>
                  <span class="font-mono font-bold text-white text-sm">Rp <?= esc($subtotal) ?></span>
                </div>
                <div class="pt-3 border-t border-blue-500/20">
                  <span class="text-[11px] font-semibold text-blue-300 uppercase tracking-wider block mb-1">Perkiraan Range Biaya (±10%):</span>
                  <div class="text-lg sm:text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-300 via-sky-200 to-white font-mono">
                    Rp <?= esc($estMin) ?> - Rp <?= esc($estMax) ?>
                  </div>
                  <p class="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
                    *Estimasi awal material & jasa fabrikasi sebelum survey pengukuran detail.
                  </p>
                </div>
              </div>

            </div>

            <!-- Card Material Breakdown Table (If Details Exist) -->
            <?php if (!empty($est['details']) && is_array($est['details'])): ?>
              <div class="space-y-2 pt-2">
                <p class="text-xs font-semibold text-slate-300 uppercase tracking-wider">Rincian Material & Komponen Terpilih</p>
                <div class="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/70">
                  <table class="w-full text-left text-xs text-slate-300">
                    <thead class="bg-slate-900/90 text-slate-400 border-b border-slate-800 uppercase font-mono text-[10px]">
                      <tr>
                        <th class="py-2.5 px-3">Item Material / Jasa</th>
                        <th class="py-2.5 px-2 text-center">Volume</th>
                        <th class="py-2.5 px-3 text-right">Harga Satuan</th>
                        <th class="py-2.5 px-3 text-right">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/60 font-sans">
                      <?php foreach ($est['details'] as $det): ?>
                        <tr class="hover:bg-slate-900/40 transition-colors">
                          <td class="py-2.5 px-3 font-medium text-white flex items-center space-x-1.5">
                            <span class="inline-block px-1.5 py-0.5 rounded text-[9px] font-mono uppercase border <?= ($det['kategori'] ?? '') === 'jasa' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-blue-500/10 text-blue-400 border-blue-500/20' ?>">
                              <?= esc($det['kategori'] ?? 'material') ?>
                            </span>
                            <span><?= esc($det['nama_material'] ?? 'Komponen Proyek') ?></span>
                          </td>
                          <td class="py-2.5 px-2 text-center font-mono text-slate-300">
                            <?= number_format((float) $det['qty'], 1, ',', '.') ?> <?= esc($det['satuan'] ?? 'unit') ?>
                          </td>
                          <td class="py-2.5 px-3 text-right font-mono text-slate-400">
                            Rp <?= number_format((float) $det['harga'], 0, ',', '.') ?>
                          </td>
                          <td class="py-2.5 px-3 text-right font-bold font-mono text-slate-100">
                            Rp <?= number_format((float) $det['subtotal'], 0, ',', '.') ?>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            <?php endif; ?>

            <!-- Card Footer: Re-calculate -->
            <div class="pt-4 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div class="text-[11px] text-slate-400">
                Estimasi ini tersimpan di riwayat Anda.
              </div>
              <div class="flex items-center space-x-2.5 self-start sm:self-auto">
                <a
                  href="<?= base_url('/#kalkulator') ?>"
                  class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-wider transition-all"
                >
                  Hitung Lagi
                </a>
              </div>
            </div>

          </div>
        <?php endforeach; ?>

      <?php endif; ?>

    </div>

  </div>
</section>
<?= $this->endSection() ?>
