<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddWorkerAllocationToProyek extends Migration
{
    public function up()
    {
        if (! $this->db->fieldExists('nilai_tukang', 'proyek')) {
            $this->forge->addColumn('proyek', [
                'nilai_tukang' => [
                    'type'       => 'DECIMAL',
                    'constraint' => '15,2',
                    'default'    => 0.00,
                    'null'       => false,
                    'after'      => 'id_tukang',
                ],
            ]);
        }

        if (! $this->db->fieldExists('pekerjaan_tukang', 'proyek')) {
            $this->forge->addColumn('proyek', [
                'pekerjaan_tukang' => [
                    'type' => 'TEXT',
                    'null' => true,
                    'after' => 'nilai_tukang',
                ],
            ]);
        }
    }

    public function down()
    {
        if ($this->db->fieldExists('pekerjaan_tukang', 'proyek')) {
            $this->forge->dropColumn('proyek', 'pekerjaan_tukang');
        }

        if ($this->db->fieldExists('nilai_tukang', 'proyek')) {
            $this->forge->dropColumn('proyek', 'nilai_tukang');
        }
    }
}
