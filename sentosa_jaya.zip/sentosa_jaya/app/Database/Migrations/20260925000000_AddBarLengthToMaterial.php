<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddBarLengthToMaterial extends Migration
{
    public function up()
    {
        $fields = [
            'panjang_standar' => [
                'type'       => 'DECIMAL',
                'constraint' => '6,2',
                'default'    => 6.00,
                'null'       => false,
                'comment'    => 'Panjang standar material batang dalam meter',
            ],
        ];

        if (! $this->db->fieldExists('panjang_standar', 'material')) {
            $this->forge->addColumn('material', $fields);
        }

        $this->db->query(
            "UPDATE material m
             INNER JOIN jenis_pekerjaan jp ON jp.id_jp = m.id_jp
             SET m.satuan = 'batang'
             WHERE jp.nama IN ('Teralis', 'Tralis') AND m.kategori = 'rangka'"
        );
    }

    public function down()
    {
        if ($this->db->fieldExists('panjang_standar', 'material')) {
            $this->forge->dropColumn('material', 'panjang_standar');
        }
    }
}
