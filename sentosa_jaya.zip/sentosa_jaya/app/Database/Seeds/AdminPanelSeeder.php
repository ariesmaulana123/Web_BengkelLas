<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class AdminPanelSeeder extends Seeder
{
    public function run()
    {
        $db = \Config\Database::connect();
        $forge = \Config\Database::forge();

        echo "Running Database Schema Updates for Sentosa Jaya Las Admin Panel...\n";

        // 1. Alter table estimasi (Add columns for Estimasi Final & Survey)
        $fieldsToAdd = [
            'biaya_jasa' => [
                'type' => 'DECIMAL',
                'constraint' => '15,2',
                'default' => 0.00,
                'after' => 'estimasi_max'
            ],
            'biaya_pengiriman' => [
                'type' => 'DECIMAL',
                'constraint' => '15,2',
                'default' => 0.00,
                'after' => 'biaya_jasa'
            ],
            'biaya_tambahan' => [
                'type' => 'DECIMAL',
                'constraint' => '15,2',
                'default' => 0.00,
                'after' => 'biaya_pengiriman'
            ],
            'diskon' => [
                'type' => 'DECIMAL',
                'constraint' => '15,2',
                'default' => 0.00,
                'after' => 'biaya_tambahan'
            ],
            'total_final' => [
                'type' => 'DECIMAL',
                'constraint' => '15,2',
                'null' => true,
                'after' => 'diskon'
            ],
            'catatan_admin' => [
                'type' => 'TEXT',
                'null' => true,
                'after' => 'catatan'
            ],
            'tanggal_survey' => [
                'type' => 'DATETIME',
                'null' => true,
                'after' => 'catatan_admin'
            ],
            'lokasi_survey' => [
                'type' => 'TEXT',
                'null' => true,
                'after' => 'tanggal_survey'
            ]
        ];

        foreach ($fieldsToAdd as $colName => $colDef) {
            if (!$db->fieldExists($colName, 'estimasi')) {
                $forge->addColumn('estimasi', [$colName => $colDef]);
                echo "[OK] Added column '$colName' to 'estimasi'.\n";
            } else {
                echo "[SKIP] Column '$colName' already exists in 'estimasi'.\n";
            }
        }

        // 2. Create table proyek
        if (!$db->tableExists('proyek')) {
            $db->query("
                CREATE TABLE `proyek` (
                  `id_proyek` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
                  `id_estimasi` bigint UNSIGNED DEFAULT NULL,
                  `id_user` int UNSIGNED NOT NULL,
                  `id_tukang` int UNSIGNED DEFAULT NULL,
                  `nilai_tukang` decimal(15,2) NOT NULL DEFAULT '0.00',
                  `pekerjaan_tukang` text,
                  `kode_proyek` varchar(50) NOT NULL,
                  `nama_proyek` varchar(150) NOT NULL,
                  `nilai_proyek` decimal(15,2) NOT NULL DEFAULT '0.00',
                  `dp` decimal(15,2) NOT NULL DEFAULT '0.00',
                  `sisa_pembayaran` decimal(15,2) NOT NULL DEFAULT '0.00',
                  `status_pembayaran` varchar(30) NOT NULL DEFAULT 'belum_lunas',
                  `tanggal_mulai` date DEFAULT NULL,
                  `tanggal_target_selesai` date DEFAULT NULL,
                  `tanggal_selesai` date DEFAULT NULL,
                  `progress` int NOT NULL DEFAULT '0',
                  `status` varchar(30) NOT NULL DEFAULT 'rencana',
                  `catatan` text,
                  `foto_dokumentasi` text,
                  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id_proyek`),
                  UNIQUE KEY `uq_kode_proyek` (`kode_proyek`),
                  KEY `idx_proyek_estimasi` (`id_estimasi`),
                  KEY `idx_proyek_user` (`id_user`),
                  KEY `idx_proyek_tukang` (`id_tukang`),
                  KEY `idx_proyek_status` (`status`),
                  CONSTRAINT `fk_proyek_estimasi` FOREIGN KEY (`id_estimasi`) REFERENCES `estimasi` (`id_estimasi`) ON DELETE SET NULL ON UPDATE CASCADE,
                  CONSTRAINT `fk_proyek_user` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE RESTRICT ON UPDATE CASCADE,
                  CONSTRAINT `fk_proyek_tukang` FOREIGN KEY (`id_tukang`) REFERENCES `users` (`id_user`) ON DELETE SET NULL ON UPDATE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
            ");
            echo "[OK] Table 'proyek' created successfully.\n";
        } else {
            echo "[SKIP] Table 'proyek' already exists.\n";
        }

        // 3. Create table kasbon tukang
        if (!$db->tableExists('kasbon_tukang')) {
            $db->query("
                CREATE TABLE `kasbon_tukang` (
                  `id_kasbon` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
                  `id_proyek` bigint UNSIGNED NOT NULL,
                  `id_tukang` int UNSIGNED NOT NULL,
                  `id_admin` int UNSIGNED NOT NULL,
                  `nominal` decimal(15,2) NOT NULL DEFAULT '0.00',
                  `tanggal_kasbon` date NOT NULL,
                  `keterangan` text,
                  `metode_pembayaran` varchar(30) NOT NULL DEFAULT 'transfer',
                  `bukti_transfer` varchar(255) DEFAULT NULL,
                  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id_kasbon`),
                  KEY `idx_kasbon_proyek` (`id_proyek`),
                  KEY `idx_kasbon_tukang` (`id_tukang`),
                  KEY `idx_kasbon_admin` (`id_admin`),
                  KEY `idx_kasbon_tanggal` (`tanggal_kasbon`),
                  CONSTRAINT `fk_kasbon_proyek` FOREIGN KEY (`id_proyek`) REFERENCES `proyek` (`id_proyek`) ON DELETE RESTRICT ON UPDATE CASCADE,
                  CONSTRAINT `fk_kasbon_tukang` FOREIGN KEY (`id_tukang`) REFERENCES `users` (`id_user`) ON DELETE RESTRICT ON UPDATE CASCADE,
                  CONSTRAINT `fk_kasbon_admin` FOREIGN KEY (`id_admin`) REFERENCES `users` (`id_user`) ON DELETE RESTRICT ON UPDATE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
            ");
            echo "[OK] Table 'kasbon_tukang' created successfully.\n";
        } else {
            echo "[SKIP] Table 'kasbon_tukang' already exists.\n";
        }

        // 4. Create table follow_up
        if (!$db->tableExists('follow_up')) {
            $db->query("
                CREATE TABLE `follow_up` (
                  `id_follow_up` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
                  `id_estimasi` bigint UNSIGNED DEFAULT NULL,
                  `id_proyek` bigint UNSIGNED DEFAULT NULL,
                  `id_user_admin` int UNSIGNED NOT NULL,
                  `tipe` varchar(50) NOT NULL DEFAULT 'estimasi',
                  `metode` varchar(50) NOT NULL DEFAULT 'whatsapp',
                  `hasil` text NOT NULL,
                  `tanggal_follow_up` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `tanggal_next_follow_up` datetime DEFAULT NULL,
                  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id_follow_up`),
                  KEY `idx_fu_estimasi` (`id_estimasi`),
                  KEY `idx_fu_proyek` (`id_proyek`),
                  KEY `idx_fu_admin` (`id_user_admin`),
                  CONSTRAINT `fk_fu_estimasi` FOREIGN KEY (`id_estimasi`) REFERENCES `estimasi` (`id_estimasi`) ON DELETE CASCADE ON UPDATE CASCADE,
                  CONSTRAINT `fk_fu_proyek` FOREIGN KEY (`id_proyek`) REFERENCES `proyek` (`id_proyek`) ON DELETE CASCADE ON UPDATE CASCADE,
                  CONSTRAINT `fk_fu_admin` FOREIGN KEY (`id_user_admin`) REFERENCES `users` (`id_user`) ON DELETE RESTRICT ON UPDATE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
            ");
            echo "[OK] Table 'follow_up' created successfully.\n";
        } else {
            echo "[SKIP] Table 'follow_up' already exists.\n";
        }

        // 5. Create table pengaturan_perusahaan
        if (!$db->tableExists('pengaturan_perusahaan')) {
            $db->query("
                CREATE TABLE `pengaturan_perusahaan` (
                  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
                  `nama_perusahaan` varchar(150) NOT NULL DEFAULT 'Sentosa Jaya Las',
                  `tagline` varchar(255) DEFAULT 'Bengkel Las & Konstruksi Baja Presisi Bergaransi',
                  `alamat` text NOT NULL,
                  `no_wa` varchar(30) NOT NULL DEFAULT '087766364557',
                  `email` varchar(100) NOT NULL DEFAULT 'admin@sentosajayalas.com',
                  `nama_bank` varchar(50) DEFAULT 'BCA (Bank Central Asia)',
                  `no_rekening` varchar(50) DEFAULT '8735-0912-33',
                  `atas_nama_bank` varchar(100) DEFAULT 'Sentosa Jaya Las / Maulana',
                  `logo` varchar(255) DEFAULT NULL,
                  `nama_penanggung_jawab` varchar(100) DEFAULT 'Bambang Sentosa',
                  `jabatan_penanggung_jawab` varchar(100) DEFAULT 'Direktur Operasional',
                  `catatan_penawaran` text,
                  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
            ");
            echo "[OK] Table 'pengaturan_perusahaan' created successfully.\n";

            // Insert initial row
            $db->table('pengaturan_perusahaan')->insert([
                'nama_perusahaan' => 'Sentosa Jaya Las',
                'tagline' => 'Spesialis Kanopi, Pagar, Railing & Konstruksi Besi Berkualitas',
                'alamat' => 'Jl. Raya Industri Metal No. 88, Kawasan Bengkel Sentosa, Jabodetabek',
                'no_wa' => '087766364557',
                'email' => 'info@sentosajayalas.com',
                'nama_bank' => 'Bank Central Asia (BCA)',
                'no_rekening' => '8735-0912-33',
                'atas_nama_bank' => 'Sentosa Jaya Las',
                'nama_penanggung_jawab' => 'Bambang Sentosa',
                'jabatan_penanggung_jawab' => 'Kepala Workshop & Estimator Senior',
                'catatan_penawaran' => "1. Harga sudah termasuk material, ongkos kerja perakitan, dan pemasangan di lokasi.\n2. Pembayaran DP minimal 50% saat kesepakatan SPK kerja, pelunasan setelah pengerjaan selesai 100% dan di-acc pelanggan.\n3. Masa garansi konstruksi dan kebocoran atap berlaku selama 12 bulan sejak serah terima.",
            ]);
            echo "[OK] Initial settings row inserted.\n";
        } else {
            echo "[SKIP] Table 'pengaturan_perusahaan' already exists.\n";
        }

        // 6. Check if sample tukang user exists
        $tukang = $db->table('users')->where('email', 'tukang@sentosajayalas.com')->get()->getRow();
        if (!$tukang) {
            $db->table('users')->insert([
                'nama'       => 'Sujatno (Tukang Las Senior)',
                'email'      => 'tukang@sentosajayalas.com',
                'no_wa'      => '081298765001',
                'password'   => password_hash('tukang123', PASSWORD_BCRYPT),
                'role'       => 'tukang',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
            echo "[OK] Sample user 'tukang' created (email: tukang@sentosajayalas.com / tukang123).\n";
        }

        echo "Database Migration Completed Successfully!\n";
    }
}
