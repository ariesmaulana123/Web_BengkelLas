<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class InitialDataSeeder extends Seeder
{
    public function run()
    {
        $db = \Config\Database::connect();

        // 1. Seed Users
        $users = [
            [
                'nama'       => 'Pelanggan Sentosa',
                'email'      => 'pelanggan@example.com',
                'no_wa'      => '081234567890',
                'password'   => password_hash('password123', PASSWORD_BCRYPT),
                'role'       => 'customer',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'nama'       => 'Admin Sentosa Jaya',
                'email'      => 'admin@sentosajayalas.com',
                'no_wa'      => '087766364557',
                'password'   => password_hash('admin123', PASSWORD_BCRYPT),
                'role'       => 'admin',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
        ];

        foreach ($users as $user) {
            $existing = $db->table('users')->where('email', $user['email'])->get()->getRow();
            if (!$existing) {
                $db->table('users')->insert($user);
            }
        }

        // 2. Seed Jenis Pekerjaan
        $jenisPekerjaan = [
            [
                'nama'      => 'Kanopi',
                'deskripsi' => 'Pembuatan dan pemasangan kanopi carport, teras, dan kanopi komersial dengan berbagai pilihan rangka dan atap berkualitas.',
                'status'    => 'aktif',
            ],
            [
                'nama'      => 'Pagar',
                'deskripsi' => 'Fabrikasi pagar besi minimalis, laser cutting, perforated, dan expanded metal bergaransi anti karat.',
                'status'    => 'aktif',
            ],
            [
                'nama'      => 'Railing Tangga',
                'deskripsi' => 'Pemasangan railing tangga dan balkon modern dari bahan hollow galvanis, stainless steel, dan kaca tempered.',
                'status'    => 'aktif',
            ],
            [
                'nama'      => 'Teralis',
                'deskripsi' => 'Pembuatan teralis jendela dan pintu pengaman dengan material besi nako, plat, atau hollow kokoh.',
                'status'    => 'aktif',
            ],
        ];

        foreach ($jenisPekerjaan as $jp) {
            $existing = $db->table('jenis_pekerjaan')->where('nama', $jp['nama'])->get()->getRow();
            if (!$existing) {
                $db->table('jenis_pekerjaan')->insert([
                    'nama'       => $jp['nama'],
                    'deskripsi'  => $jp['deskripsi'],
                    'status'     => $jp['status'],
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
            }
        }

        // Ambil mapping id_jp
        $jpRows = $db->table('jenis_pekerjaan')->get()->getResultArray();
        $jpMap = [];
        foreach ($jpRows as $row) {
            $jpMap[$row['nama']] = $row['id_jp'];
        }

        // 3. Seed Material & Master Harga
        $materialsData = [
            // --- KANOPI ---
            // Rangka
            ['Kanopi', 'rangka', 'Hollow Galvanis 40x40 (Tebal 1.2mm)', 'm2', 175000],
            ['Kanopi', 'rangka', 'Hollow Galvanis 40x60 (Tebal 1.4mm)', 'm2', 225000],
            ['Kanopi', 'rangka', 'Baja Ringan Zincalume C75', 'm2', 135000],
            ['Kanopi', 'rangka', 'Besi WF 150 Industrial', 'm2', 390000],
            // Atap
            ['Kanopi', 'atap', 'Alderon Double Layer (Twinwall)', 'm2', 245000],
            ['Kanopi', 'atap', 'Alderon Single Layer (RS)', 'm2', 160000],
            ['Kanopi', 'atap', 'Spandek Pasir (Peredam Suara)', 'm2', 130000],
            ['Kanopi', 'atap', 'Polycarbonate SolarTuff Flat', 'm2', 210000],
            ['Kanopi', 'atap', 'Kaca Tempered 8mm Clear', 'm2', 480000],
            // Tiang (opsional per meter tinggi)
            ['Kanopi', 'tiang', 'Tiang Hollow 40x60 / 50x50 Galvanis', 'm', 95000],
            // Jasa Fabrikasi & Pasang Kanopi
            ['Kanopi', 'jasa', 'Jasa Fabrikasi & Instalasi Kanopi', 'm2', 100000],

            // --- PAGAR ---
            ['Pagar', 'rangka', 'Besi Hollow Minimalis Galvanis 40x40/40x20', 'm2', 380000],
            ['Pagar', 'rangka', 'Laser Cutting Motif Plat Baja 2mm', 'm2', 750000],
            ['Pagar', 'rangka', 'Kombinasi Plat Perforated & Hollow', 'm2', 520000],
            ['Pagar', 'rangka', 'Besi Tempa Klasik Ornamen', 'm2', 680000],
            ['Pagar', 'jasa', 'Jasa Fabrikasi & Pemasangan Pagar', 'm2', 120000],

            // --- RAILING TANGGA ---
            ['Railing Tangga', 'rangka', 'Hollow Galvanis Minimalis + Handrail Kayu', 'm2', 450000],
            ['Railing Tangga', 'rangka', 'Stainless Steel 304 Anti Karat', 'm2', 650000],
            ['Railing Tangga', 'rangka', 'Kaca Tempered 10mm Frameless', 'm2', 850000],
            ['Railing Tangga', 'rangka', 'Besi Hollow Full Hitam Doff', 'm2', 380000],
            ['Railing Tangga', 'jasa', 'Jasa Fabrikasi & Pemasangan Railing', 'm2', 110000],

            // --- TERALIS ---
            ['Teralis', 'rangka', 'Besi Nako 12mm Minimalis Modern', 'batang', 280000],
            ['Teralis', 'rangka', 'Besi Plat Strip Minimalis', 'batang', 250000],
            ['Teralis', 'rangka', 'Hollow Galvanis 20x20 Kotak', 'batang', 240000],
            ['Teralis', 'rangka', 'Besi Ulir Tempa Klasik 12mm', 'batang', 350000],
            ['Teralis', 'jasa', 'Jasa Pasang & Finishing Teralis', 'm2', 80000],
        ];

        foreach ($materialsData as $item) {
            [$jpName, $kategori, $namaMaterial, $satuan, $harga] = $item;
            $idJp = $jpMap[$jpName] ?? null;
            if (!$idJp) continue;

            $existingMat = $db->table('material')
                ->where('id_jp', $idJp)
                ->where('kategori', $kategori)
                ->where('nama_material', $namaMaterial)
                ->get()
                ->getRow();

            if (!$existingMat) {
                $db->table('material')->insert([
                    'id_jp'         => $idJp,
                    'kategori'      => $kategori,
                    'nama_material' => $namaMaterial,
                    'satuan'        => $satuan,
                    'status'        => 'aktif',
                    'created_at'    => date('Y-m-d H:i:s'),
                    'updated_at'    => date('Y-m-d H:i:s'),
                ]);
                $idMaterial = $db->insertID();
            } else {
                $idMaterial = $existingMat->id_material;
            }

            $existingHarga = $db->table('master_harga')->where('id_material', $idMaterial)->get()->getRow();
            if (!$existingHarga) {
                $db->table('master_harga')->insert([
                    'id_material' => $idMaterial,
                    'harga'       => $harga,
                    'status'      => 'aktif',
                    'created_at'  => date('Y-m-d H:i:s'),
                    'updated_at'  => date('Y-m-d H:i:s'),
                ]);
            } else {
                $db->table('master_harga')->where('id_material', $idMaterial)->update([
                    'harga'      => $harga,
                    'status'     => 'aktif',
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
            }
        }
    }
}
