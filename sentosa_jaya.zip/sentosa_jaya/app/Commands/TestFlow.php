<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\EstimasiModel;
use App\Models\UserModel;

class TestFlow extends BaseCommand
{
    protected $group       = 'Testing';
    protected $name        = 'test:flow';
    protected $description = 'Runs end-to-end integration tests for estimation & manual job orders';

    public function run(array $params)
    {
        CLI::write("=== MEMULAI TEST INTEGRASI ALUR SISTEM ===", 'green');

        $estimasiModel = new EstimasiModel();
        $userModel = new UserModel();

        // 1. Cek User Testing
        $testUser = $userModel->where('role', 'customer')->first();
        if (!$testUser) {
            CLI::write("[!] Membuat customer test...", 'yellow');
            $userId = $userModel->insert([
                'username' => 'testcustomer',
                'password' => password_hash('password', PASSWORD_DEFAULT),
                'nama'     => 'Budi Test Customer',
                'no_wa'    => '081234567890',
                'alamat'   => 'Jl. Test No. 123',
                'role'     => 'customer'
            ]);
        } else {
            $userId = $testUser['id_user'];
            CLI::write("[OK] Menggunakan customer ID: {$userId} ({$testUser['nama']})", 'cyan');
        }

        // 2. Test Simpan Estimasi dari Landing Page (Kalkulator - User)
        CLI::write("\n--- 1. Testing Simpan Estimasi dari Kalkulator (User Landing Page) ---", 'yellow');
        $calcData = [
            'id_user'       => $userId,
            'id_jp'         => null,
            'panjang'       => 5.00,
            'lebar'         => 3.00,
            'tinggi'        => 0.00,
            'total_volume'  => 15.00,
            'total_estimasi'=> 4500000.00,
            'rincian_biaya' => json_encode(['bahan' => 3000000, 'jasa' => 1500000]),
            'catatan'       => 'Estimasi kanopi carport dari kalkulator web',
            'status'        => 'tersimpan',
            'sumber'        => 'kalkulator'
        ];
        $calcEstimasiId = $estimasiModel->insert($calcData);
        CLI::write("[OK] Estimasi kalkulator berhasil disimpan dengan ID: {$calcEstimasiId}", 'green');

        // 3. Test Cek di Riwayat User
        $userRiwayat = $estimasiModel->getEstimasiByUser($userId);
        $foundInUser = false;
        foreach ($userRiwayat as $r) {
            if ($r['id_estimasi'] == $calcEstimasiId) {
                $foundInUser = true;
                break;
            }
        }
        if ($foundInUser) {
            CLI::write("[PASS] Data estimasi kalkulator MUNCUL di Riwayat User (/riwayat).", 'green');
        } else {
            CLI::error("[FAIL] Data estimasi kalkulator TIDAK DITEMUKAN di Riwayat User!");
        }

        // 4. Test Cek di Admin CRM (Pencatatan Pekerjaan Manual) -> HARUS TIDAK MUNCUL!
        $adminList = $estimasiModel->getEstimasiCRM();
        $foundInAdmin = false;
        foreach ($adminList as $a) {
            if ($a['id_estimasi'] == $calcEstimasiId) {
                $foundInAdmin = true;
                break;
            }
        }
        if (!$foundInAdmin) {
            CLI::write("[PASS] Data estimasi kalkulator TIDAK MUNCUL di Admin CRM (Pencatatan Pekerjaan Manual) - Sesuai Aturan Baru!", 'green');
        } else {
            CLI::error("[FAIL] Data estimasi kalkulator MASIH MUNCUL di Admin CRM!");
        }

        // 5. Test Pencatatan Pekerjaan Manual oleh Admin (Customer WA Fix)
        CLI::write("\n--- 2. Testing Pencatatan Pekerjaan Manual oleh Admin (Order WA) ---", 'yellow');
        $manualData = [
            'id_user'             => null,
            'nama_customer_manual'=> 'Ibu Hajah Siti (WA)',
            'no_wa_manual'        => '082199887766',
            'nama_pekerjaan'      => 'Teralis Jendela Klasik & Pintu Kasa Nyamuk',
            'panjang'             => 2.50,
            'lebar'               => 1.80,
            'tinggi'              => 0.00,
            'ukuran_lubang'       => '15 x 15 cm jarak kisi',
            'qty_unit'            => '4 Unit Jendela + 1 Pintu',
            'material_custom'     => 'Besi Nako 12mm Full, Frame Hollow 4x4 Tebal 1.6mm, Finishing Duco Hitam Doff',
            'harga_bahan'         => 2800000.00,
            'harga_jasa'          => 1200000.00,
            'biaya_pengiriman'    => 150000.00,
            'diskon'              => 50000.00,
            'total_estimasi'      => 4100000.00,
            'catatan'             => 'Deal via WA. Pemasangan di Perum Griya Indah Blok B2.',
            'status'              => 'deal',
            'sumber'              => 'manual'
        ];
        $manualEstimasiId = $estimasiModel->insert($manualData);
        CLI::write("[OK] Pekerjaan manual berhasil disimpan dengan ID: {$manualEstimasiId}", 'green');

        // 6. Test Cek di Admin CRM -> HARUS MUNCUL
        $adminListAfter = $estimasiModel->getEstimasiCRM();
        $foundManualInAdmin = false;
        $manualRecord = null;
        foreach ($adminListAfter as $a) {
            if ($a['id_estimasi'] == $manualEstimasiId) {
                $foundManualInAdmin = true;
                $manualRecord = $a;
                break;
            }
        }
        if ($foundManualInAdmin) {
            CLI::write("[PASS] Pekerjaan manual MUNCUL di Admin CRM (Pencatatan Pekerjaan) dengan detail:", 'green');
            CLI::write("       - Customer: {$manualRecord['nama_customer']}");
            CLI::write("       - Pekerjaan: {$manualRecord['nama_pekerjaan']}");
            CLI::write("       - Qty / Unit: {$manualRecord['qty_unit']}");
            CLI::write("       - Total Biaya: Rp " . number_format($manualRecord['total_final'] ?? $manualRecord['subtotal'] ?? 0, 0, ',', '.'));
            CLI::write("       - Status: {$manualRecord['status']}");
        } else {
            CLI::error("[FAIL] Pekerjaan manual TIDAK DITEMUKAN di Admin CRM!");
        }

        // 7. Test Detail Estimasi
        CLI::write("\n--- 3. Testing getEstimasiDetail ---", 'yellow');
        $detail = $estimasiModel->getEstimasiDetail($manualEstimasiId);
        if ($detail && $detail['nama_customer'] == 'Ibu Hajah Siti (WA)') {
            CLI::write("[PASS] getEstimasiDetail mengembalikan data customer & spesifikasi lengkap dengan benar.", 'green');
        } else {
            CLI::error("[FAIL] getEstimasiDetail gagal mengembalikan data!");
        }

        // 8. Test Render PDF Template (Penawaran / SPK)
        CLI::write("\n--- 4. Testing Render View PDF Penawaran / SPK ---", 'yellow');
        try {
            $pdfView = view('admin/crm/estimasi/penawaran_pdf', ['estimasi' => $detail]);
            if (strpos($pdfView, 'Teralis Jendela Klasik') !== false && strpos($pdfView, '15 x 15 cm jarak kisi') !== false) {
                CLI::write("[PASS] Template PDF Penawaran/SPK berhasil di-render tanpa error dan memuat spesifikasi custom.", 'green');
            } else {
                CLI::error("[FAIL] Template PDF tidak memuat konten spesifikasi manual yang sesuai.");
            }
        } catch (\Throwable $e) {
            CLI::error("[FAIL] Error rendering PDF view: " . $e->getMessage());
        }

        // 9. Test Render View Laporan PDF
        CLI::write("\n--- 5. Testing Render View Laporan PDF ---", 'yellow');
        try {
            $settingsModel = new \App\Models\PengaturanPerusahaanModel();
            $laporanData = [
                'title'                => 'Laporan Rekapitulasi Pekerjaan & Keuangan',
                'startDate'            => '2026-01-01',
                'endDate'              => '2026-12-31',
                'totalEstimasi'        => 5,
                'proyekStats'          => ['total_proyek' => 2, 'omzet' => 15000000, 'total_dp' => 5000000, 'total_piutang' => 10000000],
                'proyekList'           => [],
                'pekerjaanListPeriode' => [$manualRecord],
                'jpStats'              => [],
                'settings'             => $settingsModel->getSettings(),
                'adminName'            => 'Administrator',
                'adminRole'            => 'Admin'
            ];
            $laporanPdfView = view('admin/laporan/cetak_pdf', $laporanData);
            if (stripos($laporanPdfView, 'Rekapitulasi') !== false) {
                CLI::write("[PASS] Template PDF Laporan Rekapitulasi berhasil di-render tanpa error.", 'green');
            } else {
                CLI::error("[FAIL] Template Laporan PDF gagal di-render dengan benar.");
            }
        } catch (\Throwable $e) {
            CLI::error("[FAIL] Error rendering Laporan PDF view: " . $e->getMessage());
        }

        CLI::write("\n=== SEMUA TESTING SELESAI DENGAN SUKSES ===", 'green');
    }
}
